import sys

def extract():
    with open("recovered_73_0x7fb0d0000000.tsx", "rb") as f:
        data = f.read()
    
    target_utf8 = b"export default function App() {"
    
    idx = data.find(target_utf8)
    if idx != -1:
        print("Found UTF-8 at", idx)
        
        # look for something near the end
        end_idx = data.find(b"Toaster", idx)
        if end_idx != -1:
            print("Found Toaster at", end_idx)
            end = data.find(b";\n}", end_idx)
            if end != -1:
                with open("App_recovered_clean.tsx", "wb") as out:
                    out.write(data[idx:end+3])
                print("Extracted successfully!")
                return
        print("Could not find end")

if __name__ == "__main__":
    extract()
