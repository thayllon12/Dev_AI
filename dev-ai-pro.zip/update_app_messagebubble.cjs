const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(
    /isCodeMode=\{isCodeMode\} chatId=\{currentChatId\}/g,
    `isCodeMode={isCodeMode} chatId={currentChatId}\n                    onExportGithub={() => setGithubModal({ isOpen: true, mode: 'export' })}\n                    onImportGithub={() => setGithubModal({ isOpen: true, mode: 'import' })}`
);

fs.writeFileSync('src/App.tsx', content);
