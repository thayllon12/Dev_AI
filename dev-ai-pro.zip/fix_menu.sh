sed -i 's/bg-\[#1f1f23\]/bg-bg-modal/g' src/components/MessageBubble.tsx
sed -i 's/border-white\/10/border-border-subtle/g' src/components/MessageBubble.tsx
sed -i 's/text-\[#9ca3af\]/text-text-muted/g' src/components/MessageBubble.tsx
sed -i 's/border-white\/5/border-border-subtle/g' src/components/MessageBubble.tsx
sed -i 's/text-white/text-text-primary/g' src/components/MessageBubble.tsx
sed -i 's/hover:bg-white\/10/hover:bg-bg-surface-hover/g' src/components/MessageBubble.tsx
