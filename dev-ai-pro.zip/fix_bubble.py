import sys

with open('src/components/MessageBubble.tsx', 'r') as f:
    text = f.read()

bad_part = "                  )}</h3>"
idx = text.find(bad_part)
if idx != -1:
    top_half = text[:idx + 20] # keep the "                  )}"
    
    missing_code = """
                </motion.div>
              )}
            </div>
          </div>
          {/* Auto Continuar Geração button below message when cut off */}
          {!isUser && onContinue && (msg.needsContinue || isLastMessage) && (
            <div className="mt-2 flex items-center">
              <button
                onClick={() => onContinue(msg)}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold bg-purple-500/10 text-purple-400 hover:bg-purple-500/20 border border-purple-500/30 rounded-xl transition-all shadow-sm hover:scale-105 active:scale-95"
              >
                <Play size={14} />
                <span>Continuar geração</span>
              </button>
            </div>
          )}
        </div>
      </motion.div>
      <FilePreviewModal
        isOpen={!!previewFile}
        onClose={() => setPreviewFile(null)}
        dataUrl={previewFile?.dataUrl || ""}
        mimeType={previewFile?.mimeType || "image/png"}
        fileName={previewFile?.fileName}
        onEdit={() => {
          if (previewFile?.dataUrl) {
            setMarkupImage(previewFile.dataUrl);
            setPreviewFile(null);
          }
        }}
      />
      {markupImage && (
        <ImageMarkupModal
          isOpen={!!markupImage}
          onClose={() => setMarkupImage(null)}
          dataUrl={markupImage}
          onSave={(newDataUrl) => {
            // Initiate a local download of the edited image
            const link = document.createElement("a");
            link.href = newDataUrl;
            link.download = `editado_${previewFile?.fileName || "imagem.png"}`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            setMarkupImage(null);
            toast.success("Imagem editada e salva!");
          }}
        />
      )}
      {/* Sources Modal */}
      {showSourcesModal && (
        <div className="fixed inset-0 z-[100000] bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-[#18181b] border border-border-subtle w-full max-w-xl rounded-t-3xl sm:rounded-2xl p-5 shadow-2xl flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between pb-3 border-b border-border-subtle mb-4">
              <div className="flex items-center gap-2">
                <ExternalLink size={18} className="text-primary" />
                <h3 className="font-bold text-base text-text-primary">Fontes de Pesquisa ({getMessageSources().length})</h3>"""

    bottom_half = text[idx + 20:] # after "}</h3>" -> "              </div>\n              <button"
    
    with open('src/components/MessageBubble.tsx', 'w') as f:
        f.write(top_half + missing_code + bottom_half)
    print("Fixed!")
else:
    print("Could not find bad part")
