const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(
  /<Toaster position="top-center" richColors \/>/,
  `<GithubSyncModal 
        isOpen={githubModal.isOpen} 
        mode={githubModal.mode} 
        onClose={() => setGithubModal({ ...githubModal, isOpen: false })} 
      />
      <Toaster position="top-center" richColors />`
);

fs.writeFileSync('src/App.tsx', content);
