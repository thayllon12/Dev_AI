import sys
with open("recovered_73_0x7fb0d0000000.tsx", "rb") as f:
    data = f.read()

target = b"getAI = "
idx = data.find(target)
if idx != -1:
    print(data[idx:idx+500].decode("utf-8", "ignore"))
else:
    print("getAI = not found")
    
target = b"function getAI"
idx = data.find(target)
if idx != -1:
    print(data[idx:idx+500].decode("utf-8", "ignore"))
else:
    print("function getAI not found")

target = b"export const getAI"
idx = data.find(target)
if idx != -1:
    print(data[idx:idx+500].decode("utf-8", "ignore"))
else:
    print("export const getAI not found")
