import sys
import string

def extract():
    with open("recovered_90_0xc000000000.tsx", "rb") as f:
        data = f.read()
    
    # Try utf-8 decode, replace errors
    text = data.decode("utf-8", "ignore")
    # print some part of it to see
    idx = text.find("export default function App")
    if idx != -1:
        print(text[idx:idx+1000])
        print("==========")
        print(text[idx+1000:idx+2000])

if __name__ == "__main__":
    extract()
