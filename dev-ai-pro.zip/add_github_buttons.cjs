const fs = require('fs');
let content = fs.readFileSync('src/components/MessageBubble.tsx', 'utf8');

const target = `                    </button>
                  )}`;

const newButtons = `                    </button>
                  )}
                  {!isUser && hasCodeBlocks && onExportGithub && (
                    <button
                      onClick={() => {
                        onExportGithub(msg);
                        setShowActions(false);
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left border-t border-border-subtle mt-0.5 pt-1.5"
                    >
                      <Github size={16} className="text-text-primary" />
                      <span>Exportar para o GitHub</span>
                    </button>
                  )}
                  {!isUser && hasCodeBlocks && onImportGithub && (
                    <button
                      onClick={() => {
                        onImportGithub(msg);
                        setShowActions(false);
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left"
                    >
                      <Download size={16} className="text-text-primary" />
                      <span>Importar do GitHub</span>
                    </button>
                  )}`;

// Replace only the LAST occurrence of target which is for the ZIP button.
// Let's do it by regex matching the ZIP button specifically.

content = content.replace(
    /<span>Baixar projeto \(ZIP\)<\/span>[\s\S]*?<\/button>[\s\S]*?}\)/,
    `<span>Baixar projeto (ZIP)</span>
                    </button>
                  )}
                  {!isUser && hasCodeBlocks && onExportGithub && (
                    <button
                      onClick={() => {
                        onExportGithub(msg);
                        setShowActions(false);
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left border-t border-border-subtle mt-0.5 pt-1.5"
                    >
                      <Github size={16} className="text-text-primary" />
                      <span>Exportar para GitHub</span>
                    </button>
                  )}
                  {!isUser && hasCodeBlocks && onImportGithub && (
                    <button
                      onClick={() => {
                        onImportGithub(msg);
                        setShowActions(false);
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left"
                    >
                      <Download size={16} className="text-text-primary" />
                      <span>Importar do GitHub</span>
                    </button>
                  )}`
);

// add Github to imports if not there
if (!content.includes('Github,')) {
    content = content.replace('Archive,', 'Archive, Github,');
}

fs.writeFileSync('src/components/MessageBubble.tsx', content);
