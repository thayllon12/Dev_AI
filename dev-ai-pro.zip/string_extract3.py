import sys

def extract():
    with open("recovered_90_0xc000000000.tsx", "rb") as f:
        data = f.read()
    
    target_utf8 = b"export default function App() {"
    target_utf16 = target_utf8.decode('utf-8').encode('utf-16le')
    
    idx = data.find(target_utf8)
    if idx != -1:
        print("Found UTF-8 at", idx)
        end_idx = data.find(b"  );\n}", idx)
        if end_idx == -1:
            end_idx = data.find(b";}", idx)
        if end_idx == -1:
            print("End not found in UTF-8")
            end_idx = idx + 200000
        
        chunk = data[idx:end_idx+6]
        # some bytes might be interspersed? In Go strings are contiguous.
        with open("App_recovered_clean.tsx", "wb") as out:
            out.write(chunk)
        print("Wrote", len(chunk), "bytes")
        return
        
    idx = data.find(target_utf16)
    if idx != -1:
        print("Found UTF-16 at", idx)
        end_idx = data.find(b";\x00}\x00", idx)
        if end_idx == -1:
            print("End not found in UTF-16")
            end_idx = idx + 400000
        chunk = data[idx:end_idx+4]
        try:
            clean_text = chunk.decode('utf-16le')
            with open("App_recovered_clean.tsx", "w") as out:
                out.write(clean_text)
            print("Wrote UTF-16 decoded")
        except Exception as e:
            print("Decode error", e)
        return

if __name__ == "__main__":
    extract()
