with open("recovered_90_0xc000000000.tsx", "rb") as f:
    data = f.read()

idx = data.find(b"import React, { useState,")
if idx != -1:
    end = data.find(b"export default function App() {", idx)
    print(data[idx:end].decode("utf-8", "ignore"))
else:
    print("Not found in 90")
