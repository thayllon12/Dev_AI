const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(
  /<MicrofoneGemini[\s\S]*?onStateChange=\{setMicState\}\s*\/>/,
  `<button
                      type="button"
                      onClick={() => setGithubModal({ isOpen: true, mode: 'export' })}
                      className="p-2 sm:p-2.5 text-text-muted hover:text-text-primary rounded-xl hover:bg-bg-surface-hover transition-colors shrink-0"
                      title="Exportar para GitHub"
                    >
                      <Github size={20} strokeWidth={2.5} />
                    </button>`
);

// Add GithubSyncModal right before </AnimatePresence> at the bottom.
content = content.replace(
  /<\/AnimatePresence>\n\s*<\/div>\n\s*\);\n}/,
  `  <GithubSyncModal 
        isOpen={githubModal.isOpen} 
        mode={githubModal.mode} 
        onClose={() => setGithubModal({ ...githubModal, isOpen: false })} 
      />
      </AnimatePresence>
    </div>
  );
}`
);

fs.writeFileSync('src/App.tsx', content);
