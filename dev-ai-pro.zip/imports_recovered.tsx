.gain.exponentialRampToValueAtTime(0.01, now + 1.2);

      osc.connect(distortion);
      distortion.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 1.2);

    } catch (e) {
      console.warn("Audio Context play failed:", e);
    }
  }

  if (navigator.vibrate) {
    try { navigator.vibrate([100, 50, 100, 50, 200]); } catch(e){}
  }
};

export const playOpeningSound = (enabled: boolean) => {
  if (!enabled || localStorage.getItem('soundEffectsEnabled') === 'false') return;
  playCancellableSound('https://www.myinstants.com/media/sounds/angelical.mp3');
};

export const playQuotaExceededSound = (enabled: boolean) => {
  if (!enabled || localStorage.getItem('soundEffectsEnabled') === 'false') return;
  const quotaSounds = [
    "https://www.myinstants.com/media/sounds/aiiii-aiii-aiiii.mp3",
    "https://www.myinstants.com/media/sounds/fahhhhhhhhhhhhhh.mp3",
    "https://www.myinstants.com/media/sounds/foi-quando-gyro-finalmente-entendeu.mp3",
    "https://www.myinstants.com/media/sounds/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-e-lutador.mp3",
  ];
  playCancellableSound(quotaSounds[Math.floor(Math.random() * quotaSounds.length)]);
};

let lastTickTime = 0;
export const playTypingTick = (vibrationEnabled: boolean) => {
  const now = Date.now();
  if (now - lastTickTime < 65) return;
  lastTickTime = now;
  const ctx = initAudioCtx();
  if (ctx) {
    try {
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(600 + Math.random() * 300, ctx.currentTime);
      gainNode.gain.setValueAtTime(0.015, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.05);
    } catch (err) {}
  }
  if (vibrationEnabled && navigator.vibrate) {
    try {
      navigator.vibrate(10); 
    } catch(e){}
  }
};


const getInitialSettings = () => {
  try {
    const saved = localStorage.getItem('userSettings');
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        selectedModel: parsed.selectedModel || 'gemini-3.6-flash',
        mode: parsed.mode || "Dev AI",
        personality: parsed.personality || "Alegre, prestativo e direto ao ponto.",
        theme: parsed.theme || "auto",
        colorTheme: parsed.colorTheme || "auto",
        highContrast: parsed.highContrast || false,
        vibration: parsed.vibration !== false,
        memory: parsed.memory || "",
        fullscreenEditor: parsed.fullscreenEditor || false,
        notificationsEnabled: parsed.notificationsEnabled !== false,
        isDevUnlocked: parsed.isDevUnlocked || false,
        realVoiceEnabled: parsed.realVoiceEnabled || false,
        soundEffectsEnabled: parsed.soundEffectsEnabled !== false,
        swarmEnabled: parsed.swarmEnabled || false,
        googleSearchEnabled: parsed.googleSearchEnabled !== false,
        typingEffect: parsed.typingEffect !== false,
        typingSound: parsed.typingSound !== false,
        autoApplyCode: parsed.autoApplyCode || false,
        codeWrap: parsed.codeWrap || false,
        autoSwitchOnError: parsed.autoSwitchOnError || false,
      };
    }
  } catch (e) { }
  return {
    selectedModel: localStorage.getItem('selectedModel') || 'gemini-3.6-flash',
    mode: "Dev AI",
    personality: "Alegre, prestativo e direto ao ponto.",
    theme: "auto",
    colorTheme: "auto",
    highContrast: false,
    vibration: true,
    memory: "",
    fullscreenEditor: false,
    notificationsEnabled: true,
    isDevUnlocked: false,
    realVoiceEnabled: false,
    soundEffectsEnabled: localStorage.getItem('soundEffectsEnabled') !== 'false',
    swarmEnabled: false,
    googleSearchEnabled: true,
    typingEffect: true,
    typingSound: true,
    autoApplyCode: false,
    codeWrap: false,
    autoSwitchOnError: false
  };
};

