const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const target = `<button
                      type="button"
                      onClick={() => setGithubModal({ isOpen: true, mode: 'export' })}
                      className="p-2 sm:p-2.5 text-text-muted hover:text-text-primary rounded-xl hover:bg-bg-surface-hover transition-colors shrink-0"
                      title="Sincronizar com GitHub"
                    >
                      <Github size={20} strokeWidth={2.5} />
                    </button>`;

const originalMic = `<MicrofoneGemini 
                      ref={micRef}
                      onTranscricaoConcluida={(texto, autoSend) => {
                        if (!texto) return;
                        let fullText = texto;
                        setInput((prev) => {
                          fullText = prev && prev.trim() ? prev.trim() + " " + texto : texto;
                          return fullText;
                        });
                        if (autoSend) {
                          setTimeout(() => {
                            handleSend(fullText);
                          }, 50);
                        }
                      }} 
                      onStateChange={setMicState}
                    />`;

if (content.includes(target)) {
    content = content.replace(target, originalMic);
    fs.writeFileSync('src/App.tsx', content);
    console.log("Restored microphone!");
} else {
    console.log("Target not found");
}
