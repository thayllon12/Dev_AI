import { io, Socket } from 'socket.io-client';

// Socket connection
let socket: Socket | null = null;

export const getSocket = (): Socket => {
  if (!socket) {
    socket = io();
  }
  return socket;
};
