import { detectSystemLanguage } from "./i18n";

export function getInitialSettings() {
  const defaultLanguage = detectSystemLanguage();
  try {
    const saved = localStorage.getItem("userSettings");
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        language: parsed.language || defaultLanguage,
        selectedModel: parsed.selectedModel || "gemini-3.6-flash",
        mode: parsed.mode || "Dev AI",
        personality: parsed.personality || "Alegre, prestativo e direto ao ponto.",
        theme: parsed.theme || "auto",
        colorTheme: parsed.colorTheme || "auto",
        highContrast: parsed.highContrast || false,
        vibration: parsed.vibration !== false,
        memory: parsed.memory || "",
        fullscreenEditor: parsed.fullscreenEditor || false,
        notificationsEnabled: parsed.notificationsEnabled !== false,
        isDevUnlocked: parsed.isDevUnlocked || false,
        realVoiceEnabled: parsed.realVoiceEnabled || false,
        soundEffectsEnabled: parsed.soundEffectsEnabled !== false,
        swarmEnabled: parsed.swarmEnabled || false,
        googleSearchEnabled: parsed.googleSearchEnabled !== false,
        typingEffect: parsed.typingEffect !== false,
        typingSound: parsed.typingSound !== false,
        autoApplyCode: parsed.autoApplyCode || false,
        codeWrap: parsed.codeWrap || false,
        autoSwitchOnError: parsed.autoSwitchOnError || false,
      };
    }
  } catch (e) {}

  return {
    language: defaultLanguage,
    selectedModel: localStorage.getItem("selectedModel") || "gemini-3.6-flash",
    mode: "Dev AI",
    personality: "Alegre, prestativo e direto ao ponto.",
    theme: "auto",
    colorTheme: "auto",
    highContrast: false,
    vibration: true,
    memory: "",
    fullscreenEditor: false,
    notificationsEnabled: true,
    isDevUnlocked: false,
    realVoiceEnabled: false,
    soundEffectsEnabled: localStorage.getItem("soundEffectsEnabled") !== "false",
    swarmEnabled: false,
    googleSearchEnabled: true,
    typingEffect: true,
    typingSound: true,
    autoApplyCode: false,
    codeWrap: false,
    autoSwitchOnError: false,
  };
}
