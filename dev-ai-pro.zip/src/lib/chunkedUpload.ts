const CHUNK_SIZE = 5 * 1024 * 1024; // 5 MB

export async function uploadLargeFile(
  file: File,
  mimeType: string,
  apiKey: string,
  onProgress: (percent: number, speed: string, eta: string) => void
): Promise<{ fileUri: string; mimeType: string; name: string }> {
  const startTime = Date.now();
  let uploadedBytes = 0;

  // Init
  const initRes = await fetch('/api/upload/init', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      filename: file.name,
      mimeType
    })
  });
  if (!initRes.ok) {
    throw new Error(`Erro ao inicializar upload (${initRes.status})`);
  }
  const { uploadId } = await initRes.json();

  const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
  
  // Upload chunks
  for (let i = 0; i < totalChunks; i++) {
    const start = i * CHUNK_SIZE;
    const end = Math.min(file.size, start + CHUNK_SIZE);
    const chunk = file.slice(start, end);

    const chunkBase64 = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]); // get base64 part
      };
      reader.readAsDataURL(chunk);
    });

    let retries = 3;
    while (retries > 0) {
      try {
        const chunkRes = await fetch('/api/upload/chunk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            uploadId,
            chunkBase64
          })
        });
        if (!chunkRes.ok) {
          throw new Error(`Falha no envio de chunk (${chunkRes.status})`);
        }
        break;
      } catch (err) {
        retries--;
        if (retries === 0) throw err;
        await new Promise(r => setTimeout(r, 2000 * (4 - retries))); // Exponential backoff
      }
    }

    uploadedBytes += chunk.size;
    
    // Calculate speed and ETA
    const elapsedSeconds = Math.max(0.1, (Date.now() - startTime) / 1000);
    const bytesPerSecond = uploadedBytes / elapsedSeconds;
    const speedMBps = (bytesPerSecond / (1024 * 1024)).toFixed(1) + ' MB/s';
    
    const remainingBytes = file.size - uploadedBytes;
    const remainingSeconds = remainingBytes / Math.max(1, bytesPerSecond);
    const etaStr = remainingSeconds > 60 
      ? Math.round(remainingSeconds / 60) + ' min' 
      : Math.round(remainingSeconds) + ' s';

    const percent = Math.round((uploadedBytes / file.size) * 100);
    onProgress(percent, speedMBps, etaStr);
  }

  // Complete
  const completeRes = await fetch('/api/upload/complete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      uploadId,
      mimeType,
      filename: file.name,
      apiKey
    })
  });

  if (!completeRes.ok) {
    const errorData = await completeRes.json().catch(() => ({}));
    throw new Error(errorData.error || `Erro ao finalizar upload (${completeRes.status})`);
  }

  return completeRes.json();
}