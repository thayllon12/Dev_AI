import { GoogleGenAI } from "@google/genai";

export function getAI() {
  const candidateKeys = [
    process.env.GEMINI_API_KEY,
    (import.meta as any).env && (import.meta as any).env.VITE_GEMINI_API_KEY,
    process.env.API_KEY
  ].filter(k => k && typeof k === 'string' && k.trim() !== '' && !k.startsWith('ya29.') && k !== 'MY_GEMINI_API_KEY' && !k.includes('MY_GEMINI_API_KEY'));

  const apiKey = candidateKeys[0] || process.env.GEMINI_API_KEY || ((import.meta as any).env && (import.meta as any).env.VITE_GEMINI_API_KEY) || "";

  if (apiKey.startsWith('ya29.')) {
    return new GoogleGenAI({ httpOptions: { headers: { Authorization: `Bearer ${apiKey}` } } });
  }
  return new GoogleGenAI({ apiKey });
}
