/**
 * Real-time dynamic status message detector based on actual AI response content
 */
export function detectRealtimeStatus(liveText: string, thinkText?: string | null, isConnecting?: boolean): string {
  if (isConnecting || (!liveText.trim() && !thinkText?.trim())) {
    return "Conectando à IA...";
  }

  // If inside thinking
  if (thinkText?.trim() && !liveText.trim()) {
    return "Processando pensamento...";
  }

  const text = liveText.trim();
  const last150 = text.slice(-150);

  // Check if currently inside a code block
  const codeFenceCount = (text.match(/```/g) || []).length;
  if (codeFenceCount % 2 !== 0) {
    if (text.endsWith("```") || text.endsWith("```\n")) {
      return "Abrindo bloco de código...";
    }
    if (/interface\s+|type\s+|export\s+interface|struct\s+/i.test(last150)) {
      return "Escrevendo interfaces...";
    }
    if (/AudioContext|speechSynthesis|Audio\(|play\(|sound|mp3|wav|Tone\./i.test(last150)) {
      return "Escrevendo código do áudio...";
    }
    if (/<[a-z0-9]+|export\s+default\s+function|const\s+[A-Z]\w*\s*=/i.test(last150)) {
      return "Escrevendo sistemas...";
    }
    if (/import\s+|from\s+['"]/i.test(last150)) {
      return "Importando módulos...";
    }
    if (/function\s+|const\s+|let\s+|return\s+/i.test(last150)) {
      return "Desenvolvendo funções...";
    }
    return "Escrevendo bloco de código...";
  }

  // Check profanity / swearing
  if (/\b(porra|caralho|merda|puta|desgraça|maldito|cacete)\b/i.test(text)) {
    return "Xingando o usuário... 🤬";
  }

  // Check greetings / thanks / help
  if (/\b(obrigado|agradeço|prazer|disponível|estou aqui para ajudar|como posso ajudar|olá|oi|tudo bem)\b/i.test(last150)) {
    return "Ajudando o usuário...";
  }

  const lastLine = text.split("\n").pop() || "";
  if (lastLine.startsWith("- ") || lastLine.startsWith("* ") || lastLine.startsWith("1. ")) {
    return "Organizando resposta...";
  }

  return "Respondendo o usuário...";
}
