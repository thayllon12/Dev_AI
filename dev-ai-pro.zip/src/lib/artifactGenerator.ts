import { jsPDF } from "jspdf";
import * as docx from "docx";
import * as XLSX from "xlsx";
import pptxgen from "pptxgenjs";
import saveAs from "file-saver";

/**
 * Universal File Generator for Real Artifacts
 * Supports: .pdf, .docx, .pptx, .xlsx, .csv, .json, .txt, .html, .css, .js, .py, .zip, etc.
 */

export interface ArtifactFileOptions {
  title?: string;
  filename?: string;
  language?: string;
  content: string;
}

export async function generateAndDownloadFile(options: ArtifactFileOptions): Promise<void> {
  const { title = "Documento", content, language = "text" } = options;
  const lang = language.toLowerCase();
  const cleanTitle = (options.filename || title).replace(/[^a-zA-Z0-9_\-\.]/g, "_");

  // 1. PDF Generation
  if (lang === "pdf" || lang === "documento") {
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text(title, 14, 22);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    const splitText = doc.splitTextToSize(content, 180);
    doc.text(splitText, 14, 34);

    doc.save(`${cleanTitle.replace(/\.pdf$/i, "")}.pdf`);
    return;
  }

  // 2. PowerPoint (.pptx) Slide Generation
  if (lang === "pptx" || lang === "powerpoint" || lang === "slide" || lang === "slides") {
    const pres = new pptxgen();
    pres.layout = "LAYOUT_16x9";

    // Split content by slide markers like "---", "# Slide", "Slide [0-9]"
    const slideChunks = content
      .split(/(?:^|\n)(?:---|#+\s*Slide|\bSlide\s+\d+:?)/gi)
      .map(c => c.trim())
      .filter(Boolean);

    if (slideChunks.length === 0) {
      slideChunks.push(content);
    }

    slideChunks.forEach((chunk, index) => {
      const slide = pres.addSlide();
      
      // Set stylish dark/modern gradient background
      slide.background = { color: index === 0 ? "1E1E2E" : "181825" };

      const lines = chunk.split("\n").map(l => l.trim()).filter(Boolean);
      let slideTitle = lines[0] ? lines[0].replace(/^#+\s*/, "") : `Slide ${index + 1}`;
      let bodyLines = lines.slice(1);

      if (index === 0 && lines.length <= 3) {
        // Cover Slide
        slide.addText(slideTitle, {
          x: 0.8,
          y: 2.2,
          w: "85%",
          fontSize: 32,
          bold: true,
          color: "89B4FA",
          align: "center"
        });
        if (bodyLines.length > 0) {
          slide.addText(bodyLines.join("\n"), {
            x: 0.8,
            y: 3.5,
            w: "85%",
            fontSize: 18,
            color: "CDD6F4",
            align: "center"
          });
        }
      } else {
        // Standard Content Slide
        slide.addText(slideTitle, {
          x: 0.8,
          y: 0.6,
          w: "85%",
          fontSize: 24,
          bold: true,
          color: "89B4FA"
        });

        const bulletText = bodyLines.length > 0 
          ? bodyLines.map(l => ({ text: l.replace(/^[-*•]\s*/, ""), options: { bullet: true, color: "CDD6F4", fontSize: 14 } }))
          : [{ text: chunk, options: { color: "CDD6F4", fontSize: 14 } }];

        slide.addText(bulletText as any, {
          x: 0.8,
          y: 1.5,
          w: "85%",
          h: "70%",
          lineSpacing: 24
        });
      }
    });

    await pres.writeFile({ fileName: `${cleanTitle.replace(/\.pptx$/i, "")}.pptx` });
    return;
  }

  // 3. Word Document (.docx)
  if (lang === "docx" || lang === "word") {
    const paragraphs = content.split("\n\n").map(p => {
      const isHeader = p.startsWith("#");
      return new docx.Paragraph({
        children: [
          new docx.TextRun({
            text: p.replace(/^#+\s*/, ""),
            bold: isHeader,
            size: isHeader ? 28 : 22
          })
        ],
        spacing: { after: 200 }
      });
    });

    const docxDoc = new docx.Document({
      sections: [
        {
          properties: {},
          children: [
            new docx.Paragraph({
              children: [
                new docx.TextRun({
                  text: title,
                  bold: true,
                  size: 36,
                  color: "2B579A"
                })
              ],
              spacing: { after: 300 }
            }),
            ...paragraphs
          ]
        }
      ]
    });

    const blob = await docx.Packer.toBlob(docxDoc);
    saveAs(blob, `${cleanTitle.replace(/\.docx$/i, "")}.docx`);
    return;
  }

  // 4. Excel (.xlsx) or CSV
  if (lang === "xlsx" || lang === "excel" || lang === "csv") {
    let rows: any[] = [];
    
    // Try parse as JSON
    try {
      const parsed = JSON.parse(content);
      if (Array.isArray(parsed)) rows = parsed;
    } catch {
      // Parse CSV / Delimited lines
      const lines = content.split("\n").map(l => l.trim()).filter(Boolean);
      rows = lines.map(l => {
        if (l.includes("\t")) return l.split("\t");
        if (l.includes(";")) return l.split(";");
        return l.split(",");
      });
    }

    const ws = XLSX.utils.aoa_to_sheet(Array.isArray(rows[0]) ? rows : [rows]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");

    if (lang === "csv") {
      const csvOutput = XLSX.utils.sheet_to_csv(ws);
      const blob = new Blob([csvOutput], { type: "text/csv;charset=utf-8;" });
      saveAs(blob, `${cleanTitle.replace(/\.csv$/i, "")}.csv`);
    } else {
      XLSX.writeFile(wb, `${cleanTitle.replace(/\.xlsx$/i, "")}.xlsx`);
    }
    return;
  }

  // 5. Standard Text / Code / HTML / JS / Python / JSON Files
  const mimeTypes: Record<string, string> = {
    html: "text/html;charset=utf-8;",
    htm: "text/html;charset=utf-8;",
    css: "text/css;charset=utf-8;",
    js: "application/javascript;charset=utf-8;",
    javascript: "application/javascript;charset=utf-8;",
    ts: "application/typescript;charset=utf-8;",
    typescript: "application/typescript;charset=utf-8;",
    py: "text/x-python;charset=utf-8;",
    python: "text/x-python;charset=utf-8;",
    json: "application/json;charset=utf-8;",
    txt: "text/plain;charset=utf-8;",
    text: "text/plain;charset=utf-8;",
    md: "text/markdown;charset=utf-8;",
    markdown: "text/markdown;charset=utf-8;",
    xml: "application/xml;charset=utf-8;",
    svg: "image/svg+xml;charset=utf-8;",
    sh: "application/x-sh;charset=utf-8;",
    sql: "application/sql;charset=utf-8;"
  };

  const extensionMap: Record<string, string> = {
    javascript: "js",
    typescript: "ts",
    python: "py",
    html: "html",
    css: "css",
    json: "json",
    markdown: "md",
    text: "txt"
  };

  const ext = extensionMap[lang] || lang || "txt";
  const mime = mimeTypes[lang] || "text/plain;charset=utf-8;";
  const finalFilename = cleanTitle.includes(".") ? cleanTitle : `${cleanTitle}.${ext}`;

  const blob = new Blob([content], { type: mime });
  saveAs(blob, finalFilename);
}
