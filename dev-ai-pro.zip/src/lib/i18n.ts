export type SupportedLanguage = 'pt' | 'en' | 'es' | 'fr' | 'de' | 'it';

export interface Translations {
  appName: string;
  call: string;
  endCall: string;
  minimizeCall: string;
  audioMessage: string;
  message: string;
  replyingTo: string;
  cancel: string;
  stop: string;
  speaking: string;
  processing: string;
  listening: string;
  responding: string;
  paused: string;
  connectionError: string;
  connected: string;
  connecting: string;
  camera: string;
  screenShare: string;
  microphone: string;
  mute: string;
  unmute: string;
  history: string;
  branchChat: string;
  branchedFrom: string;
  settings: string;
  language: string;
  copied: string;
  preview: string;
  code: string;
  save: string;
  delete: string;
  rename: string;
  pin: string;
  unpin: string;
  newChat: string;
  search: string;
  exportChat: string;
  shareChat: string;
  send: string;
  typeMessage: string;
}

const translations: Record<SupportedLanguage, Translations> = {
  pt: {
    appName: "Dev AI",
    call: "Chamada",
    endCall: "Encerrar chamada",
    minimizeCall: "Minimizar chamada",
    audioMessage: "Áudio",
    message: "Mensagem",
    replyingTo: "Respondendo a",
    cancel: "Cancelar",
    stop: "Parar",
    speaking: "Falando...",
    processing: "Processando...",
    listening: "Ouvindo...",
    responding: "Respondendo...",
    paused: "Pausado",
    connectionError: "Erro de conexão",
    connected: "Conectado",
    connecting: "Conectando...",
    camera: "Câmera",
    screenShare: "Compartilhar tela",
    microphone: "Microfone",
    mute: "Silenciar",
    unmute: "Ativar som",
    history: "Histórico",
    branchChat: "Derivar chat",
    branchedFrom: "Chat derivado de",
    settings: "Configurações",
    language: "Idioma",
    copied: "Copiado para a área de transferência!",
    preview: "Ver prévia",
    code: "Código",
    save: "Salvar",
    delete: "Excluir",
    rename: "Renomear",
    pin: "Fixar",
    unpin: "Desfixar",
    newChat: "Nova conversa",
    search: "Pesquisar...",
    exportChat: "Exportar conversa",
    shareChat: "Compartilhar conversa",
    send: "Enviar",
    typeMessage: "Digite uma mensagem ou comando..."
  },
  en: {
    appName: "Dev AI",
    call: "Call",
    endCall: "End call",
    minimizeCall: "Minimize call",
    audioMessage: "Audio",
    message: "Message",
    replyingTo: "Replying to",
    cancel: "Cancel",
    stop: "Stop",
    speaking: "Speaking...",
    processing: "Processing...",
    listening: "Listening...",
    responding: "Responding...",
    paused: "Paused",
    connectionError: "Connection error",
    connected: "Connected",
    connecting: "Connecting...",
    camera: "Camera",
    screenShare: "Share screen",
    microphone: "Microphone",
    mute: "Mute",
    unmute: "Unmute",
    history: "History",
    branchChat: "Branch chat",
    branchedFrom: "Branch from",
    settings: "Settings",
    language: "Language",
    copied: "Copied to clipboard!",
    preview: "Preview",
    code: "Code",
    save: "Save",
    delete: "Delete",
    rename: "Rename",
    pin: "Pin",
    unpin: "Unpin",
    newChat: "New chat",
    search: "Search...",
    exportChat: "Export chat",
    shareChat: "Share chat",
    send: "Send",
    typeMessage: "Type a message or command..."
  },
  es: {
    appName: "Dev AI",
    call: "Llamada",
    endCall: "Finalizar llamada",
    minimizeCall: "Minimizar llamada",
    audioMessage: "Audio",
    message: "Mensaje",
    replyingTo: "Respondiendo a",
    cancel: "Cancelar",
    stop: "Detener",
    speaking: "Hablando...",
    processing: "Procesando...",
    listening: "Escuchando...",
    responding: "Respondiendo...",
    paused: "Pausado",
    connectionError: "Error de conexión",
    connected: "Conectado",
    connecting: "Conectando...",
    camera: "Cámara",
    screenShare: "Compartir pantalla",
    microphone: "Micrófono",
    mute: "Silenciar",
    unmute: "Activar sonido",
    history: "Historial",
    branchChat: "Derivar chat",
    branchedFrom: "Chat derivado de",
    settings: "Ajustes",
    language: "Idioma",
    copied: "¡Copiado al portapapeles!",
    preview: "Vista previa",
    code: "Código",
    save: "Guardar",
    delete: "Eliminar",
    rename: "Renombrar",
    pin: "Fijar",
    unpin: "Desfijar",
    newChat: "Nueva conversación",
    search: "Buscar...",
    exportChat: "Exportar chat",
    shareChat: "Compartir chat",
    send: "Enviar",
    typeMessage: "Escribe un mensaje o comando..."
  },
  fr: {
    appName: "Dev AI",
    call: "Appel",
    endCall: "Terminer l'appel",
    minimizeCall: "Réduire l'appel",
    audioMessage: "Audio",
    message: "Message",
    replyingTo: "En réponse à",
    cancel: "Annuler",
    stop: "Arrêter",
    speaking: "En train de parler...",
    processing: "Traitement...",
    listening: "À l'écoute...",
    responding: "Répond...",
    paused: "En pause",
    connectionError: "Erreur de connexion",
    connected: "Connecté",
    connecting: "Connexion...",
    camera: "Caméra",
    screenShare: "Partager l'écran",
    microphone: "Microphone",
    mute: "Muet",
    unmute: "Activer le son",
    history: "Historique",
    branchChat: "Dériver le chat",
    branchedFrom: "Chat dérivé de",
    settings: "Paramètres",
    language: "Langue",
    copied: "Copié dans le presse-papiers !",
    preview: "Aperçu",
    code: "Code",
    save: "Enregistrer",
    delete: "Supprimer",
    rename: "Renommer",
    pin: "Épingler",
    unpin: "Désépingler",
    newChat: "Nouveau chat",
    search: "Rechercher...",
    exportChat: "Exporter le chat",
    shareChat: "Partager le chat",
    send: "Envoyer",
    typeMessage: "Tapez un message..."
  },
  de: {
    appName: "Dev AI",
    call: "Anruf",
    endCall: "Anruf beenden",
    minimizeCall: "Anruf minimieren",
    audioMessage: "Audio",
    message: "Nachricht",
    replyingTo: "Antwort an",
    cancel: "Abbrechen",
    stop: "Stopp",
    speaking: "Spricht...",
    processing: "Verarbeitung...",
    listening: "Zuhören...",
    responding: "Antwortet...",
    paused: "Pausiert",
    connectionError: "Verbindungsfehler",
    connected: "Verbunden",
    connecting: "Verbinden...",
    camera: "Kamera",
    screenShare: "Bildschirm teilen",
    microphone: "Mikrofon",
    mute: "Stummschalten",
    unmute: "Ton an",
    history: "Verlauf",
    branchChat: "Chat abzweigen",
    branchedFrom: "Chat abgeleitet von",
    settings: "Einstellungen",
    language: "Sprache",
    copied: "In die Zwischenablage kopiert!",
    preview: "Vorschau",
    code: "Code",
    save: "Speichern",
    delete: "Löschen",
    rename: "Umbenennen",
    pin: "Anheften",
    unpin: "Lösen",
    newChat: "Neuer Chat",
    search: "Suchen...",
    exportChat: "Chat exportieren",
    shareChat: "Chat teilen",
    send: "Senden",
    typeMessage: "Nachricht eingeben..."
  },
  it: {
    appName: "Dev AI",
    call: "Chiamata",
    endCall: "Termina chiamata",
    minimizeCall: "Riduci a icona",
    audioMessage: "Audio",
    message: "Messaggio",
    replyingTo: "Rispondendo a",
    cancel: "Annulla",
    stop: "Ferma",
    speaking: "Parla...",
    processing: "Elaborazione...",
    listening: "In ascolto...",
    responding: "Risponde...",
    paused: "In pausa",
    connectionError: "Errore di connessione",
    connected: "Connesso",
    connecting: "Connessione...",
    camera: "Fotocamera",
    screenShare: "Condividi schermo",
    microphone: "Microfono",
    mute: "Silenzia",
    unmute: "Riattiva audio",
    history: "Cronologia",
    branchChat: "Deriva chat",
    branchedFrom: "Chat derivata da",
    settings: "Impostazioni",
    language: "Lingua",
    copied: "Copiato negli appunti!",
    preview: "Anteprima",
    code: "Codice",
    save: "Salva",
    delete: "Elimina",
    rename: "Rinomina",
    pin: "Fissa",
    unpin: "Sblocca",
    newChat: "Nuova chat",
    search: "Cerca...",
    exportChat: "Esporta chat",
    shareChat: "Condividi chat",
    send: "Invia",
    typeMessage: "Scrivi un messaggio..."
  }
};

export function detectSystemLanguage(): SupportedLanguage {
  try {
    const lang = (navigator.language || (navigator as any).userLanguage || 'pt').toLowerCase();
    if (lang.startsWith('pt')) return 'pt';
    if (lang.startsWith('es')) return 'es';
    if (lang.startsWith('fr')) return 'fr';
    if (lang.startsWith('de')) return 'de';
    if (lang.startsWith('it')) return 'it';
    if (lang.startsWith('en')) return 'en';
  } catch (e) {}
  return 'pt';
}

export function getTranslations(lang?: string): Translations {
  const code = (lang || detectSystemLanguage()) as SupportedLanguage;
  return translations[code] || translations.pt;
}
