import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  ScreenShare, 
  X, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  RefreshCw,
  Send,
  MessageSquare,
  Radio,
  Share2
} from 'lucide-react';
import { toast } from 'sonner';

interface GeminiLiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendTranscriptToChat?: (userText: string, aiText: string) => void;
  conversationContext?: string;
}

export const GeminiLiveModal: React.FC<GeminiLiveModalProps> = ({ 
  isOpen, 
  onClose,
  onSendTranscriptToChat,
  conversationContext = ""
}) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isSpeakerMuted, setIsSpeakerMuted] = useState(false);
  const [micPermissionDenied, setMicPermissionDenied] = useState(false);

  // Transcripts
  const [userTranscript, setUserTranscript] = useState<string>('');
  const [aiTranscript, setAiTranscript] = useState<string>('');
  const [recentTranscripts, setRecentTranscripts] = useState<Array<{ sender: 'user' | 'model'; text: string; time: string }>>([]);

  // Audio level visualizers
  const [userAudioLevel, setUserAudioLevel] = useState<number>(0);
  const [aiAudioLevel, setAiAudioLevel] = useState<number>(0);

  // References
  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const videoPreviewRef = useRef<HTMLVideoElement | null>(null);
  const screenPreviewRef = useRef<HTMLVideoElement | null>(null);
  const frameIntervalRef = useRef<any>(null);
  const audioWorkletOrProcessorRef = useRef<any>(null);
  const nextPlayTimeRef = useRef<number>(0);
  const audioSourceNodesRef = useRef<AudioBufferSourceNode[]>([]);
  const transcriptScrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll transcript container
  useEffect(() => {
    if (transcriptScrollRef.current) {
      transcriptScrollRef.current.scrollTop = transcriptScrollRef.current.scrollHeight;
    }
  }, [userTranscript, aiTranscript, recentTranscripts]);

  // Stop playback when interrupted
  const stopAllAudioPlayback = useCallback(() => {
    try {
      audioSourceNodesRef.current.forEach(node => {
        try { node.stop(); } catch (e) {}
      });
      audioSourceNodesRef.current = [];
      if (outputAudioCtxRef.current) {
        nextPlayTimeRef.current = outputAudioCtxRef.current.currentTime;
      }
      setAiAudioLevel(0);
    } catch (e) {
      console.warn("Error stopping audio playback:", e);
    }
  }, []);

  // Play incoming 24kHz PCM audio chunk from Gemini Live
  const playPcmAudioChunk = useCallback((base64Data: string) => {
    if (isSpeakerMuted) return;
    try {
      if (!outputAudioCtxRef.current || outputAudioCtxRef.current.state === 'closed') {
        outputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      const ctx = outputAudioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Decode base64 to binary PCM
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert 16-bit PCM to Float32
      const pcm16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(pcm16.length);
      let sumSquares = 0;
      for (let i = 0; i < pcm16.length; i++) {
        float32[i] = pcm16[i] / 32768.0;
        sumSquares += float32[i] * float32[i];
      }

      const rms = Math.sqrt(sumSquares / (pcm16.length || 1));
      setAiAudioLevel(Math.min(100, Math.round(rms * 400)));

      const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
      audioBuffer.getChannelData(0).set(float32);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);

      const now = ctx.currentTime;
      const startTime = Math.max(now, nextPlayTimeRef.current);
      source.start(startTime);
      nextPlayTimeRef.current = startTime + audioBuffer.duration;

      audioSourceNodesRef.current.push(source);
      source.onended = () => {
        audioSourceNodesRef.current = audioSourceNodesRef.current.filter(n => n !== source);
        if (audioSourceNodesRef.current.length === 0) {
          setAiAudioLevel(0);
        }
      };
    } catch (err) {
      console.error("Error playing PCM chunk:", err);
    }
  }, [isSpeakerMuted]);

  // Convert Float32 mic buffer to 16-bit PCM base64 (16kHz)
  const floatTo16BitPCMBase64 = (input: Float32Array): string => {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    let binary = '';
    const bytes = new Uint8Array(output.buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  // Start Gemini Live connection
  const startLiveSession = async () => {
    setIsConnecting(true);
    setMicPermissionDenied(false);
    try {
      // 1. Setup Audio Input with robust fallback constraints
      let micStream: MediaStream;
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
          }
        });
      } catch (e) {
        // Fallback with basic audio
        micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }
      micStreamRef.current = micStream;

      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      if (audioCtx.state === 'suspended') {
        await audioCtx.resume();
      }
      inputAudioCtxRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(micStream);
      const processor = audioCtx.createScriptProcessor(2048, 1, 1);
      audioWorkletOrProcessorRef.current = processor;

      // 2. Connect WebSocket
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/gemini-live-ws`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnecting(false);
        setIsConnected(true);
        toast.success("Conectado ao Gemini 3.1 Flash Live (Voz Charon)");

        // Send initial config with Charon voice and optional recent chat context
        ws.send(JSON.stringify({
          type: 'init',
          voice: 'Charon',
          model: 'gemini-3.1-flash-live-preview',
          context: conversationContext ? `CONTEXTO DA CONVERSA ANTERIOR DO CHAT:\n${conversationContext.slice(-2000)}` : undefined
        }));
      };

      processor.onaudioprocess = (e) => {
        if (isMuted || ws.readyState !== WebSocket.OPEN) return;
        const inputData = e.inputBuffer.getChannelData(0);
        
        // Calculate volume
        let sum = 0;
        for (let i = 0; i < inputData.length; i++) {
          sum += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sum / inputData.length);
        setUserAudioLevel(Math.min(100, Math.round(rms * 400)));

        const base64Audio = floatTo16BitPCMBase64(inputData);
        ws.send(JSON.stringify({
          type: 'realtime_input',
          audio: base64Audio
        }));
      };

      source.connect(processor);
      processor.connect(audioCtx.destination);

      // Handle incoming messages
      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'audio' && msg.audio) {
            playPcmAudioChunk(msg.audio);
          }

          if (msg.type === 'interrupted') {
            stopAllAudioPlayback();
          }

          if (msg.type === 'input_transcription' && msg.text) {
            setUserTranscript(prev => (prev ? prev + ' ' : '') + msg.text);
            if (msg.isFinal) {
              setRecentTranscripts(prev => [...prev.slice(-20), { sender: 'user', text: msg.text, time: new Date().toLocaleTimeString() }]);
            }
          }

          if (msg.type === 'output_transcription' && msg.text) {
            setAiTranscript(prev => prev + msg.text);
            if (msg.isFinal) {
              setRecentTranscripts(prev => [...prev.slice(-20), { sender: 'model', text: msg.text, time: new Date().toLocaleTimeString() }]);
            }
          }
        } catch (e) {
          console.error("Error processing websocket message:", e);
        }
      };

      ws.onerror = (err) => {
        console.error("WebSocket error:", err);
        toast.error("Erro na conexão com o Gemini Live.");
      };

      ws.onclose = () => {
        setIsConnected(false);
        setIsConnecting(false);
      };

    } catch (err: any) {
      console.error("Failed to start Live session:", err);
      setIsConnecting(false);
      setMicPermissionDenied(true);
      toast.error(`Falha ao acessar o microfone: ${err.message || 'Permissão negada'}`);
    }
  };

  // Toggle Camera
  const toggleCamera = async () => {
    if (isCameraActive) {
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach(t => t.stop());
        cameraStreamRef.current = null;
      }
      if (videoPreviewRef.current) {
        videoPreviewRef.current.srcObject = null;
      }
      setIsCameraActive(false);
      if (!isScreenSharing && frameIntervalRef.current) {
        clearInterval(frameIntervalRef.current);
        frameIntervalRef.current = null;
      }
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: "user" }
      });
      cameraStreamRef.current = stream;
      if (videoPreviewRef.current) {
        videoPreviewRef.current.srcObject = stream;
      }
      setIsCameraActive(true);
      startVideoFrameStreaming();
      toast.success("Câmera ativada.");
    } catch (err: any) {
      console.error("Error starting camera:", err);
      toast.error("Não foi possível acessar a câmera.");
    }
  };

  // Toggle Screen Share
  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(t => t.stop());
        screenStreamRef.current = null;
      }
      if (screenPreviewRef.current) {
        screenPreviewRef.current.srcObject = null;
      }
      setIsScreenSharing(false);
      if (!isCameraActive && frameIntervalRef.current) {
        clearInterval(frameIntervalRef.current);
        frameIntervalRef.current = null;
      }
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 5 }
      });
      screenStreamRef.current = stream;
      if (screenPreviewRef.current) {
        screenPreviewRef.current.srcObject = stream;
      }
      setIsScreenSharing(true);

      stream.getVideoTracks()[0].onended = () => {
        setIsScreenSharing(false);
      };

      startVideoFrameStreaming();
      toast.success("Compartilhamento de tela ativado.");
    } catch (err: any) {
      console.error("Error sharing screen:", err);
      toast.error("Não foi possível compartilhar a tela.");
    }
  };

  // Capture and stream video frames to Gemini Live (1-2 FPS JPEG)
  const startVideoFrameStreaming = () => {
    if (frameIntervalRef.current) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    frameIntervalRef.current = setInterval(() => {
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

      const activeVideo = isScreenSharing ? screenPreviewRef.current : (isCameraActive ? videoPreviewRef.current : null);
      if (!activeVideo || activeVideo.videoWidth === 0) return;

      canvas.width = Math.min(640, activeVideo.videoWidth);
      canvas.height = Math.min(480, activeVideo.videoHeight);
      ctx?.drawImage(activeVideo, 0, 0, canvas.width, canvas.height);

      const base64Jpeg = canvas.toDataURL('image/jpeg', 0.6).split(',')[1];
      if (base64Jpeg) {
        wsRef.current.send(JSON.stringify({
          type: 'realtime_input',
          video: base64Jpeg
        }));
      }
    }, 1000);
  };

  // Sync back to main text chat if desired
  const handleSaveToChat = () => {
    if (recentTranscripts.length === 0) {
      toast.info("Nenhuma conversa para salvar no chat.");
      return;
    }
    const fullTranscript = recentTranscripts
      .map(t => `${t.sender === 'user' ? '👤 Você' : '🤖 Gemini Live'}: ${t.text}`)
      .join('\n\n');
    
    if (onSendTranscriptToChat) {
      onSendTranscriptToChat("Transcrição da chamada ao vivo com Gemini Live", fullTranscript);
      toast.success("Transcrição adicionada à conversa principal!");
    } else {
      navigator.clipboard.writeText(fullTranscript);
      toast.success("Transcrição copiada para a área de transferência!");
    }
  };

  // Close cleanup
  const cleanup = useCallback(() => {
    if (wsRef.current) {
      try { wsRef.current.close(); } catch (e) {}
      wsRef.current = null;
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(t => t.stop());
      micStreamRef.current = null;
    }
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach(t => t.stop());
      cameraStreamRef.current = null;
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
      screenStreamRef.current = null;
    }
    if (inputAudioCtxRef.current) {
      try { inputAudioCtxRef.current.close(); } catch (e) {}
      inputAudioCtxRef.current = null;
    }
    if (outputAudioCtxRef.current) {
      try { outputAudioCtxRef.current.close(); } catch (e) {}
      outputAudioCtxRef.current = null;
    }
    if (frameIntervalRef.current) {
      clearInterval(frameIntervalRef.current);
      frameIntervalRef.current = null;
    }
    stopAllAudioPlayback();
    setIsConnected(false);
    setIsConnecting(false);
  }, [stopAllAudioPlayback]);

  useEffect(() => {
    if (isOpen) {
      startLiveSession();
    } else {
      cleanup();
    }
    return () => {
      cleanup();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[99999] bg-[#0d0d11]/95 backdrop-blur-2xl flex flex-col items-center justify-between p-3 sm:p-6 overflow-hidden select-none">
        
        {/* Top Header */}
        <div className="w-full max-w-4xl flex items-center justify-between z-10 shrink-0 pb-2 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/20 border border-primary/40 rounded-2xl flex items-center justify-center text-primary shadow-[0_0_20px_rgba(59,130,246,0.3)]">
              <Radio size={20} className="animate-pulse text-red-500" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-wide">
                  Gemini 3.1 Flash Live
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-primary/20 text-primary border border-primary/30 uppercase tracking-wider">
                  Voz Charon
                </span>
              </div>
              <p className="text-xs text-text-muted">
                {isConnected ? (
                  <span className="text-emerald-400 flex items-center gap-1.5 font-medium">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                    Ao vivo com áudio bidirecional e contexto contínuo
                  </span>
                ) : isConnecting ? (
                  <span className="text-amber-400 flex items-center gap-1.5 font-medium">
                    <RefreshCw size={12} className="animate-spin" /> Conectando ao Gemini Live...
                  </span>
                ) : (
                  <span className="text-red-400">Desconectado</span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveToChat}
              className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 hover:text-white border border-white/10 transition-colors flex items-center gap-1.5 text-xs"
              title="Salvar transcrição no chat"
            >
              <Share2 size={16} />
              <span className="hidden sm:inline">Salvar no Chat</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all border border-white/10 active:scale-95"
              title="Fechar"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Center Main Stage (Mobile-First Layout with Responsive Grid) */}
        <div className="w-full max-w-4xl flex-1 my-3 flex flex-col gap-3 min-h-0 relative overflow-hidden">
          
          {/* Visual Feeds Grid (User Visualizer + AI Voice Orb Aura) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 min-h-[160px] sm:min-h-[220px] max-h-[38vh] shrink-0">
            
            {/* User Presence & Visualizer */}
            <div className="bg-[#18181c] border border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center relative overflow-hidden shadow-xl backdrop-blur-md">
              {/* Dynamic User Speaking Aura */}
              <div 
                className="absolute w-36 h-36 rounded-full bg-primary/25 blur-3xl transition-all duration-150 pointer-events-none"
                style={{ transform: `scale(${1 + userAudioLevel / 35})` }}
              />

              {isCameraActive ? (
                <div className="w-full h-full relative rounded-xl overflow-hidden bg-black flex items-center justify-center">
                  <video ref={videoPreviewRef} autoPlay playsInline muted className="w-full h-full object-cover -scale-x-100" />
                  <span className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/60 backdrop-blur-md rounded-md text-[10px] font-bold text-white">
                    Sua Câmera
                  </span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2.5 z-10">
                  <div className="relative">
                    <div 
                      className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center shadow-lg transition-transform duration-100 ${
                        isMuted ? 'bg-red-500/20 border border-red-500/40 text-red-400' : 'bg-gradient-to-tr from-primary to-indigo-500 text-white'
                      }`}
                      style={{ transform: `scale(${isMuted ? 1 : 1 + userAudioLevel / 80})` }}
                    >
                      {isMuted ? <MicOff size={28} /> : <Mic size={28} />}
                    </div>
                    {userAudioLevel > 10 && !isMuted && (
                      <span className="absolute inset-0 rounded-full border-2 border-primary animate-ping pointer-events-none" />
                    )}
                  </div>
                  <span className="text-xs font-bold text-white/70">
                    {micPermissionDenied 
                      ? "Permissão de microfone negada" 
                      : isMuted ? "Seu microfone está silenciado" : "Você está falando..."}
                  </span>
                </div>
              )}
            </div>

            {/* AI Avatar Presence / Screen Share */}
            <div className="bg-[#18181c] border border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center relative overflow-hidden shadow-xl backdrop-blur-md">
              {/* Dynamic AI Voice Aura */}
              <div 
                className="absolute w-44 h-44 rounded-full bg-indigo-500/30 blur-3xl transition-all duration-150 pointer-events-none"
                style={{ transform: `scale(${1 + aiAudioLevel / 30})` }}
              />

              {isScreenSharing ? (
                <div className="w-full h-full relative rounded-xl overflow-hidden bg-black flex items-center justify-center">
                  <video ref={screenPreviewRef} autoPlay playsInline muted className="w-full h-full object-contain" />
                  <span className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/60 backdrop-blur-md rounded-md text-[10px] font-bold text-white">
                    Tela Compartilhada
                  </span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2.5 z-10">
                  <div className="relative">
                    <div 
                      className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center shadow-xl transition-transform duration-100 border-2 border-white/20"
                      style={{ transform: `scale(${1 + aiAudioLevel / 60})` }}
                    >
                      <Sparkles size={36} className="text-white animate-pulse" />
                    </div>
                    {aiAudioLevel > 10 && (
                      <span className="absolute -inset-2 rounded-full border-2 border-indigo-400 animate-ping pointer-events-none" />
                    )}
                  </div>
                  <span className="text-xs font-bold text-white tracking-wide">
                    {aiAudioLevel > 5 ? "Gemini falando..." : "Gemini 3.1 Flash (Charon)"}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Real-time Subtitles & Conversation Stream */}
          <div className="flex-1 bg-[#141418] border border-white/10 rounded-2xl p-3 sm:p-4 flex flex-col min-h-0 overflow-hidden backdrop-blur-md">
            <div className="text-[11px] font-bold uppercase tracking-wider text-white/50 pb-2 border-b border-white/10 flex items-center justify-between shrink-0">
              <span className="flex items-center gap-1.5">
                <MessageSquare size={14} className="text-primary" />
                Transcrição em Tempo Real
              </span>
              <span className="text-[11px] text-emerald-400 font-mono font-medium">Sincronizado</span>
            </div>

            <div ref={transcriptScrollRef} className="flex-1 overflow-y-auto custom-scrollbar pt-2.5 space-y-2 text-sm">
              {/* Dynamic live user speaking display */}
              {userTranscript && (
                <div className="flex items-start gap-2 bg-primary/10 border border-primary/20 rounded-xl p-2.5">
                  <span className="px-2 py-0.5 bg-primary/20 text-primary font-bold text-[10px] rounded-md shrink-0 uppercase">
                    Você
                  </span>
                  <p className="text-white text-xs sm:text-sm leading-relaxed">
                    {userTranscript}
                  </p>
                </div>
              )}

              {/* Dynamic live AI response display */}
              {aiTranscript && (
                <div className="flex items-start gap-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-2.5">
                  <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-bold text-[10px] rounded-md shrink-0 uppercase">
                    Gemini
                  </span>
                  <p className="text-white text-xs sm:text-sm leading-relaxed">
                    {aiTranscript}
                  </p>
                </div>
              )}

              {/* History of completed turns */}
              {recentTranscripts.map((t, idx) => (
                <div 
                  key={idx} 
                  className={`flex items-start gap-2 p-2 rounded-xl text-xs ${
                    t.sender === 'user' ? 'bg-white/5 text-white/80' : 'bg-primary/10 text-white'
                  }`}
                >
                  <span className="font-bold text-[10px] uppercase text-white/40 shrink-0">
                    {t.sender === 'user' ? 'Você:' : 'Gemini:'}
                  </span>
                  <span className="flex-1 leading-relaxed">{t.text}</span>
                  <span className="text-[9px] text-white/30 font-mono shrink-0">{t.time}</span>
                </div>
              ))}

              {!userTranscript && !aiTranscript && recentTranscripts.length === 0 && (
                <div className="h-full flex items-center justify-center text-white/40 text-xs italic text-center p-4">
                  Fale com a IA em tempo real. A conversa continuará o contexto do chat e todas as falas serão transcritas aqui.
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Bottom Floating Control Bar */}
        <div className="w-full max-w-xl bg-[#1c1c22] border border-white/10 rounded-full p-2 flex items-center justify-around shadow-2xl backdrop-blur-2xl z-20 shrink-0">
          
          {/* Mute / Unmute Mic */}
          <button
            onClick={() => {
              setIsMuted(!isMuted);
              toast(isMuted ? "Microfone reativado" : "Microfone silenciado");
            }}
            className={`p-3 rounded-full transition-all flex items-center justify-center active:scale-95 ${
              isMuted 
                ? "bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30" 
                : "bg-white/10 text-white hover:bg-white/20 border border-white/10"
            }`}
            title={isMuted ? "Ativar Microfone" : "Silenciar Microfone"}
          >
            {isMuted ? <MicOff size={20} /> : <Mic size={20} />}
          </button>

          {/* Toggle Camera */}
          <button
            onClick={toggleCamera}
            className={`p-3 rounded-full transition-all flex items-center justify-center active:scale-95 ${
              isCameraActive 
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30" 
                : "bg-white/10 text-white hover:bg-white/20 border border-white/10"
            }`}
            title={isCameraActive ? "Desativar Câmera" : "Ativar Câmera"}
          >
            {isCameraActive ? <Video size={20} /> : <VideoOff size={20} />}
          </button>

          {/* Toggle Screen Share */}
          <button
            onClick={toggleScreenShare}
            className={`p-3 rounded-full transition-all flex items-center justify-center active:scale-95 ${
              isScreenSharing 
                ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 hover:bg-indigo-500/30" 
                : "bg-white/10 text-white hover:bg-white/20 border border-white/10"
            }`}
            title={isScreenSharing ? "Parar Compartilhamento" : "Compartilhar Tela"}
          >
            <ScreenShare size={20} />
          </button>

          {/* Mute AI Speaker */}
          <button
            onClick={() => {
              setIsSpeakerMuted(!isSpeakerMuted);
              if (!isSpeakerMuted) stopAllAudioPlayback();
              toast(isSpeakerMuted ? "Áudio da IA ativado" : "Áudio da IA silenciado");
            }}
            className={`p-3 rounded-full transition-all flex items-center justify-center active:scale-95 ${
              isSpeakerMuted 
                ? "bg-amber-500/20 text-amber-400 border border-amber-500/30 hover:bg-amber-500/30" 
                : "bg-white/10 text-white hover:bg-white/20 border border-white/10"
            }`}
            title={isSpeakerMuted ? "Ouvir IA" : "Silenciar Áudio da IA"}
          >
            {isSpeakerMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>

          {/* End Call / Close */}
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-full bg-red-600 hover:bg-red-500 text-white font-bold text-xs transition-all shadow-lg active:scale-95 flex items-center gap-1.5"
          >
            Encerrar
          </button>

        </div>

      </div>
    </AnimatePresence>
  );
};
