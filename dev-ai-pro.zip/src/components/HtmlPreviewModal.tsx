import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { X, RefreshCw, Terminal, Maximize2, Minimize2, Play, UserPlus, Users } from 'lucide-react';
import { toast } from 'sonner';
import { getSocket } from '../lib/socket';
import { db } from '../firebase';
import { doc, setDoc } from 'firebase/firestore';

interface HtmlPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  code: string;
  chatId?: string | null;
  isGenerating?: boolean;
}

export const HtmlPreviewModal: React.FC<HtmlPreviewModalProps> = ({ isOpen, onClose, code, chatId, isGenerating }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showConsole, setShowConsole] = useState(false);
  const [logs, setLogs] = useState<{ type: string; message: string }[]>([]);
  const [snapshottedCode, setSnapshottedCode] = useState(code);
  
  useEffect(() => {
    if (isOpen && !isGenerating) {
      setSnapshottedCode(code);
    }
  }, [code, isGenerating, isOpen]);
  
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [key, setKey] = useState(0);

  useEffect(() => {
    const handleFsChange = () => {
      if (!document.fullscreenElement) {
        setIsFullscreen(false);
      } else {
        setIsFullscreen(true);
      }
    };
    document.addEventListener("fullscreenchange", handleFsChange);
    document.addEventListener("webkitfullscreenchange", handleFsChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFsChange);
      document.removeEventListener("webkitfullscreenchange", handleFsChange);
    };
  }, []);

  const isMultiplayerDetected = Boolean(
    snapshottedCode && (
      snapshottedCode.includes("DevMultiplayer") ||
      snapshottedCode.includes("multiplayer") ||
      snapshottedCode.includes("room_main") ||
      snapshottedCode.includes("BroadcastChannel") ||
      snapshottedCode.includes("socket")
    )
  );

  const [onlinePlayersCount, setOnlinePlayersCount] = useState(1);
  const myPlayerIdRef = useRef('player_' + Math.random().toString(36).substring(2, 7));

  useEffect(() => {
    if (isOpen) {
      setLogs([]);
      setKey(k => k + 1);
      
      const socket = getSocket();
      
      if (chatId) {
        socket.emit('join-chat', chatId);
      }

      const handleHtmlSync = (data: any) => {
        // Forward the sync data to the iframe
        if (data.payload && data.payload.sender) {
          iframeRef.current?.contentWindow?.postMessage({
            type: 'MULTIPLAYER_FORWARD',
            payload: data.payload
          }, '*');
        }
      };

      socket.on('html-sync', handleHtmlSync);

      // Manage browser back button
      window.history.pushState({ htmlPreviewOpen: true }, '', window.location.href);
      const handlePopState = (e: PopStateEvent) => {
        onClose();
      };
      window.addEventListener('popstate', handlePopState);
      
      return () => {
        socket.off('html-sync', handleHtmlSync);
        if (chatId) {
          socket.emit('leave-chat', chatId);
        }
        window.removeEventListener('popstate', handlePopState);
      };
    }
  }, [isOpen, code, onClose, chatId]);

  useEffect(() => {
    const handleMessage = async (event: MessageEvent) => {
      if (event.data?.type === 'CONSOLE_LOG') {
        setLogs(prev => [...prev, { type: event.data.level, message: event.data.args.join(' ') }]);
      } else if (event.data?.type === 'CONSOLE_ERROR') {
        setLogs(prev => [...prev, { type: 'error', message: event.data.message }]);
      } else if (event.data?.type === 'MULTIPLAYER_SYNC' && event.data?.payload) {
        // Broadcast the event using Socket.io
        try {
          if (chatId) {
            const socket = getSocket();
            socket.emit('html-sync', { chatId, payload: event.data.payload });
          }
        } catch (err) {
          console.warn('Failed to sync multiplayer to socket:', err);
        }
      }
    };
    
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  useEffect(() => {
    const handleFullscreenChange = () => {
      if (!document.fullscreenElement) {
        setIsFullscreen(false);
      }
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const handleReload = () => {
    setLogs([]);
    setKey(k => k + 1);
  };

  const handleInvitePlayer = async () => {
    try {
      const shareUrl = window.location.href;
      try {
        await navigator.clipboard.writeText(shareUrl);
      } catch (clipErr) {
        console.warn("Clipboard fallback:", clipErr);
      }
      toast.success("🎮 Link da partida copiado! Convite enviado para todos do chat!");

      // Enviar sinal de convite via Firestore room
      try {
        const inviteDoc = doc(db, 'multiplayer_rooms', 'room_main', 'signals', 'invite_' + Date.now());
        await setDoc(inviteDoc, {
          sender: 'Host',
          data: { type: 'GAME_INVITE', message: 'O host te convidou para jogar em tempo real!' },
          time: Date.now(),
          updatedAt: Date.now()
        });
      } catch (e) {
        console.warn("Invite signal failed:", e);
      }

      // Notificação do sistema do celular / navegador
      if ("Notification" in window) {
        if (Notification.permission === "granted") {
          new Notification("🎮 Convite para Partida Dev AI", {
            body: "O host convidou você para jogar em tempo real!",
            icon: "/favicon.ico"
          });
        } else if (Notification.permission !== "denied") {
          Notification.requestPermission().then(permission => {
            if (permission === "granted") {
              new Notification("🎮 Convite para Partida Dev AI", {
                body: "O host convidou você para jogar em tempo real!",
                icon: "/favicon.ico"
              });
            }
          });
        }
      }
    } catch (err) {
      toast.info("Link da partida gerado! Copie a URL para convidar amigos.");
    }
  };

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      try { containerRef.current?.requestFullscreen?.(); } catch(e){}
      setIsFullscreen(true);
    } else {
      try { document.exitFullscreen?.(); } catch(e){}
      setIsFullscreen(false);
    }
  };

  const getHtmlWithConsoleHook = () => {
    const hookScript = `
      <script>
        (function() {
          const originalConsoleLog = console.log;
          const originalConsoleError = console.error;
          const originalConsoleWarn = console.warn;
          const originalConsoleInfo = console.info;

          console.log = function(...args) {
            window.parent.postMessage({ type: 'CONSOLE_LOG', level: 'log', args: args.map(String) }, '*');
            originalConsoleLog.apply(console, args);
          };
          console.error = function(...args) {
            window.parent.postMessage({ type: 'CONSOLE_LOG', level: 'error', args: args.map(String) }, '*');
            originalConsoleError.apply(console, args);
          };
          console.warn = function(...args) {
            window.parent.postMessage({ type: 'CONSOLE_LOG', level: 'warn', args: args.map(String) }, '*');
            originalConsoleWarn.apply(console, args);
          };
          console.info = function(...args) {
            window.parent.postMessage({ type: 'CONSOLE_LOG', level: 'info', args: args.map(String) }, '*');
            originalConsoleInfo.apply(console, args);
          };
          window.onerror = function(message, source, lineno, colno, error) {
            window.parent.postMessage({ type: 'CONSOLE_ERROR', message: message + " at line " + lineno }, '*');
            return false;
          };

          // --- DevAI Multiplayer Engine (BroadcastChannel + LocalStorage Sync) ---
          const roomId = 'dev_ai_mp_' + (window.location.pathname || 'room');
          let bc;
          try {
            if (typeof BroadcastChannel !== 'undefined') {
              bc = new BroadcastChannel(roomId);
            }
          } catch(e) {}

          const pId = 'p_' + Math.random().toString(36).substring(2, 7);

          window.DevMultiplayer = {
            playerId: pId,
            roomId: roomId,
            send: function(data) {
              const payload = { sender: pId, data, time: Date.now() };
              if (bc) {
                try { bc.postMessage(payload); } catch(err) {}
              }
              try {
                localStorage.setItem('dev_ai_mp_sync', JSON.stringify(payload));
              } catch(err) {}
              window.parent.postMessage({ type: 'MULTIPLAYER_SYNC', payload }, '*');
            },
            onMessage: function(callback) {
              if (bc) {
                bc.onmessage = (e) => {
                  if (e.data && e.data.sender !== pId) {
                    callback(e.data.data, e.data.sender);
                  }
                };
              }
              window.addEventListener('storage', (e) => {
                if (e.key === 'dev_ai_mp_sync' && e.newValue) {
                  try {
                    const payload = JSON.parse(e.newValue);
                    if (payload && payload.sender !== pId) {
                      callback(payload.data, payload.sender);
                    }
                  } catch(err){}
                }
              });
              window.addEventListener('message', (e) => {
                if (e.data && e.data.type === 'MULTIPLAYER_FORWARD' && e.data.payload && e.data.payload.sender !== pId) {
                  callback(e.data.payload.data, e.data.payload.sender);
                }
              });
            }
          };
        })();
      </script>
    `;
    return `<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    ${hookScript}
  </head>
  <body>
    ${snapshottedCode.replace(/<!DOCTYPE html>/i, '').replace(/<html>/i, '').replace(/<\/html>/i, '')}
  </body>
</html>`;
  };

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className={`fixed inset-0 ${isFullscreen ? '!z-[99999] !w-screen !h-screen !m-0 !p-0 !max-w-none !max-h-none' : 'z-[999]'} flex flex-col bg-white`}
        >
          <div 
            ref={containerRef}
            className="w-full h-full flex flex-col bg-white overflow-hidden relative"
          >
            {/* Header / Actions Menu */}
            <div className={`flex-none bg-[#1e1e1e] p-2 items-center justify-between z-10 text-white ${isFullscreen ? 'hidden' : 'flex'}`}>
               <div className="flex items-center gap-2 px-2">
                 <span className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 text-xs font-semibold border border-emerald-500/30 shadow-sm">
                   <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                   <span>{onlinePlayersCount} {onlinePlayersCount === 1 ? 'jogando' : 'jogando'}</span>
                 </span>
               </div>
               
               <div className="flex items-center gap-2 text-white/80">
                 <button 
                   onClick={handleInvitePlayer} 
                   className="px-2.5 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 font-semibold text-xs border border-emerald-500/30 flex items-center gap-1.5 transition-all active:scale-95 shadow-sm" 
                   title="Convidar jogador para a partida (Notificação e Link)"
                 >
                   <UserPlus size={14} />
                   <span className="hidden sm:inline">Convidar para Jogar</span>
                 </button>
                 <button onClick={handleReload} className="p-2 rounded hover:bg-white/10 transition-colors" title="Recarregar (Reload)">
                   <RefreshCw size={16} />
                 </button>
                 <button onClick={() => setShowConsole(!showConsole)} className={`p-2 rounded transition-colors ${showConsole ? 'bg-primary/30 text-primary' : 'hover:bg-white/10'}`} title="Console">
                   <Terminal size={16} />
                 </button>
                 <button onClick={toggleFullscreen} className="p-2 rounded hover:bg-white/10 transition-colors" title={isFullscreen ? "Sair da Tela Cheia" : "Tela Cheia"}>
                   {isFullscreen ? <Minimize2 size={16} className="text-emerald-400" /> : <Maximize2 size={16} className="text-emerald-400" />}
                 </button>
                 <div className="w-px h-6 bg-white/20 mx-1" />
                 <button onClick={() => { 
                    if(isFullscreen) try { document.exitFullscreen?.(); } catch(e){}
                    if (window.history.state?.htmlPreviewOpen) window.history.back();
                    onClose(); 
                 }} className="p-2 rounded hover:bg-red-500/20 hover:text-red-400 transition-colors" title="Fechar">
                   <X size={16} />
                 </button>
               </div>
            </div>

            {/* Floating exit button for fullscreen mode */}
            {isFullscreen && (
              <button
                onClick={toggleFullscreen}
                className="absolute top-3 right-3 z-[999999] p-2.5 rounded-full bg-black/50 text-white/50 hover:text-white hover:bg-black/90 transition-all opacity-0 hover:opacity-100 shadow-lg"
                title="Sair da Tela Cheia (ESC)"
              >
                <Minimize2 size={18} className="text-emerald-400" />
              </button>
            )}

            {/* Iframe content */}
            <iframe
              key={key}
              ref={iframeRef}
              srcDoc={getHtmlWithConsoleHook()}
              className="w-full flex-1 border-0 bg-white"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals"
            />

            {/* Console Drawer */}
            <AnimatePresence>
              {showConsole && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: 250 }}
                  exit={{ height: 0 }}
                  className="bg-[#1e1e1e] border-t border-white/10 overflow-hidden flex flex-col z-20"
                >
                  <div className="flex items-center justify-between p-2 bg-[#252526] border-b border-white/10">
                    <div className="flex items-center gap-2 px-2 text-white/80 text-xs font-mono">
                      <Terminal size={14} /> Console
                    </div>
                    <button onClick={() => setLogs([])} className="text-xs text-white/50 hover:text-white px-2 py-1 rounded hover:bg-white/10 transition-colors">
                      Limpar
                    </button>
                  </div>
                  <div className="flex-1 overflow-auto p-2 font-mono text-xs">
                    {logs.length === 0 ? (
                      <div className="text-white/30 p-2 italic">Aguardando logs...</div>
                    ) : (
                      logs.map((log, i) => (
                        <div key={i} className={`p-1 border-b border-white/5 ${
                          log.type === 'error' ? 'text-red-400 bg-red-400/5' :
                          log.type === 'warn' ? 'text-yellow-400 bg-yellow-400/5' :
                          log.type === 'info' ? 'text-emerald-400' : 'text-white/80'
                        }`}>
                          <span className="opacity-50 mr-2">[{log.type}]</span>
                          {log.message}
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};
