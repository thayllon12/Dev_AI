import React, { useState, useMemo } from 'react';
import { Search, Check, Sparkles, X } from 'lucide-react';
import { cn } from '../lib/utils';

export interface AIModel {
  id: string;
  displayName: string;
  subtitle?: string;
  overrideApi?: string;
  capabilities?: {
    image?: boolean;
    file?: boolean;
    video?: boolean;
    music?: boolean;
  };
}

export interface AIProvider {
  name: string;
  logo: string;
  apiType: string;
  models: AIModel[];
}

export const AI_PROVIDERS: AIProvider[] = [
  {
    name: "Automático (Seleção Inteligente)",
    logo: "https://www.gstatic.com/lamda/images/gemini_sparkle_aurora_33f86dc0c0257da337c63.svg",
    apiType: "auto",
    models: [
      { id: "auto", displayName: "Auto (Seleção de IA)", subtitle: "Llama para simples, Gemini Flash para foda, Gemini Pro para foda ainda" }
    ]
  },
  {
    name: "Google (Gemini & Gemma)",
    logo: "https://www.gstatic.com/lamda/images/gemini_sparkle_aurora_33f86dc0c0257da337c63.svg",
    apiType: "gemini",
    models: [
      { id: "gemini-3-flash-preview", displayName: "Gemini 3 Flash Preview", subtitle: "O modelo mais leve e rápido do Google", capabilities: { image: true, file: true } },
      { id: "gemini-3.5-flash", displayName: "Gemini 3.5 Flash", subtitle: "Rápido para conversas e código", capabilities: { image: true, file: true, video: true, music: true } },
      { id: "gemini-3.6-flash", displayName: "Gemini 3.6 Flash", subtitle: "A IA padrão e equilibrada do Google", capabilities: { image: true, file: true, video: true, music: true } },
      { id: "gemini-3.1-pro-preview", displayName: "Gemini 3.1 Pro", subtitle: "A IA mais capaz e avançada do Google", capabilities: { image: true, file: true, video: true, music: true } },
      { id: "google/gemma-4-31b-it", displayName: "Gemma 4", overrideApi: "nvidia", subtitle: "Modelo open-source eficiente do Google" }
    ]
  },
  {
    name: "OpenAI",
    logo: "https://upload.wikimedia.org/wikipedia/commons/4/4d/OpenAI_Logo.svg",
    apiType: "groq",
    models: [
      { id: "openai/gpt-oss-120b", displayName: "GPT OSS 120B", subtitle: "O modelo de raciocínio mais inteligente" },
      { id: "openai/gpt-oss-20b", displayName: "GPT OSS 20B", subtitle: "O modelo leve e rápido" }
    ]
  },
  {
    name: "Meta (Llama)",
    logo: "https://console.groq.com/_next/image?url=%2FMeta_logo.png&w=96&q=75",
    apiType: "groq",
    models: [
      { id: "llama-3.3-70b-versatile", displayName: "Llama 3.3", subtitle: "Llama mais avançado e versátil" },
      { id: "llama-3.1-8b-instant", displayName: "Llama 3.1", subtitle: "Resposta instantânea e leve da Meta" }
    ]
  },
  {
    name: "Qwen (Alibaba)",
    logo: "https://console.groq.com/_next/image?url=%2Fqwen_logo.png&w=96&q=75",
    apiType: "nvidia",
    models: [
      { id: "qwen/qwen3.6-27b", displayName: "Qwen 3.6 (NVIDIA)", overrideApi: "groq", subtitle: "Modelo balanceado da Qwen em nuvem" },
      { id: "local-qwen-llamacpp", displayName: "Qwen (Local llama.cpp)", overrideApi: "local", subtitle: "Modelo Qwen rodando no celular via llama.cpp (127.0.0.1:8080)" }
    ]
  },
  {
    name: "MiniMax",
    logo: "https://console.groq.com/_next/image?url=%2Fminimax_logo.png&w=96&q=75",
    apiType: "nvidia",
    models: [
      { id: "minimaxai/minimax-m3", displayName: "MiniMax M3", subtitle: "Raciocínio avançado da MiniMax" }
    ]
  },
  {
    name: "Zhipu AI (GLM)",
    logo: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
    apiType: "nvidia",
    models: [
      { id: "z-ai/glm-5.2", displayName: "GLM 5.2", subtitle: "Modelo unificado de próxima geração" }
    ]
  },
  {
    name: "Moonshot (Kimi)",
    logo: "https://kimi.moonshot.cn/favicon.ico",
    apiType: "nvidia",
    models: [
      { id: "moonshotai/kimi-k2.6", displayName: "Kimi K2.6", subtitle: "Processamento e contexto longo" }
    ]
  }
];

// Helper to find a model by ID
export function getModelById(modelId: string): AIModel | undefined {
  for (const provider of AI_PROVIDERS) {
    const found = provider.models.find(m => m.id === modelId);
    if (found) return found;
  }
  return undefined;
}

// Helper to find a provider by model ID
export function getProviderByModelId(modelId: string): AIProvider | undefined {
  return AI_PROVIDERS.find(provider => provider.models.some(m => m.id === modelId));
}

interface ModelSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedModelId: string;
  onSelectModel: (modelId: string, displayName: string) => void;
}

export const ModelSelectorModal: React.FC<ModelSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedModelId,
  onSelectModel,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [failedLogos, setFailedLogos] = useState<Record<string, boolean>>({});

  const filteredProviders = useMemo(() => {
    if (!searchTerm.trim()) return AI_PROVIDERS;

    const term = searchTerm.toLowerCase();
    return AI_PROVIDERS.map(provider => {
      const matchesProvider = provider.name.toLowerCase().includes(term);
      const matchingModels = provider.models.filter(
        m => m.displayName.toLowerCase().includes(term) ||
             (m.subtitle && m.subtitle.toLowerCase().includes(term)) ||
             m.id.toLowerCase().includes(term)
      );

      if (matchesProvider) {
        return provider;
      }

      if (matchingModels.length > 0) {
        return {
          ...provider,
          models: matchingModels
        };
      }

      return null;
    }).filter(Boolean) as AIProvider[];
  }, [searchTerm]);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 z-[1000000] bg-black/50 backdrop-blur-sm transition-opacity" 
        onClick={onClose} 
      />

      {/* Popover / Modal */}
      <div 
        className={cn(
          "fixed z-[1000005] left-1/2 -translate-x-1/2 bottom-20 sm:bottom-24 w-[92vw] sm:w-[420px] max-h-[75vh] sm:max-h-[520px]",
          "bg-bg-modal border border-border-strong rounded-3xl shadow-2xl overflow-hidden flex flex-col",
          "animate-in fade-in zoom-in-95 duration-200"
        )}
      >
        {/* Search Header */}
        <div className="p-3.5 border-b border-border-subtle/60 shrink-0 bg-bg-surface flex items-center justify-between gap-2">
          <div className="relative flex-1 flex items-center">
            <Search className="absolute left-3.5 size-4 text-text-muted pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar modelo..."
              className={cn(
                "w-full pl-10 pr-9 py-2 bg-bg-surface-hover/60 border border-border-subtle rounded-xl text-sm text-text-primary placeholder:text-text-muted/70",
                "focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-transparent transition-all"
              )}
            />
            {searchTerm && (
              <button 
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-3 text-text-muted hover:text-text-primary p-0.5"
              >
                <X className="size-4" />
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-text-muted hover:text-text-primary hover:bg-bg-surface-hover transition-colors shrink-0"
            title="Fechar"
          >
            <X className="size-5" />
          </button>
        </div>

        {/* Scrollable Models List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-4 custom-scrollbar">
          {filteredProviders.length === 0 ? (
            <div className="py-10 text-center text-text-muted text-sm">
              Nenhum modelo encontrado para "{searchTerm}"
            </div>
          ) : (
            filteredProviders.map((provider) => (
              <div key={provider.name} className="space-y-1">
                {/* Category Header */}
                <div className="px-3 pt-1 pb-1 text-xs font-semibold text-text-muted tracking-wide uppercase">
                  {provider.name}
                </div>

                {/* Model Rows */}
                {provider.models.map((model) => {
                  const isSelected = selectedModelId === model.id;
                  const hasLogoError = failedLogos[provider.name];

                  return (
                    <button
                      key={model.id}
                      type="button"
                      onClick={() => {
                        onSelectModel(model.id, model.displayName);
                        onClose();
                      }}
                      className={cn(
                        "w-full flex items-center justify-between p-2.5 sm:p-3 rounded-2xl text-left transition-all duration-150 group",
                        isSelected 
                          ? "bg-bg-surface-hover border border-border-strong/60 shadow-xs" 
                          : "hover:bg-bg-surface-hover/70 border border-transparent"
                      )}
                    >
                      {/* Left: Logo & Names */}
                      <div className="flex items-center gap-3 min-w-0 pr-2">
                        {/* Logo */}
                        <div className="w-8 h-8 rounded-xl bg-bg-surface-hover flex items-center justify-center shrink-0 overflow-hidden border border-border-subtle/50">
                          {!hasLogoError && provider.logo ? (
                            <img 
                              src={provider.logo} 
                              alt={provider.name}
                              className="w-5 h-5 object-contain"
                              onError={() => setFailedLogos(prev => ({ ...prev, [provider.name]: true }))}
                            />
                          ) : (
                            <Sparkles className="size-4 text-primary" />
                          )}
                        </div>

                        {/* Title & Subtitle */}
                        <div className="min-w-0 flex-1">
                          <div className={cn(
                            "text-sm font-semibold truncate transition-colors",
                            isSelected ? "text-text-primary" : "text-text-primary/90 group-hover:text-text-primary"
                          )}>
                            {model.displayName}
                          </div>
                          {model.subtitle && (
                            <div className="text-xs text-text-muted truncate mt-0.5">
                              {model.subtitle}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right: Selected Indicator */}
                      <div className="flex items-center gap-2 shrink-0">
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                            <Check className="size-3.5 stroke-[2.5]" />
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
};
