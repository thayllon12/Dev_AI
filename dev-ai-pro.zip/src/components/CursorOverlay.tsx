import React, { useEffect, useState } from 'react';
import { getSocket } from '../lib/socket';
import { motion, AnimatePresence } from 'motion/react';

interface CursorData {
  uid: string;
  x: number;
  y: number;
  user: {
    displayName: string;
    photoURL: string;
  };
}

export function CursorOverlay({ currentChatId, currentUserUid }: { currentChatId: string | null; currentUserUid: string }) {
  const [cursors, setCursors] = useState<Record<string, CursorData>>({});

  useEffect(() => {
    if (!currentChatId) return;

    const socket = getSocket();
    socket.emit('join-chat', currentChatId);

    const handleCursorMove = (data: CursorData) => {
      if (data.uid === currentUserUid) return;
      setCursors(prev => ({
        ...prev,
        [data.uid]: data
      }));

      // Remove after 3 seconds of inactivity
      setTimeout(() => {
        setCursors(prev => {
          const newCursors = { ...prev };
          delete newCursors[data.uid];
          return newCursors;
        });
      }, 3000);
    };

    socket.on('cursor-move', handleCursorMove);

    const handleMouseMove = (e: MouseEvent) => {
      if (!currentChatId) return;
      const data = {
        chatId: currentChatId,
        uid: currentUserUid,
        x: e.clientX,
        y: e.clientY,
        user: {
          displayName: 'User', // we can fetch real name
          photoURL: ''
        }
      };
      socket.emit('cursor-move', data);
    };

    // Throttle mouse move
    let lastTime = 0;
    const throttledMouseMove = (e: MouseEvent) => {
      const now = Date.now();
      if (now - lastTime > 50) {
        handleMouseMove(e);
        lastTime = now;
      }
    };

    window.addEventListener('mousemove', throttledMouseMove);

    return () => {
      socket.off('cursor-move', handleCursorMove);
      window.removeEventListener('mousemove', throttledMouseMove);
      socket.emit('leave-chat', currentChatId);
    };
  }, [currentChatId, currentUserUid]);

  if (!currentChatId) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[9999] overflow-hidden">
      <AnimatePresence>
        {Object.values(cursors).map((cursor) => (
          <motion.div
            key={cursor.uid}
            initial={{ opacity: 0 }}
            animate={{ x: cursor.x, y: cursor.y, opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ type: "tween", duration: 0.1, ease: "linear" }}
            className="absolute top-0 left-0 flex flex-col items-start drop-shadow-md"
            style={{ pointerEvents: 'none' }}
          >
            <svg width="18" height="24" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2.5 2.5L15 11L8 13.5L4 20L2.5 2.5Z" fill="#10b981" stroke="white" strokeWidth="1.5" strokeLinejoin="round"/>
            </svg>
            {cursor.user.displayName && (
              <div className="ml-4 -mt-1 px-2 py-0.5 bg-emerald-500 text-white text-[10px] rounded-full whitespace-nowrap shadow-sm">
                {cursor.user.displayName}
              </div>
            )}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
