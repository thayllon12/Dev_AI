import React, { useState, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { motion } from "motion/react";
import { toast } from "sonner";
import { Copy, CheckCheck, RotateCcw, Edit2, Code2, Download, ExternalLink, MoreVertical, Volume2, VolumeX, X, SplitSquareHorizontal, Brain, ChevronDown, ChevronUp, Archive, Github, Maximize2, Image as ImageIcon, Play, FileCode, Reply } from "lucide-react";
import { ClaudeArtifactCard } from "./ClaudeArtifactCard";
import { MultiFileArtifactCard } from "./MultiFileArtifactCard";
import { AudioMessagePlayer } from "./AudioMessagePlayer";
import { CodeBlock } from "./CodeBlock";
import { useClickOutside } from "../hooks/useClickOutside";
import { FilePreviewModal } from "./FilePreviewModal";
import { ImageMarkupModal } from "./ImageMarkupModal";
import { MermaidBlock } from "./MermaidBlock";
import { ReasoningWeb } from "./ReasoningWeb";
import { AILogo } from "./AILogo";
import { copyToClipboard, guessLanguage } from "../lib/utils";
import { triggerHaptic, playPinAlertSound } from "../lib/audio";
import { FileText, Code } from "lucide-react";
import JSZip from "jszip";
import { FileCard } from "./FileCard";
import { GenerationTimer } from "./GenerationTimer";

interface MessageBubbleProps {
  msg: any;
  isCodeMode: boolean;
  userPhoto?: string | null;
  onRegenerate?: (msg: any) => void;
  onContinue?: (msg: any) => void;
  isLastMessage?: boolean;
  onEdit?: (msg: any) => void;
  onBranch?: (msg: any) => void;
  onExportGithub?: (msg: any) => void;
  onImportGithub?: (msg: any) => void;
  onReply?: (msg: any) => void;
  userSettings: any;
  chatId?: string | null;
  onAnalyzeSecurity?: (code: string) => void;
  onAskAI?: (code: string) => void;
  onMemorize?: (content: string) => void;
  generationTimerNode?: React.ReactNode;
  generationStepsNode?: React.ReactNode;
}

export const MessageBubble: React.FC<MessageBubbleProps> = React.memo(({
  msg,
  isCodeMode,
  userPhoto,
  onRegenerate,
  onContinue,
  isLastMessage,
  onEdit,
  onBranch,
  onExportGithub,
  onImportGithub,
  onReply,
  userSettings,
  chatId,
  onAnalyzeSecurity,
  onAskAI,
  onMemorize,
  generationTimerNode,
  generationStepsNode
}) => {
  const isUser = msg.role === "user" || msg.role === "human_chat";
  const [copied, setCopied] = useState(false);
  const [showActions, setShowActions] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showSelectText, setShowSelectText] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);

  useEffect(() => {
    if (showSelectText) {
      document.body.classList.add('hide-input-field');
    } else {
      document.body.classList.remove('hide-input-field');
    }
    return () => document.body.classList.remove('hide-input-field');
  }, [showSelectText]);
  const [showSourcesModal, setShowSourcesModal] = useState(false);
  const [previewFile, setPreviewFile] = useState<{ dataUrl: string; mimeType: string; fileName?: string } | null>(null);
  const [markupImage, setMarkupImage] = useState<string | null>(null);
  const [isThinkExpanded, setIsThinkExpanded] = useState(false);


  const [isThinkVisible, setIsThinkVisible] = useState(true);
  const [isUserTextExpanded, setIsUserTextExpanded] = useState(false);

  const actionsMenuRef = React.useRef<HTMLDivElement>(null);

  useClickOutside(actionsMenuRef, () => {
    if (showActions) setShowActions(false);
  });

  useEffect(() => {
    return () => {
      if (isPlaying) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isPlaying]);

  const getCleanText = (text: string) => {
    let clean = text.replace(/<think>[\s\S]*?<\/think>/gi, '');
    clean = clean.replace(/(\*\*|__)(.*?)\1/g, '$2');
    clean = clean.replace(/(\*|_)(.*?)\1/g, '$2');
    clean = clean.replace(/^#+\s+/gm, '');
    clean = clean.replace(/```[a-z]*\n([\s\S]*?)```/g, '\n$1\n');
    clean = clean.replace(/`([^`]+)`/g, '$1');
    return clean.trim();
  };

  const getMessageSources = (): { title: string; url: string }[] => {
    if (msg.sources && Array.isArray(msg.sources)) {
      return msg.sources;
    }
    if (msg.citations && Array.isArray(msg.citations)) {
      return msg.citations;
    }

    const sources: { title: string; url: string }[] = [];
    const urlRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
    let match;
    const seenUrls = new Set<string>();

    if (msg.content) {
      while ((match = urlRegex.exec(msg.content)) !== null) {
        const title = match[1].trim();
        const url = match[2].trim();
        if (!url.startsWith("data:") && !seenUrls.has(url)) {
          seenUrls.add(url);
          const cleanTitle = /^\d+$/.test(title) ? `Fonte [${title}]` : title;
          sources.push({ title: cleanTitle, url });
        }
      }
    }

    return sources;
  };

  const handleCopy = async () => {
    await copyToClipboard(getCleanText(msg.content));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadImage = async (url: string, filename: string = 'image') => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = `${filename.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(objectUrl);
    } catch (e) {
       // fallback
       const link = document.createElement("a");
       link.href = url;
       link.download = `${filename.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.png`;
       link.click();
    }
  };

  const handleCopyImage = async (url: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      await navigator.clipboard.write([
        new ClipboardItem({
          [blob.type]: blob
        })
      ]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Falha ao copiar imagem. Certifique-se que o navegador suporta isso.", err);
    }
  };

  const handleDownloadText = () => {
    const blob = new Blob([getCleanText(msg.content)], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `message-${Date.now()}.txt`;
    a.click();
  };

  const getCleanReadableText = (text?: string) => {
    if (!text) return "";
    let clean = typeof text === 'string' ? text : String(text);
    // Remove think blocks
    clean = clean.replace(/<think>[\s\S]*?<\/think>/g, "");
    // Remove code blocks
    clean = clean.replace(/```[\s\S]*?```/g, " o trecho de código foi ocultado da leitura verbal. ");
    // Convert some simple markdown
    clean = clean.replace(/\*\*/g, "");
    clean = clean.replace(/\#/g, "");
    return clean;
  };

  const toggleTTS = async () => {
    if (isPlaying) {
      window.speechSynthesis.cancel();
      // stop internal audio element if exists
      const audioEl = document.getElementById(`audio-player-${msg.id}`) as HTMLAudioElement;
      if (audioEl) {
         audioEl.pause();
         audioEl.currentTime = 0;
      }
      setIsPlaying(false);
      return;
    }

    const text = getCleanReadableText(msg.content) || "Sem conteúdo para ler.";
    setIsPlaying(true);

    try {
      const { getAI } = await import("../App");
      const ai = getAI();
      if (ai) {
        // Attempt to use Gemini TTS
        const response = await ai.models.generateContent({
          model: "gemini-3.1-flash-tts-preview",
          contents: [{ parts: [{ text: `Leia o seguinte texto de forma expressiva e natural em português do Brasil, num tom amigável. Não leia blocos de código grandes se houver.\n\n${text.substring(0, 5000)}` }] }],
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } }
            }
          }
        });
        
        const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (audioData) {
          const audioUrl = `data:audio/wav;base64,${audioData}`;
          let audioEl = document.getElementById(`audio-player-${msg.id}`) as HTMLAudioElement;
          if (!audioEl) {
             audioEl = document.createElement("audio");
             audioEl.id = `audio-player-${msg.id}`;
             document.body.appendChild(audioEl);
          }
          audioEl.src = audioUrl;
          audioEl.onended = () => setIsPlaying(false);
          audioEl.onerror = () => setIsPlaying(false);
          audioEl.play();
          return;
        }
      }
    } catch (e) {
      console.error("Gemini TTS failed.", e);
      setIsPlaying(false);
    }
  };

  const handleDownloadProject = async () => {
    const codeBlocks: { language: string; code: string }[] = [];
    const regex = /```(\w+)?\n([\s\S]*?)```/g;
    let match;
    while ((match = regex.exec(msg.content)) !== null) {
      codeBlocks.push({
        language: match[1] || "txt",
        code: match[2].trim(),
      });
    }

    if (codeBlocks.length === 0) return;

    const zip = new JSZip();
    codeBlocks.forEach((block, index) => {
      // Try to guess a filename if not provided in the comment
      let filename = `file_${index + 1}.${block.language}`;
      const firstLine = block.code.split('\n')[0];
      if (firstLine.startsWith('//') || firstLine.startsWith('/*') || firstLine.startsWith('<!--')) {
        const potentialName = firstLine.replace(/[\/\*<!>\-]/g, '').trim();
        if (potentialName.includes('.')) {
          filename = potentialName;
        }
      }
      zip.file(filename, block.code);
    });

    const content = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(content);
    const a = document.createElement("a");
    a.href = url;
    a.download = `project-${Date.now()}.zip`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadFormat = async (format: 'txt' | 'md' | 'html' | 'json' | 'zip') => {
    const text = msg.content || "";
    const timestamp = Date.now();
    const filename = `message-${timestamp}`;

    const saveAsBlob = (blob: Blob, name: string) => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      a.click();
      URL.revokeObjectURL(url);
    };

    if (format === 'txt') {
      const blob = new Blob([getCleanText(text)], { type: "text/plain;charset=utf-8" });
      saveAsBlob(blob, `${filename}.txt`);
      toast.success("Download iniciado em TXT!");
    } else if (format === 'md') {
      const blob = new Blob([text], { type: "text/markdown;charset=utf-8" });
      saveAsBlob(blob, `${filename}.md`);
      toast.success("Download iniciado em Markdown!");
    } else if (format === 'html') {
      const htmlContent = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Dev AI - Export</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 2rem; max-width: 800px; margin: 0 auto; background: #0f0f11; color: #e4e4e7; line-height: 1.6; }
    pre { background: #18181b; padding: 1rem; border-radius: 8px; overflow-x: auto; border: 1px solid #27272a; }
    code { font-family: monospace; color: #38bdf8; }
  </style>
</head>
<body>
  <div>${getCleanText(text).replace(/\n/g, '<br/>')}</div>
</body>
</html>`;
      const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
      saveAsBlob(blob, `${filename}.html`);
      toast.success("Download iniciado em HTML!");
    } else if (format === 'json') {
      const jsonObj = {
        id: msg.id,
        role: msg.role,
        content: msg.content,
        thinking: msg.streamingThinkContent || thinkContent,
        createdAt: new Date().toISOString()
      };
      const blob = new Blob([JSON.stringify(jsonObj, null, 2)], { type: "application/json;charset=utf-8" });
      saveAsBlob(blob, `${filename}.json`);
      toast.success("Download iniciado em JSON!");
    } else if (format === 'zip') {
      await handleDownloadProject();
      toast.success("Download iniciado em ZIP!");
    }
  };


  const { thinkContent, mainContent, generatedFiles, isStreamingFiles } = React.useMemo(() => {
    let thinkContent = "";
    let mainContent = msg.content || "";
    let generatedFiles: any[] = [];
    let isStreamingFiles = false;

    if (!isUser) {
      let thinkContents: string[] = [];

      if (msg.streamingThinkContent || msg.thinkContent || msg.thinking) {
        thinkContents.push(msg.streamingThinkContent || msg.thinkContent || msg.thinking);
      }

      // Remove closed <think>...</think>
      mainContent = mainContent.replace(/<think>([\s\S]*?)<\/think>/gi, (match, p1) => {
        if (p1.trim()) thinkContents.push(p1.trim());
        return "";
      });

      // Remove unclosed <think>... during streaming
      const unclosedThinkIndex = mainContent.indexOf("<think>");
      if (unclosedThinkIndex !== -1) {
        const codeBlockIndex = mainContent.indexOf("```", unclosedThinkIndex);
        if (codeBlockIndex !== -1) {
          const thought = mainContent.substring(unclosedThinkIndex + 7, codeBlockIndex).trim();
          if (thought) thinkContents.push(thought);
          mainContent = mainContent.substring(0, unclosedThinkIndex) + "\n" + mainContent.substring(codeBlockIndex);
        } else {
          const thought = mainContent.substring(unclosedThinkIndex + 7).trim();
          if (thought) thinkContents.push(thought);
          mainContent = mainContent.substring(0, unclosedThinkIndex);
        }
      }

      thinkContent = Array.from(new Set(thinkContents.filter(Boolean))).join("\n\n");
      
      // Remove closed <generated_files>...</generated_files>
      mainContent = mainContent.replace(/<generated_files>([\s\S]*?)<\/generated_files>/g, (match, p1) => {
        try {
          const files = JSON.parse(p1);
          generatedFiles.push(...files);
        } catch(e) {}
        return "";
      });

      // Remove unclosed <generated_files>... during streaming to prevent JSON leakage
      const unclosedGenFilesIndex = mainContent.indexOf("<generated_files>");
      if (unclosedGenFilesIndex !== -1) {
        isStreamingFiles = true;
        mainContent = mainContent.substring(0, unclosedGenFilesIndex).trim();
      }
    }

    return { thinkContent, mainContent, generatedFiles, isStreamingFiles };
  }, [msg.content, msg.streamingThinkContent, isUser]);

  useEffect(() => {
    if (msg.isGenerating && (msg.streamingThinkContent || thinkContent)) {
       setIsThinkExpanded(true);
    }
  }, [msg.isGenerating, msg.streamingThinkContent, thinkContent]);

  const wasGeneratingRef = React.useRef(msg.isGenerating);
  useEffect(() => {
    if (wasGeneratingRef.current && !msg.isGenerating) {
      playPinAlertSound(userSettings?.soundEffectsEnabled !== false);
    }
    wasGeneratingRef.current = msg.isGenerating;
  }, [msg.isGenerating, userSettings]);

  const hasCodeBlocks = msg.content && typeof msg.content === 'string' && msg.content.includes("```");

  const msgStateRef = React.useRef({ content: msg.content, isGenerating: msg.isGenerating });
  React.useEffect(() => {
    msgStateRef.current = { content: msg.content, isGenerating: msg.isGenerating };
  }, [msg.content, msg.isGenerating]);

  const aiMarkdownComponents = React.useMemo<any>(() => ({
    pre: ({ node, children, ...props }: any) => {
      if (React.isValidElement(children)) {
        const codeProps = children.props as any;
        const match = /language-(\w+)/.exec(codeProps.className || "");
        const codeString = String(codeProps.children).replace(/\n$/, "");
        const language = match ? match[1] : guessLanguage(codeString);
        
        if (language === 'mermaid' || language === 'diagram') {
          return <MermaidBlock chart={codeString} />;
        }

        const isMultiFileProject = /(?:={3,}\s*(?:FILE|ARQUIVO):|\/\/\s*(?:FILE|ARQUIVO):|#\s*(?:FILE|ARQUIVO):)/i.test(codeString);

        if (isMultiFileProject) {
          return (
            <MultiFileArtifactCard
              language={language}
              code={codeString}
              isGenerating={msgStateRef.current.isGenerating}
              chatId={chatId}
            />
          );
        }

        const cleanLang = (language || '').toLowerCase();
        const isExplicitArtifact = 
          cleanLang === 'artifact' || 
          cleanLang.startsWith('artifact-') || 
          ['pptx', 'powerpoint', 'slide', 'slides', 'docx', 'word', 'xlsx', 'excel'].includes(cleanLang) ||
          /^(?:\/\/\s*ARTEFATO|\/\*\s*ARTEFATO\s*\*\/|<!--\s*ARTEFATO\s*-->)/i.test(codeString.trim());

        if (isExplicitArtifact) {
          return (
            <ClaudeArtifactCard
              language={language}
              code={codeString}
              isGenerating={msgStateRef.current.isGenerating}
              chatId={chatId}
            />
          );
        }
        
        return (
          <CodeBlock
            language={language}
            code={codeString}
            userSettings={userSettings}
            chatId={chatId}
            isGenerating={msgStateRef.current.isGenerating}
          />
        );
      }
      return <pre {...props}>{children}</pre>;
    },
    code: ({ node, className, children, ...props }: any) => {
      return (
        <code
          className={`px-1.5 py-0.5 rounded text-sm font-mono border whitespace-pre-wrap break-words bg-bg-code border-border-subtle ${className || ""}`}
          {...props}
        >
          {children}
        </code>
      );
    },
    p: ({ children }: any) => <div className="mb-4 last:mb-0 leading-relaxed">{children}</div>,
    ul: ({ children }: any) => <ul className="list-disc pl-6 mb-4 space-y-2">{children}</ul>,
    ol: ({ children }: any) => <ol className="list-decimal pl-6 mb-4 space-y-2">{children}</ol>,
    li: ({ children }: any) => <li className="leading-relaxed">{children}</li>,
    h1: ({ children }: any) => <h1 className="text-2xl font-bold mb-4 mt-6 first:mt-0">{children}</h1>,
    h2: ({ children }: any) => <h2 className="text-xl font-bold mb-3 mt-5 first:mt-0">{children}</h2>,
    h3: ({ children }: any) => <h3 className="text-lg font-bold mb-2 mt-4 first:mt-0">{children}</h3>,
    table: ({ children }: any) => <div className="overflow-x-auto w-full mb-4"><table className="min-w-full divide-y divide-border-subtle">{children}</table></div>,
    blockquote: ({ children }: any) => (
      <blockquote className="border-l-4 pl-4 italic my-4 border-primary/30">
        {children}
      </blockquote>
    ),
    a: ({ href, children }: any) => {
      if (href === "" && String(children) === "CURSOR") {
         return <span className="inline-block w-[5px] h-[1em] ml-1 bg-white align-middle animate-pulse shadow-[0_0_8px_rgba(255,255,255,0.8)] shrink-0 pointer-events-none" />;
      }
      if (href?.startsWith('blob:') && String(children).includes('VIDEO_BLOB')) {
        return <video controls src={href} className="max-w-full rounded-xl border border-border-strong shadow-lg my-4" />;
      }
      if (href?.startsWith('blob:') && String(children).includes('AUDIO_BLOB')) {
        return <audio controls src={href} className="w-full my-4" />;
      }
      return <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{children}</a>;
    },
    strong: ({ children }: any) => <strong className="font-bold">{children}</strong>,
    em: ({ children }: any) => <em className="italic">{children}</em>,
    img: ({ src, alt }: any) => {
      if (!src) return null;
      const isGeneratedImage = src.startsWith("data:image") || src.startsWith("https://image.pollinations.ai");
      return (
        <div className="relative group inline-block max-w-full my-4">
          <img 
            src={src} 
            alt={alt || "Imagem"} 
            className="max-w-full h-auto cursor-pointer rounded-lg shadow-sm border border-border-subtle group-hover:opacity-90 transition-opacity" 
            referrerPolicy="no-referrer" 
            onClick={() => setPreviewFile({ dataUrl: src, mimeType: 'image/png' })} 
            title="Clique para expandir" 
          />
          {isGeneratedImage && (
            <div className="absolute bottom-2 right-2 w-6 h-6 opacity-30 hover:opacity-100 transition-opacity select-none drop-shadow-md flex items-center justify-center p-1 rounded-full bg-black/40 backdrop-blur-md pointer-events-none">
             <span className="text-text-primary text-xs font-bold">AI</span>
           </div>
          )}
        </div>
      );
    },
  }), [userSettings, onAnalyzeSecurity, onAskAI]);

  const userMarkdownComponents = React.useMemo<any>(() => ({
    pre: ({ node, children, ...props }: any) => {
      if (React.isValidElement(children)) {
        const codeProps = children.props as any;
        const match = /language-(\w+)/.exec(codeProps.className || "");
        const codeString = String(codeProps.children).replace(/\n$/, "");
        const language = match ? match[1] : guessLanguage(codeString);
        
        if (language === 'mermaid' || language === 'diagram') {
          return <MermaidBlock chart={codeString} />;
        }
        
        
        return (
          <CodeBlock
            language={language}
            code={codeString}
            userSettings={userSettings}
            fullMessageContent={msgStateRef.current.content}
            onAnalyzeSecurity={onAnalyzeSecurity}
            onAskAI={onAskAI}
            isGenerating={msgStateRef.current.isGenerating} chatId={chatId}
          />
        );
      }
      return <pre {...props}>{children}</pre>;
    },
    code: ({ node, className, children, ...props }: any) => {
      return (
        <code
          className={`px-1.5 py-0.5 rounded text-sm font-mono border bg-transparent border-white/20 whitespace-pre-wrap break-words ${className || ""}`}
          {...props}
        >
          {children}
        </code>
      );
    },
    p: ({ children }: any) => <div className="mb-2 last:mb-0 leading-relaxed text-[15px]">{children}</div>,
    ul: ({ children }: any) => <ul className="list-disc pl-6 mb-2 space-y-1">{children}</ul>,
    ol: ({ children }: any) => <ol className="list-decimal pl-6 mb-2 space-y-1">{children}</ol>,
    li: ({ children }: any) => <li className="leading-relaxed">{children}</li>,
    a: ({ href, children }: any) => <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{children}</a>,
    strong: ({ children }: any) => <strong className="font-bold">{children}</strong>,
    em: ({ children }: any) => <em className="italic">{children}</em>,
    img: ({ src, alt }: any) => {
      if (!src) return null;
      return (
        <img 
          src={src} 
          alt={alt || "Imagem"} 
          className="max-w-full h-auto cursor-pointer rounded-lg shadow-sm border border-border-subtle my-2 hover:opacity-90 transition-opacity" 
          referrerPolicy="no-referrer" 
          onClick={() => setPreviewFile({ dataUrl: src, mimeType: 'image/png' })} 
          title="Clique para expandir" 
        />
      );
    },
  }), [userSettings, onAnalyzeSecurity, onAskAI]);

  return (
    <>
      <motion.div
        id={`message-${msg.id}`}
        style={{ contain: 'content' }}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className={`message-item group flex flex-col gap-2 min-w-0 w-full max-w-full ${isUser ? "items-end text-right" : "items-start text-left"}`}
      >
        {isUser ? (
          <div className="flex flex-col items-end gap-1">
            <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 shadow-lg overflow-hidden bg-primary text-white">
              {msg.authorPhoto ? (
                <img src={msg.authorPhoto} alt={msg.authorName || "User"} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : userPhoto ? (
                <img src={userPhoto} alt="User" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="text-sm font-bold">{msg.authorName ? msg.authorName.charAt(0).toUpperCase() : "U"}</div>
              )}
            </div>
            <div className="flex items-center gap-1.5 px-1">
              <span className="text-xs font-bold text-text-muted uppercase tracking-wider">
                {msg.authorName || "Você"}
              </span>
              {msg.role === "human_chat" && (
                <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-zinc-500/20 text-zinc-300 border border-zinc-500/30">
                  CHAT
                </span>
              )}
              {msg.privateTo && (
                <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-500 border border-amber-500/30">
                  🔒 @{msg.privateTo}
                </span>
              )}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-start gap-1.5 mb-2 w-full">
            {/* Logo at top */}
            <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-md overflow-hidden bg-bg-surface border border-border-strong">
              <AILogo mode={userSettings.mode} />
            </div>

            {/* Name below logo + Thinking button and timer on same row */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-extrabold tracking-wide text-text-primary animate-pulse transition-all">
                Dev AI
              </span>

              {(thinkContent || msg.streamingThinkContent || msg.thinkContent || msg.thinking) && (
                <button
                  onClick={() => {
                    triggerHaptic('pop', userSettings?.vibration);
                    setIsThinkExpanded(!isThinkExpanded);
                    setIsThinkVisible(true);
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-bg-surface border border-border-strong text-xs font-semibold text-text-secondary hover:text-text-primary hover:border-primary/50 transition-all shadow-xs cursor-pointer active:scale-95"
                  title="Processo de pensamento"
                >
                  <Brain size={13} className={isThinkExpanded ? "text-primary animate-pulse" : "text-text-muted"} />
                  <span>Pensamento</span>
                  {isThinkExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                </button>
              )}

              {generationTimerNode ? (
                <div className="flex items-center">
                  {generationTimerNode}
                </div>
              ) : (msg.generationTimeSeconds !== undefined && !msg.isGenerating) ? (
                <div className="flex items-center">
                  <GenerationTimer isCompleted={true} completedTimeSeconds={msg.generationTimeSeconds} startTime={Date.now()} />
                </div>
              ) : null}
            </div>
          </div>
        )}

        <div className={`relative flex flex-col max-w-full min-w-0 ${isUser ? "items-end" : "items-start"}`}>
          {generationStepsNode && (
            <div className="mb-2 w-full">
              {generationStepsNode}
            </div>
          )}

          <div
            className={`relative group transition-all duration-300 w-full break-words ${
              isUser ? "text-text-primary flex justify-end" : "text-text-primary"
            }`}
          >
            <div className={`flex flex-col gap-3 min-w-0 ${isUser ? "items-end max-w-[88%] sm:max-w-[80%]" : "w-full"}`}>
              {(thinkContent || msg.streamingThinkContent) && isThinkVisible && (
                <div className="bg-bg-surface border border-border-subtle rounded-xl overflow-hidden shadow-sm w-full">
                  <div className="flex items-center justify-between p-2.5 bg-bg-surface-hover/50">
                    <button 
                      onClick={() => {
                        triggerHaptic('pop', userSettings?.vibration);
                        setIsThinkExpanded(!isThinkExpanded);
                      }}
                      className="flex-1 flex items-center gap-2 text-sm font-medium text-text-muted hover:text-text-primary transition-colors text-left"
                      aria-label={isThinkExpanded ? "Recolher processo de pensamento" : "Expandir processo de pensamento"}
                      aria-expanded={isThinkExpanded}
                    >
                      <Brain size={16} className={isThinkExpanded ? "text-primary animate-pulse" : ""} />
                      <span>Processo de pensamento {msg.isGenerating ? "(Em andamento...)" : ""}</span>
                      {isThinkExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                    </button>
                    <button 
                      onClick={() => {
                        triggerHaptic('pop', userSettings?.vibration);
                        setIsThinkVisible(false);
                      }}
                      className="p-1.5 text-text-muted hover:text-red-500 hover:bg-red-500/10 rounded-md transition-colors"
                      title="Fechar processo de pensamento"
                      aria-label="Fechar processo de pensamento"
                    >
                      <X size={14} />
                    </button>
                  </div>
                  {isThinkExpanded && (
                    <div className="p-4 border-t border-border-subtle bg-bg-main/30 text-sm text-text-secondary select-text">
                      <ReasoningWeb 
                        content={msg.streamingThinkContent || thinkContent} 
                        isGenerating={msg.isGenerating && (!!msg.streamingThinkContent || !msg.content.includes("</think>"))} 
                      />
                    </div>
                  )}
                </div>
              )}
              
              {/* Reply Quote Display if this message is a reply */}
              {msg.replyTo && (
                <div 
                  onClick={() => {
                    const targetEl = document.getElementById(`message-${msg.replyTo.id}`);
                    if (targetEl) {
                      targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                      targetEl.classList.add('ring-2', 'ring-primary', 'transition-all');
                      setTimeout(() => targetEl.classList.remove('ring-2', 'ring-primary'), 1500);
                    }
                  }}
                  className={`cursor-pointer mb-1.5 p-2.5 rounded-xl border-l-4 border-primary text-xs max-w-full overflow-hidden flex flex-col gap-0.5 transition-opacity hover:opacity-90 ${
                    isUser ? 'bg-black/30 text-right items-end' : 'bg-white/5 text-left items-start'
                  }`}
                >
                  <span className="font-bold text-primary text-[11px] truncate flex items-center gap-1">
                    <Reply size={12} className="rotate-180" />
                    {msg.replyTo.authorName || (msg.replyTo.role === 'user' ? 'Você' : 'Dev AI')}
                  </span>
                  <span className="text-text-muted text-[12px] line-clamp-2 italic truncate w-full">
                    {msg.replyTo.audioUrl ? '🎙️ Mensagem de áudio' : (msg.replyTo.content || 'Mensagem')}
                  </span>
                </div>
              )}

              {isUser ? (
                <div className="flex flex-col items-end w-full">
                  {msg.audioUrl && (
                    <div className="mb-2 w-full max-w-sm">
                      <AudioMessagePlayer 
                        audioUrl={msg.audioUrl} 
                        duration={msg.audioDuration || 0}
                        waveform={msg.waveform || []}
                        authorName={msg.authorName || "Você"}
                      />
                    </div>
                  )}
                  {msg.content && (
                    <div className={`bg-bg-surface-hover border border-border-strong px-4 sm:px-5 py-3 rounded-2xl rounded-tr-sm shadow-sm text-left select-text markdown-body w-fit max-w-full [word-break:normal] [overflow-wrap:break-word] whitespace-pre-wrap overflow-x-auto relative min-w-[3rem] ${!isUserTextExpanded && msg.content.length > 500 ? "max-h-64 overflow-y-hidden" : ""}`}>
                      <ReactMarkdown
                        remarkPlugins={[remarkGfm]}
                        components={userMarkdownComponents}
                      >
                        {msg.content}
                      </ReactMarkdown>
                      {!isUserTextExpanded && msg.content.length > 500 && (
                        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-bg-surface-hover to-transparent pointer-events-none" />
                      )}
                    </div>
                  )}
                  {msg.content && msg.content.length > 500 && (
                    <button 
                      onClick={() => {
                        triggerHaptic('pop', userSettings?.vibration);
                        setIsUserTextExpanded(!isUserTextExpanded);
                      }} 
                      className="mt-2 text-xs font-medium text-text-muted hover:text-primary transition-colors px-2 py-1 rounded-md hover:bg-primary/10"
                    >
                      {isUserTextExpanded ? "Mostrar menos" : "Mostrar mais"}
                    </button>
                  )}
                </div>
              ) : (
                <div className="markdown-body select-text w-full max-w-full overflow-x-auto [word-break:normal] [overflow-wrap:break-word] min-w-0">
                  {(mainContent.length > 250000 && !mainContent.includes('blob:')) ? (
                      (() => {
                        const parts = mainContent.split('```');
                        return parts.map((part, index) => {
                          if (index % 2 === 1) { // It's a code block
                            const firstNewline = part.indexOf('\n');
                            let language = "";
                            let code = part;
                            if (firstNewline !== -1) {
                              language = part.substring(0, firstNewline).trim();
                              code = part.substring(firstNewline + 1);
                            }
                            return (
                              <CodeBlock
                                key={index}
                                language={language || guessLanguage(code.substring(0, 500))}
                                code={code}
                                userSettings={userSettings}
                                fullMessageContent={msg.content}
                                onAnalyzeSecurity={onAnalyzeSecurity}
                                onAskAI={onAskAI}
                                isGenerating={msg.isGenerating} chatId={chatId}
                              />
                            );
                          } else {
                            return (
                              <div key={index} className="whitespace-pre-wrap break-words font-sans text-[15px] leading-relaxed my-2">
                                {part}
                              </div>
                            );
                          }
                        });
                      })()
                  ) : (
                  <div className="relative inline font-sans w-full leading-relaxed">
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      components={aiMarkdownComponents}
                    >
                      {(() => {
                        let contentWithCursor = mainContent;
                        if (msg.isGenerating && !isStreamingFiles) {
                          const codeBlockMatches = mainContent.match(/```/g) || [];
                          const isInsideCodeBlock = codeBlockMatches.length % 2 !== 0;
                          if (!isInsideCodeBlock) {
                            contentWithCursor += " [CURSOR]()";
                          }
                        }
                        return contentWithCursor;
                      })()}
                    </ReactMarkdown>
                  </div>
                )}

                {/* Animated live files generation card */}
                {isStreamingFiles && (
                  <motion.div 
                    initial={{ opacity: 0, y: 8, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className="mt-3.5 p-3.5 rounded-2xl bg-gradient-to-r from-primary/10 via-purple-950/30 to-bg-surface border border-primary/40 shadow-[0_0_20px_rgba(99,102,241,0.15)] flex items-center justify-between gap-3 text-xs text-text-primary"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-xl bg-primary/20 border border-primary/40 flex items-center justify-center shrink-0">
                        <Code size={18} className="text-primary animate-spin" />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="font-semibold text-text-primary flex items-center gap-1.5 text-xs">
                          <span>Sintetizando estrutura do projeto...</span>
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
                        </span>
                        <span className="text-[11px] text-text-muted truncate">Escrevendo arquivos HTML/JS em tempo real</span>
                      </div>
                    </div>
                    <div className="w-24 h-2 bg-bg-surface border border-border-subtle rounded-full overflow-hidden shrink-0">
                      <motion.div 
                        animate={{ x: ["-100%", "100%"] }}
                        transition={{ duration: 1.1, repeat: Infinity, ease: "linear" }}
                        className="w-full h-full bg-gradient-to-r from-primary via-purple-400 to-emerald-400 shadow-[0_0_10px_rgba(99,102,241,1)]"
                      />
                    </div>
                  </motion.div>
                )}
                
                {generatedFiles.length > 0 && (
                  <div className="flex flex-wrap gap-3 mt-4">
                    {generatedFiles.map((file, idx) => (
                       <FileCard
                         key={idx}
                         name={file.filename}
                         size={file.size ? (file.size < 1024 ? `${file.size} B` : `${(file.size / 1024).toFixed(1)} KB`) : "Desconhecido"}
                         mimeType={file.mimeType}
                         downloadUrl={file.downloadUrl}
                         content={file.content}
                         onPreview={() => setPreviewFile({ dataUrl: file.downloadUrl, mimeType: file.mimeType, fileName: file.filename })}
                       />
                    ))}
                  </div>
                )}
              </div>
              )}
            </div>
          </div>

          {/* Attachments */}
          {msg.attachments && msg.attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-border-subtle">
              {msg.attachments.map((att: any, idx: number) => {
                const isImage = att.mimeType?.startsWith("image/");
                const isAudio = att.mimeType?.startsWith("audio/");
                return (
                  <div key={idx} className="relative group/att rounded-lg overflow-hidden border border-white/20 shadow-lg cursor-pointer" onClick={() => setPreviewFile({ dataUrl: att.dataUrl, mimeType: att.mimeType })}>
                    {isImage ? (
                      <div className="max-w-[260px] max-h-[180px] rounded-lg overflow-hidden bg-black/40 border border-border-subtle flex items-center justify-center p-1">
                        <img 
                          src={att.dataUrl} 
                          alt="Attachment" 
                          className="max-w-full max-h-[170px] w-auto h-auto object-contain rounded-md" 
                          referrerPolicy="no-referrer" 
                        />
                      </div>
                    ) : isAudio ? (
                      <div className="p-2 bg-black/40 rounded-lg border border-border-subtle flex items-center gap-2">
                        <audio controls src={att.dataUrl} className="max-w-[260px] h-9 rounded" />
                      </div>
                    ) : (
                      <div className="w-24 h-24 bg-white/5 flex flex-col items-center justify-center gap-2">
                        <FileText size={24} className="text-text-primary/70" />
                        <span className="text-[10px] text-text-primary/50 uppercase truncate w-full px-2 text-center" title={att.geminiFileName || "FILE"}>
                          {att.geminiFileName || att.mimeType?.split("/")[1] || "FILE"}
                        </span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/att:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDownloadImage(att.dataUrl);
                        }}
                        className="p-1.5 bg-white text-black rounded-full hover:scale-110 transition-transform"
                        title="Baixar Anexo"
                        aria-label="Baixar Anexo"
                      >
                        <Download size={14} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Actions Menu - Only show when generation is finished or for user messages */}
          {(!msg.isGenerating || isUser) && (
            <div className={`mt-2 flex items-center gap-1.5 w-full opacity-100 transition-opacity duration-300 ${isUser ? "justify-end" : "justify-start"}`}>
              {!isUser && (
                <button
                  onClick={toggleTTS}
                  className={`p-1.5 rounded-lg transition-all hover:scale-110 active:scale-95 ${
                    isPlaying ? "bg-primary/10 text-primary" : "text-text-muted hover:text-text-primary hover:bg-bg-surface-hover"
                  }`}
                  title={isPlaying ? "Parar áudio" : "Ouvir em voz alta"}
                  aria-label={isPlaying ? "Parar áudio" : "Ouvir em voz alta"}
                >
                  {isPlaying ? <VolumeX size={18} /> : <Volume2 size={18} />}
                </button>
              )}

              {/* Display search sources if they exist */}
              {!isUser && getMessageSources().length > 0 && (
                <button
                  onClick={() => setShowSourcesModal(true)}
                  className="inline-flex items-center gap-2 px-3 py-1 text-xs font-medium bg-bg-surface-hover hover:bg-bg-surface text-text-secondary hover:text-text-primary rounded-full border border-border-subtle shadow-sm transition-all shrink-0 hover:scale-105 active:scale-95"
                  title="Ver fontes de pesquisa"
                >
                  <div className="flex -space-x-1 overflow-hidden">
                    {getMessageSources().slice(0, 3).map((s, idx) => {
                      let domain = "google.com";
                      try { domain = new URL(s.url).hostname; } catch(e) {}
                      return (
                        <img
                          key={idx}
                          src={`https://www.google.com/s2/favicons?domain=${domain}&sz=32`}
                          alt={domain}
                          className="inline-block h-3.5 w-3.5 rounded-full ring-1 ring-bg-surface bg-white"
                          onError={(e) => { (e.target as any).style.display = 'none'; }}
                        />
                      );
                    })}
                  </div>
                  <span className="font-semibold text-[11px] text-primary">Fontes ({getMessageSources().length})</span>
                </button>
              )}

              {/* Quick Reply Button */}
              {onReply && (
                <button
                  onClick={() => onReply(msg)}
                  className="p-1.5 rounded-lg text-text-muted hover:text-primary hover:bg-primary/10 transition-all hover:scale-110 active:scale-95"
                  title="Responder mensagem"
                  aria-label="Responder"
                >
                  <Reply size={18} />
                </button>
              )}

              {/* Quick Copy Button */}
              <button
                onClick={handleCopy}
                className="p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-bg-surface-hover transition-all hover:scale-110 active:scale-95"
                title="Copiar tudo"
                aria-label="Copiar tudo"
              >
                {copied ? <CheckCheck size={18} className="text-emerald-500" /> : <Copy size={18} />}
              </button>

              <div className="relative" ref={actionsMenuRef}>
                <button
                  onClick={() => setShowActions(!showActions)}
                  className={`p-1.5 rounded-lg transition-all hover:scale-110 active:scale-95 ${
                    showActions ? "bg-primary/10 text-primary" : "text-text-muted hover:text-text-primary hover:bg-bg-surface-hover"
                  }`}
                  title="Mais opções"
                  aria-label="Mais opções"
                  aria-expanded={showActions}
                >
                  <MoreVertical size={18} />
                </button>

                {showActions && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className={`absolute bottom-full mb-2 w-max min-w-[190px] max-w-[240px] py-1.5 bg-bg-modal text-text-primary border border-border-strong rounded-2xl shadow-2xl z-[99999] flex flex-col overflow-hidden backdrop-blur-2xl ${
                      isUser ? "right-0" : "left-0"
                    }`}
                    style={{ boxShadow: "0 10px 40px rgba(0,0,0,0.85)" }}
                  >
                  <div className="px-3 pb-1.5 mb-0.5 border-b border-border-subtle">
                    <span className="text-[11px] font-medium text-text-muted">
                      {(() => {
                        if (!msg.createdAt) return "Hoje, 9:20 PM";
                        try {
                          const d = msg.createdAt.toDate ? msg.createdAt.toDate() : new Date(msg.createdAt);
                          const today = new Date();
                          const isToday = d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear();
                          const timeStr = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }).toUpperCase();
                          if (isToday) return `Hoje, ${timeStr}`;
                          return `${d.toLocaleDateString()} ${timeStr}`;
                        } catch (e) {
                          return "Hoje";
                        }
                      })()}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      handleCopy();
                      setShowActions(false);
                    }}
                    className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left"
                  >
                    {copied ? <CheckCheck size={16} className="text-emerald-500" strokeWidth={1.5} /> : <Copy size={16} className="text-text-primary" strokeWidth={1.5} />}
                    <span>Copiar</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowSelectText(true);
                      setShowActions(false);
                    }}
                    className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left"
                  >
                    <FileText size={16} className="text-text-primary" strokeWidth={1.5} />
                    <span>Selecionar texto</span>
                  </button>

                  {/* USER MENU OPTIONS ONLY */}
                  {isUser && onEdit && (
                    <button
                      onClick={() => {
                        onEdit(msg);
                        setShowActions(false);
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left"
                    >
                      <Edit2 size={16} className="text-text-primary" strokeWidth={1.5} />
                      <span>Editar mensagem</span>
                    </button>
                  )}

                  {/* AI MENU OPTIONS ONLY */}
                  {!isUser && onRegenerate && (
                    <button
                      onClick={() => {
                        onRegenerate(msg);
                        setShowActions(false);
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left"
                    >
                      <RotateCcw size={16} className="text-text-primary" />
                      <span>Gerar nova resposta</span>
                    </button>
                  )}

                  {!isUser && (
                    <button
                      onClick={() => {
                        setShowDownloadModal(true);
                        setShowActions(false);
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left border-t border-border-subtle mt-0.5 pt-1.5"
                    >
                      <Download size={16} className="text-text-primary" />
                      <span>Download</span>
                    </button>
                  )}

                  {!isUser && onExportGithub && (
                    <button
                      onClick={() => {
                        onExportGithub(msg);
                        setShowActions(false);
                      }}
                      className="flex items-center gap-3 px-4 py-2 text-[13px] font-medium text-text-primary hover:bg-bg-surface-hover transition-colors text-left"
                    >
                      <Github size={16} className="text-text-primary" />
                      <span>Exportar para GitHub</span>
                    </button>
                  )}
                </motion.div>
              )}
            </div>
          </div>
        )}
          {/* Auto Continuar Geração button below message strictly when cut off / needsContinue */}
          {!isUser && onContinue && !msg.isGenerating && msg.needsContinue && (
            <div className="mt-2 flex items-center">
              <button
                onClick={() => onContinue(msg)}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold bg-purple-500/10 text-purple-400 hover:bg-purple-500/20 border border-purple-500/30 rounded-xl transition-all shadow-sm hover:scale-105 active:scale-95"
              >
                <Play size={14} />
                <span>Continuar geração</span>
              </button>
            </div>
          )}
        </div>
      </motion.div>
      <FilePreviewModal
        isOpen={!!previewFile}
        onClose={() => setPreviewFile(null)}
        dataUrl={previewFile?.dataUrl || ""}
        mimeType={previewFile?.mimeType || "image/png"}
        fileName={previewFile?.fileName}
        onEdit={() => {
          if (previewFile?.dataUrl) {
            setMarkupImage(previewFile.dataUrl);
            setPreviewFile(null);
          }
        }}
      />
      {markupImage && (
        <ImageMarkupModal
          isOpen={!!markupImage}
          onClose={() => setMarkupImage(null)}
          dataUrl={markupImage}
          onSave={(newDataUrl) => {
            // Initiate a local download of the edited image
            const link = document.createElement("a");
            link.href = newDataUrl;
            link.download = `editado_${previewFile?.fileName || "imagem.png"}`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            setMarkupImage(null);
            toast.success("Imagem editada e salva!");
          }}
        />
      )}
      {/* Sources Modal */}
      {showSourcesModal && (
        <div className="fixed inset-0 z-[100000] bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-[#18181b] border border-border-subtle w-full max-w-xl rounded-t-3xl sm:rounded-2xl p-5 shadow-2xl flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between pb-3 border-b border-border-subtle mb-4">
              <div className="flex items-center gap-2">
                <ExternalLink size={18} className="text-primary" />
                <h3 className="font-bold text-base text-text-primary">Fontes de Pesquisa ({getMessageSources().length})</h3>
              </div>
              <button
                onClick={() => setShowSourcesModal(false)}
                className="p-1.5 text-text-muted hover:text-text-primary rounded-lg hover:bg-bg-surface-hover transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            <div className="overflow-y-auto space-y-3 pr-1 custom-scrollbar">
              {getMessageSources().map((s, idx) => {
                let domain = "google.com";
                try { domain = new URL(s.url).hostname.replace("www.", ""); } catch(e) {}
                return (
                  <a
                    key={idx}
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-3 p-3 bg-white/5 hover:bg-bg-surface-hover border border-border-subtle hover:border-primary/30 rounded-xl transition-all group"
                  >
                    <img
                      src={`https://www.google.com/s2/favicons?domain=${domain}&sz=64`}
                      alt={domain}
                      className="w-5 h-5 rounded-md mt-0.5 bg-white shrink-0"
                      onError={(e) => { (e.target as any).style.display = 'none'; }}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-primary truncate">{domain}</span>
                        <ExternalLink size={12} className="text-text-muted group-hover:text-primary transition-colors shrink-0" />
                      </div>
                      <p className="text-sm font-medium text-text-primary group-hover:text-primary transition-colors line-clamp-1 mt-0.5">
                        {s.title || domain}
                      </p>
                      <p className="text-xs text-text-muted line-clamp-2 mt-1">
                        {s.url}
                      </p>
                    </div>
                  </a>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Text Selection Overlay Modal */}
      {showSelectText && (
        <div className="fixed inset-0 z-[1000000] bg-bg-modal text-text-primary flex flex-col animate-in fade-in duration-200">
          <div className="flex items-center justify-between px-4 py-3 bg-bg-surface border-b border-border-strong shrink-0 shadow-md">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowSelectText(false)}
                className="p-2 hover:bg-bg-surface-hover rounded-full transition-colors text-text-primary"
                title="Voltar"
              >
                <X size={20} />
              </button>
              <h2 className="font-bold text-lg text-text-primary">Selecionar texto</h2>
            </div>
            <button
              onClick={() => {
                copyToClipboard(msg.content);
                toast.success("Todo o texto copiado!");
              }}
              className="px-3 py-1.5 text-xs font-semibold bg-primary text-white hover:bg-primary-hover rounded-lg transition-all flex items-center gap-1.5 shadow-sm"
            >
              <Copy size={14} /> Copiar Tudo
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full select-text text-base sm:text-lg leading-relaxed text-text-primary font-sans whitespace-pre-wrap custom-scrollbar">
            {msg.content}
          </div>
        </div>
      )}

      {showDownloadModal && (
        <div className="fixed inset-0 z-[1000000] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-bg-modal text-text-primary border border-border-strong w-full max-w-sm rounded-3xl p-6 shadow-2xl relative flex flex-col gap-4"
          >
            <div className="flex items-center justify-between border-b border-border-subtle pb-3">
              <div className="flex items-center gap-2">
                <Download size={20} className="text-primary" />
                <h3 className="font-bold text-base text-text-primary">Download da Mensagem</h3>
              </div>
              <button 
                onClick={() => setShowDownloadModal(false)}
                className="p-1 text-text-muted hover:text-text-primary hover:bg-bg-surface rounded-lg transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            <p className="text-xs text-text-muted">Escolha o formato em que deseja baixar esta resposta:</p>

            <div className="grid grid-cols-1 gap-2">
              <button
                onClick={() => { handleDownloadFormat('txt'); setShowDownloadModal(false); }}
                className="flex items-center justify-between p-3 rounded-2xl bg-bg-surface hover:bg-bg-surface-hover border border-border-subtle text-xs font-semibold transition-all hover:scale-[1.01]"
              >
                <span className="flex items-center gap-2.5"><FileText size={16} className="text-blue-400" /> Texto Simples (.txt)</span>
                <Download size={14} className="text-text-muted" />
              </button>

              <button
                onClick={() => { handleDownloadFormat('md'); setShowDownloadModal(false); }}
                className="flex items-center justify-between p-3 rounded-2xl bg-bg-surface hover:bg-bg-surface-hover border border-border-subtle text-xs font-semibold transition-all hover:scale-[1.01]"
              >
                <span className="flex items-center gap-2.5"><FileCode size={16} className="text-purple-400" /> Markdown (.md)</span>
                <Download size={14} className="text-text-muted" />
              </button>

              <button
                onClick={() => { handleDownloadFormat('html'); setShowDownloadModal(false); }}
                className="flex items-center justify-between p-3 rounded-2xl bg-bg-surface hover:bg-bg-surface-hover border border-border-subtle text-xs font-semibold transition-all hover:scale-[1.01]"
              >
                <span className="flex items-center gap-2.5"><Code size={16} className="text-amber-400" /> Documento HTML (.html)</span>
                <Download size={14} className="text-text-muted" />
              </button>

              <button
                onClick={() => { handleDownloadFormat('json'); setShowDownloadModal(false); }}
                className="flex items-center justify-between p-3 rounded-2xl bg-bg-surface hover:bg-bg-surface-hover border border-border-subtle text-xs font-semibold transition-all hover:scale-[1.01]"
              >
                <span className="flex items-center gap-2.5"><FileText size={16} className="text-emerald-400" /> Estrutura JSON (.json)</span>
                <Download size={14} className="text-text-muted" />
              </button>

              {hasCodeBlocks && (
                <button
                  onClick={() => { handleDownloadFormat('zip'); setShowDownloadModal(false); }}
                  className="flex items-center justify-between p-3 rounded-2xl bg-primary/15 hover:bg-primary/25 border border-primary/40 text-xs font-bold text-primary transition-all hover:scale-[1.01]"
                >
                  <span className="flex items-center gap-2.5"><Archive size={16} className="text-primary" /> Código Compactado (.zip)</span>
                  <Download size={14} className="text-primary" />
                </button>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </>
  );
}, (prevProps, nextProps) => {
  const attachmentsEqual = (a1: any[], a2: any[]) => {
    if (!a1 && !a2) return true;
    if (!a1 || !a2) return false;
    if (a1.length !== a2.length) return false;
    for (let i = 0; i < a1.length; i++) {
      if (a1[i].mimeType !== a2[i].mimeType || a1[i].dataUrl?.length !== a2[i].dataUrl?.length) {
         return false;
      }
    }
    return true;
  };

  return (
    prevProps.msg.id === nextProps.msg.id &&
    prevProps.msg.content === nextProps.msg.content &&
    prevProps.msg.role === nextProps.msg.role &&
    prevProps.msg.isGenerating === nextProps.msg.isGenerating &&
    prevProps.msg.streamingThinkContent === nextProps.msg.streamingThinkContent &&
    attachmentsEqual(prevProps.msg.attachments, nextProps.msg.attachments) &&
    prevProps.isCodeMode === nextProps.isCodeMode &&
    prevProps.isLastMessage === nextProps.isLastMessage
  );
});
