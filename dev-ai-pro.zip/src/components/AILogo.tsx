import React from 'react';
import { cn } from '../lib/utils';

export function AILogo({ className }: { className?: string, mode?: string }) {
  return (
    <img
      src="https://spotty-salmon-m4tbarjj.edgeone.dev/file_00000000c1b4820e911cd128d84c0309.png"
      alt="Dev AI Logo"
      className={cn("w-full h-full object-cover", className)}
      referrerPolicy="no-referrer"
    />
  );
}
