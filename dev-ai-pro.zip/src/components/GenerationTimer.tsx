import React, { useState, useEffect, useRef } from "react";
import { Clock, CheckCircle2, ChevronDown, ChevronUp, Check, Zap } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { triggerHaptic } from "../lib/audio";

interface StepItem {
  id: string;
  label: string;
  timeSeconds: number;
  status: "running" | "success" | "error";
}

interface GenerationTimerProps {
  statusMessage?: string | null;
  startTime: number;
  isCompleted?: boolean;
  completedTimeSeconds?: number;
  steps?: { id: string; label: string; status: "running" | "success" | "error" }[];
}

export function GenerationTimer({ statusMessage, startTime, isCompleted, completedTimeSeconds, steps: externalSteps }: GenerationTimerProps) {
  const [elapsed, setElapsed] = useState(completedTimeSeconds !== undefined ? completedTimeSeconds : 0);
  const [isExpanded, setIsExpanded] = useState(false);
  const [recordedSteps, setRecordedSteps] = useState<StepItem[]>(() => {
    if (externalSteps && externalSteps.length > 0) {
      return externalSteps.map((s, idx) => ({
        id: s.id || `step-${idx}`,
        label: s.label,
        timeSeconds: completedTimeSeconds || 1,
        status: s.status || "success"
      }));
    }
    return [
      { id: "init-step-1", label: "Conectando à IA", timeSeconds: 1, status: isCompleted ? "success" : "running" }
    ];
  });
  const lastStatusRef = useRef<string | null>(null);

  useEffect(() => {
    if (isCompleted) {
      if (completedTimeSeconds !== undefined) setElapsed(completedTimeSeconds);
      setRecordedSteps(prev => {
        if (prev.length === 0) {
          return [
            { id: "step-conn", label: "Conectando à IA", timeSeconds: 1, status: "success" },
            { id: "step-think", label: "Pensando e raciocinando", timeSeconds: Math.max(1, Math.floor((completedTimeSeconds || 1) / 2)), status: "success" },
            { id: "step-resp", label: "Gerando resposta", timeSeconds: completedTimeSeconds || 1, status: "success" }
          ];
        }
        return prev.map(s => ({ ...s, status: "success" as const }));
      });
      triggerHaptic('success', true);
      return;
    }
    const timer = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, [startTime, isCompleted, completedTimeSeconds]);

  // Automatically record status phases as statusMessage changes
  useEffect(() => {
    const currentMsg = statusMessage || "Pensando";
    if (currentMsg !== lastStatusRef.current && !isCompleted) {
      lastStatusRef.current = currentMsg;
      const currentSeconds = Math.max(1, Math.floor((Date.now() - startTime) / 1000));
      
      triggerHaptic('tick', true);

      setRecordedSteps(prev => {
        const updated = prev.map(step =>
          step.status === "running" ? { ...step, status: "success" as const } : step
        );
        const exists = updated.some(s => s.label === currentMsg);
        if (!exists) {
          updated.push({
            id: `${Date.now()}_${Math.random()}`,
            label: currentMsg,
            timeSeconds: currentSeconds,
            status: "running"
          });
        }
        return updated;
      });
    }
  }, [statusMessage, startTime, isCompleted]);

  const formatTime = (seconds: number) => {
    const safeSecs = Math.max(1, seconds || 1);
    const mins = Math.floor(safeSecs / 60);
    const secs = safeSecs % 60;
    if (mins > 0) {
      return `${mins}:${secs.toString().padStart(2, "0")}`;
    }
    return `${secs}s`;
  };

  const rawStatus = statusMessage || "Pensando";
  const cleanStatus = rawStatus.replace(/^[("']+|[)"']+$|\.{3,}$/g, '').trim();
  const truncatedStatus = cleanStatus.length > 28 ? cleanStatus.slice(0, 25) + "..." : cleanStatus;

  const displayElapsed = isCompleted && completedTimeSeconds ? completedTimeSeconds : elapsed;
  const activeLabel = isCompleted
    ? `Terminou em ${formatTime(displayElapsed)}`
    : `${truncatedStatus} • ${formatTime(elapsed)}`;

  const stepsToDisplay = externalSteps && externalSteps.length > 0
    ? externalSteps.map((s, i) => ({ ...s, timeSeconds: Math.max(1, Math.floor((displayElapsed / (externalSteps.length || 1)) * (i + 1))) }))
    : (recordedSteps.length > 0 ? recordedSteps : [
        { id: "step-1", label: "Conectando à IA", timeSeconds: 1, status: "success" as const },
        { id: "step-2", label: "Pensando e gerando resposta", timeSeconds: Math.max(1, displayElapsed), status: "success" as const }
      ]);

  return (
    <div className="relative inline-block select-none max-w-full">
      <motion.button
        type="button"
        onClick={() => {
          triggerHaptic('pop', true);
          setIsExpanded(!isExpanded);
        }}
        whileTap={{ scale: 0.96 }}
        className={`flex items-center gap-1.5 px-3 py-1 bg-bg-surface border rounded-full text-xs text-text-primary transition-all shadow-md active:scale-95 cursor-pointer max-w-[280px] sm:max-w-[360px] relative overflow-hidden ${
          isCompleted 
            ? "border-emerald-500/40 bg-emerald-950/10 text-emerald-300" 
            : "border-primary/50 hover:border-primary/80 bg-gradient-to-r from-bg-surface via-bg-surface-hover to-bg-surface shadow-[0_0_15px_rgba(99,102,241,0.2)]"
        }`}
        title={rawStatus}
      >
        {!isCompleted && (
          <motion.div
            animate={{ x: ["-100%", "200%"] }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-primary/20 to-transparent pointer-events-none"
          />
        )}

        {isCompleted ? (
          <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
        ) : (
          <Clock size={13} className="animate-spin text-primary shrink-0" />
        )}
        <span className="font-semibold text-[11px] text-text-primary tracking-tight truncate min-w-0 flex items-center gap-1">
          <span>{activeLabel}</span>
          {!isCompleted && <Zap size={10} className="text-primary animate-bounce shrink-0 ml-0.5" />}
        </span>
        {isExpanded ? (
          <ChevronUp size={13} className="text-text-muted shrink-0 ml-0.5" />
        ) : (
          <ChevronDown size={13} className="text-text-muted shrink-0 ml-0.5" />
        )}
      </motion.button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: 4, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 4, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute left-0 top-full mt-1.5 z-[999] min-w-[200px] max-w-[280px] p-2 bg-bg-modal text-text-primary border border-border-strong rounded-xl shadow-2xl backdrop-blur-xl"
          >
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-text-muted px-2 py-1 border-b border-border-subtle mb-1 flex items-center justify-between">
              <span>Passos da IA ({stepsToDisplay.length})</span>
              {!isCompleted && <span className="w-2 h-2 rounded-full bg-primary animate-ping" />}
            </div>
            
            {stepsToDisplay.length === 0 ? (
              <div className="px-2 py-1.5 text-xs text-text-muted italic">
                Iniciando processo em tempo real...
              </div>
            ) : (
              <div className="space-y-1 max-h-48 overflow-y-auto custom-scrollbar pr-0.5">
                {stepsToDisplay.map((step) => (
                  <div
                    key={step.id}
                    className="flex items-center justify-between gap-2 px-2 py-1 rounded-lg text-xs hover:bg-white/5 transition-colors"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {step.status === "success" || isCompleted ? (
                        <Check size={12} className="text-emerald-400 shrink-0" />
                      ) : (
                        <Clock size={12} className="animate-spin text-primary shrink-0" />
                      )}
                      <span className={`truncate text-[11px] font-medium ${step.status === "running" && !isCompleted ? "text-primary font-bold animate-pulse" : "text-text-primary"}`}>
                        {step.label}
                      </span>
                    </div>
                    <span className="font-mono text-[10px] text-text-muted shrink-0">
                      {formatTime(step.timeSeconds)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

