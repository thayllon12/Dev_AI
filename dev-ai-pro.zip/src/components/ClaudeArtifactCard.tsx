import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Code2, 
  Eye, 
  Download, 
  Copy, 
  Check, 
  Share2, 
  Maximize2, 
  Sparkles, 
  FileText, 
  Presentation, 
  FileSpreadsheet, 
  FileCode,
  FileBox,
  Globe,
  MoreVertical
} from 'lucide-react';
import { toast } from 'sonner';
import { copyToClipboard } from '../lib/utils';
import { getDeviconUrl } from '../utils/devicons';
import { generateAndDownloadFile } from '../lib/artifactGenerator';
import { HtmlPreviewModal } from './HtmlPreviewModal';

export interface ClaudeArtifactCardProps {
  title?: string;
  language: string;
  code: string;
  chatId?: string | null;
  isGenerating?: boolean;
}

export const ClaudeArtifactCard: React.FC<ClaudeArtifactCardProps> = ({
  title,
  language,
  code,
  chatId,
  isGenerating
}) => {
  const [isOpenMenu, setIsOpenMenu] = useState(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'code'>('preview');
  const menuRef = useRef<HTMLDivElement>(null);

  // Determine artifact title & type label
  const lang = (language || 'html').toLowerCase();
  const deviconSrc = getDeviconUrl(lang);
  
  const getArtifactInfo = () => {
    if (lang === 'html' || lang === 'htm') {
      return {
        defaultTitle: 'Interface Web',
        typeLabel: 'Código · HTML',
        icon: deviconSrc ? (
          <img src={deviconSrc} alt="HTML" className="w-6 h-6 object-contain" referrerPolicy="no-referrer" />
        ) : (
          <Code2 size={24} className="text-orange-400 stroke-[2.2]" />
        ),
        canPreview: true
      };
    }
    if (lang === 'pptx' || lang === 'powerpoint' || lang === 'slide' || lang === 'slides') {
      return {
        defaultTitle: 'Apresentação de Slides',
        typeLabel: 'Apresentação · PowerPoint (.pptx)',
        icon: <Presentation size={24} className="text-amber-400 stroke-[2.2]" />,
        canPreview: false
      };
    }
    if (lang === 'pdf' || lang === 'documento') {
      return {
        defaultTitle: 'Documento PDF',
        typeLabel: 'Documento · PDF',
        icon: <FileText size={24} className="text-rose-400 stroke-[2.2]" />,
        canPreview: false
      };
    }
    if (lang === 'docx' || lang === 'word') {
      return {
        defaultTitle: 'Documento Word',
        typeLabel: 'Documento · Word (.docx)',
        icon: <FileText size={24} className="text-blue-400 stroke-[2.2]" />,
        canPreview: false
      };
    }
    if (lang === 'xlsx' || lang === 'excel' || lang === 'csv') {
      return {
        defaultTitle: lang === 'csv' ? 'Tabela CSV' : 'Planilha de Dados',
        typeLabel: lang === 'csv' ? 'Arquivo · CSV' : 'Planilha · Excel (.xlsx)',
        icon: <FileSpreadsheet size={24} className="text-emerald-400 stroke-[2.2]" />,
        canPreview: false
      };
    }
    if (lang === 'md' || lang === 'markdown' || lang === 'txt' || lang === 'text' || lang === 'log') {
      return {
        defaultTitle: lang === 'md' || lang === 'markdown' ? 'Documento Markdown' : 'Arquivo de Texto',
        typeLabel: `Texto · ${lang.toUpperCase()}`,
        icon: deviconSrc ? (
          <img src={deviconSrc} alt={lang} className="w-6 h-6 object-contain" referrerPolicy="no-referrer" />
        ) : (
          <FileText size={24} className="text-blue-300 stroke-[2.2]" />
        ),
        canPreview: false
      };
    }
    if (lang === 'js' || lang === 'javascript' || lang === 'ts' || lang === 'typescript' || lang === 'py' || lang === 'python' || lang === 'json' || lang === 'css' || lang === 'lua' || lang === 'cpp' || lang === 'c' || lang === 'cs' || lang === 'go' || lang === 'rs' || lang === 'rust' || lang === 'php' || lang === 'java' || lang === 'sql') {
      return {
        defaultTitle: `${lang.toUpperCase()} Script`,
        typeLabel: `Código · ${lang.toUpperCase()}`,
        icon: deviconSrc ? (
          <img src={deviconSrc} alt={lang} className="w-6 h-6 object-contain" referrerPolicy="no-referrer" />
        ) : (
          <FileCode size={24} className="text-cyan-400 stroke-[2.2]" />
        ),
        canPreview: false
      };
    }
    return {
      defaultTitle: 'Artefato',
      typeLabel: `Arquivo · ${lang.toUpperCase()}`,
      icon: deviconSrc ? (
        <img src={deviconSrc} alt={lang} className="w-6 h-6 object-contain" referrerPolicy="no-referrer" />
      ) : (
        <FileBox size={24} className="text-purple-400 stroke-[2.2]" />
      ),
      canPreview: false
    };
  };

  const info = getArtifactInfo();
  const displayTitle = title || info.defaultTitle;

  // Click outside to close menu
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpenMenu(false);
      }
    };
    if (isOpenMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpenMenu]);

  const handleCopy = async () => {
    await copyToClipboard(code);
    setCopied(true);
    toast.success('Código copiado para a área de transferência!');
    setTimeout(() => setCopied(false), 2000);
    setIsOpenMenu(false);
  };

  const handleDownload = async () => {
    try {
      toast.info('Gerando arquivo...');
      await generateAndDownloadFile({
        title: displayTitle,
        language: lang,
        content: code
      });
      toast.success(`Download de "${displayTitle}" concluído!`);
      setIsOpenMenu(false);
    } catch (err: any) {
      console.error('Download error:', err);
      toast.error(`Erro ao gerar arquivo: ${err.message || 'Falha na exportação'}`);
    }
  };

  const handlePublish = () => {
    const event = new CustomEvent('open-github-export', { detail: { code, language: lang } });
    window.dispatchEvent(event);
    setIsOpenMenu(false);
  };

  const handleOpenMain = () => {
    if (info.canPreview) {
      setIsPreviewModalOpen(true);
    } else {
      setIsOpenMenu(prev => !prev);
    }
  };

  return (
    <>
      <div className="relative my-3 w-full max-w-xl select-none">
        {/* Claude Pill / Card Header Container */}
        <div 
          onClick={handleOpenMain}
          className="group relative flex items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-[#1C1C1E] hover:bg-[#252528] active:scale-[0.99] border border-white/10 hover:border-white/20 transition-all duration-200 cursor-pointer shadow-lg"
        >
          <div className="flex items-center gap-3.5 min-w-0">
            {/* Artifact Icon Device Mockup Icon Container */}
            <div className="w-12 h-14 rounded-xl bg-[#28282B] border border-white/10 flex items-center justify-center shrink-0 shadow-inner group-hover:scale-105 transition-transform">
              {info.icon}
            </div>

            {/* Title & Subtitle */}
            <div className="flex flex-col min-w-0 pr-2">
              <span className="text-[17px] font-semibold text-white tracking-wide truncate group-hover:text-primary transition-colors">
                {displayTitle}
              </span>
              <span className="text-[13px] font-normal text-white/50 tracking-normal mt-0.5">
                {info.typeLabel}
              </span>
            </div>
          </div>

          {/* Action Trigger Button (Menu inside Artifact) */}
          <div className="flex items-center gap-1.5 shrink-0" ref={menuRef}>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsOpenMenu(prev => !prev);
              }}
              className="p-2 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              title="Opções do Artefato"
            >
              <div className="flex flex-col gap-1 items-center justify-center w-5 h-5">
                <span className="w-1 h-1 bg-current rounded-full" />
                <span className="w-1 h-1 bg-current rounded-full" />
                <span className="w-1 h-1 bg-current rounded-full" />
              </div>
            </button>

            {/* Action Popup Menu positioned relative to container */}
            <AnimatePresence>
              {isOpenMenu && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-3 top-full mt-2 w-56 rounded-2xl bg-[#1C1C1E] border border-white/10 shadow-2xl p-1.5 z-50 overflow-hidden backdrop-blur-xl"
                  onClick={(e) => e.stopPropagation()}
                >
                  {info.canPreview && (
                    <button
                      onClick={() => {
                        setIsPreviewModalOpen(true);
                        setIsOpenMenu(false);
                      }}
                      className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-[14px] font-medium text-white/90 hover:bg-white/10 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Check size={16} className="text-white/80" />
                        <span>Ver prévia</span>
                      </div>
                      <Eye size={18} className="text-white/60" />
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setIsPreviewModalOpen(true);
                      setIsOpenMenu(false);
                    }}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-[14px] font-medium text-white/90 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-3 pl-7">
                      <span>Código</span>
                    </div>
                    <Code2 size={18} className="text-white/60" />
                  </button>

                  <button
                    onClick={handlePublish}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-[14px] font-medium text-white/90 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-3 pl-7">
                      <span>Publicar</span>
                    </div>
                    <Share2 size={18} className="text-white/60" />
                  </button>

                  <button
                    onClick={handleCopy}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-[14px] font-medium text-white/90 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-3 pl-7">
                      <span>Copiar</span>
                    </div>
                    {copied ? <Check size={18} className="text-emerald-400" /> : <Copy size={18} className="text-white/60" />}
                  </button>

                  <button
                    onClick={handleDownload}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-[14px] font-medium text-white/90 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-3 pl-7">
                      <span>Baixar</span>
                    </div>
                    <Download size={18} className="text-white/60" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Preview Modal */}
      {isPreviewModalOpen && (
        <HtmlPreviewModal
          isOpen={isPreviewModalOpen}
          onClose={() => setIsPreviewModalOpen(false)}
          code={code}
          chatId={chatId}
          isGenerating={isGenerating}
        />
      )}
    </>
  );
};
