import React, { useEffect, useState, useRef } from 'react';
import { getSocket } from '../lib/socket';
import { PhoneCall, Mic, MicOff, PhoneOff, Volume2, VolumeX, Users, ChevronDown } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';

export function VoiceCallManager({ currentUser }: { currentUser: any }) {
  const [isInCall, setIsInCall] = useState(false);
  const [incomingCall, setIncomingCall] = useState<{ chatId: string, caller: any } | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isDeaf, setIsDeaf] = useState(false);
  const [participants, setParticipants] = useState<any[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);

  const localStreamRef = useRef<MediaStream | null>(null);
  const peersRef = useRef<Record<string, RTCPeerConnection>>({});
  const audioRefs = useRef<Record<string, HTMLAudioElement>>({});

  useEffect(() => {
    if (!currentUser) return;

    const socket = getSocket();

    const handleOpenCall = (e: CustomEvent) => {
      const { chatId } = e.detail;
      startCall(chatId);
    };

    window.addEventListener('open-voice-call', handleOpenCall as EventListener);

    socket.on('call-invite', (data) => {
      if (!isInCall && data.caller.uid !== currentUser.uid) {
        setIncomingCall({ chatId: data.chatId, caller: data.caller });
        toast('Recebendo chamada...', { icon: '📞' });
      }
    });

    socket.on('user-joined-call', async (user) => {
      if (!isInCall) return;
      toast.success(`${user.displayName || 'Usuário'} entrou na chamada.`);
      setParticipants(prev => [...prev.filter(p => p.uid !== user.uid), user]);
      // Initiate WebRTC connection to new user
      createPeerConnection(user.uid, true);
    });

    socket.on('user-left-call', (uid) => {
      if (!isInCall) return;
      setParticipants(prev => prev.filter(p => p.uid !== uid));
      if (peersRef.current[uid]) {
        peersRef.current[uid].close();
        delete peersRef.current[uid];
      }
      if (audioRefs.current[uid]) {
        audioRefs.current[uid].srcObject = null;
        delete audioRefs.current[uid];
      }
    });

    socket.on('webrtc-offer', async (data) => {
      if (!isInCall) return;
      const pc = createPeerConnection(data.sender, false);
      await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit('webrtc-answer', { target: data.sender, answer, sender: currentUser.uid });
    });

    socket.on('webrtc-answer', async (data) => {
      if (!isInCall) return;
      const pc = peersRef.current[data.sender];
      if (pc) {
        await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
      }
    });

    socket.on('webrtc-ice-candidate', async (data) => {
      if (!isInCall) return;
      const pc = peersRef.current[data.sender];
      if (pc) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
        } catch (e) {
          console.error('Error adding ICE candidate', e);
        }
      }
    });

    return () => {
      window.removeEventListener('open-voice-call', handleOpenCall as EventListener);
      socket.off('call-invite');
      socket.off('user-joined-call');
      socket.off('user-left-call');
      socket.off('webrtc-offer');
      socket.off('webrtc-answer');
      socket.off('webrtc-ice-candidate');
    };
  }, [currentUser, isInCall]);

  const createPeerConnection = (targetUid: string, isInitiator: boolean) => {
    const socket = getSocket();
    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
      ]
    });

    peersRef.current[targetUid] = pc;

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        pc.addTrack(track, localStreamRef.current!);
      });
    }

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        socket.emit('webrtc-ice-candidate', { target: targetUid, candidate: event.candidate, sender: currentUser.uid });
      }
    };

    pc.ontrack = (event) => {
      if (!audioRefs.current[targetUid]) {
        const audio = new Audio();
        audio.autoplay = true;
        audioRefs.current[targetUid] = audio;
      }
      audioRefs.current[targetUid].srcObject = event.streams[0];
    };

    if (isInitiator) {
      pc.createOffer().then(offer => {
        pc.setLocalDescription(offer);
        socket.emit('webrtc-offer', { target: targetUid, offer, sender: currentUser.uid });
      });
    }

    return pc;
  };

  const startCall = async (chatId: string) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      localStreamRef.current = stream;
      setIsInCall(true);
      setCurrentChatId(chatId);
      setParticipants([{ uid: currentUser.uid, displayName: currentUser.displayName }]);
      
      const socket = getSocket();
      socket.emit('join-call', { chatId, user: { uid: currentUser.uid, displayName: currentUser.displayName } });
    } catch (err) {
      toast.error('Erro ao acessar o microfone.');
      console.error(err);
    }
  };

  const [callDuration, setCallDuration] = useState(0);
  const [isExpanded, setIsExpanded] = useState(true);

  useEffect(() => {
    let timer: any;
    if (isInCall) {
      timer = setInterval(() => setCallDuration(prev => prev + 1), 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(timer);
  }, [isInCall]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const acceptCall = () => {
    if (incomingCall) {
      startCall(incomingCall.chatId);
      setIncomingCall(null);
    }
  };

  const rejectCall = () => {
    setIncomingCall(null);
  };

  const leaveCall = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(t => t.stop());
      localStreamRef.current = null;
    }
    Object.values(peersRef.current).forEach(pc => pc.close());
    peersRef.current = {};
    Object.values(audioRefs.current).forEach(audio => { audio.srcObject = null; });
    audioRefs.current = {};
    
    if (currentChatId) {
      getSocket().emit('leave-call', { chatId: currentChatId, uid: currentUser.uid });
    }
    
    setIsInCall(false);
    setCurrentChatId(null);
    setParticipants([]);
    toast('Você saiu da chamada.');
  };

  const toggleMute = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach(t => t.enabled = isMuted);
      setIsMuted(!isMuted);
    }
  };

  const toggleDeaf = () => {
    Object.values(audioRefs.current).forEach(audio => {
      audio.muted = !isDeaf;
    });
    setIsDeaf(!isDeaf);
  };

  return (
    <>
      <AnimatePresence>
        {incomingCall && !isInCall && (
          <motion.div
            initial={{ opacity: 0, y: -20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: -20, x: '-50%' }}
            className="fixed top-20 left-1/2 z-[1000] bg-bg-surface border border-primary/30 p-4 rounded-2xl shadow-2xl flex flex-col items-center gap-3 w-[300px]"
          >
            <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center animate-pulse">
              <PhoneCall className="text-primary" size={24} />
            </div>
            <div className="text-center">
              <div className="font-bold text-text-primary text-lg">{incomingCall.caller.displayName || 'Alguém'}</div>
              <div className="text-text-muted text-sm">está ligando para você</div>
            </div>
            <div className="flex gap-4 w-full mt-2">
              <button onClick={rejectCall} className="flex-1 py-2 bg-red-500/20 text-red-500 rounded-xl font-medium hover:bg-red-500/30 transition-colors">
                Recusar
              </button>
              <button onClick={acceptCall} className="flex-1 py-2 bg-emerald-500 text-white rounded-xl font-medium hover:bg-emerald-600 transition-colors">
                Aceitar
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isInCall && isExpanded && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-[100000] bg-[#0d0f12] text-white flex flex-col justify-between p-4 sm:p-6 select-none"
          >
            {/* Header */}
            <div className="flex items-center justify-between w-full max-w-4xl mx-auto pt-2">
              <button
                onClick={() => setIsExpanded(false)}
                className="p-2.5 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
                title="Minimizar chamada"
              >
                <ChevronDown size={24} />
              </button>

              <div className="flex flex-col items-center">
                <span className="font-bold text-lg text-white">Chamada de Voz em Grupo</span>
                <span className="text-xs text-emerald-400 font-mono flex items-center gap-1.5 mt-0.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  {formatDuration(callDuration)}
                </span>
              </div>

              <div className="p-2 text-white/80 bg-white/10 rounded-full text-xs font-bold flex items-center gap-1.5 px-3">
                <Users size={16} />
                <span>{participants.length}</span>
              </div>
            </div>

            {/* Participants Grid (matching Screenshot 6) */}
            <div className="flex-1 w-full max-w-4xl mx-auto my-6 grid grid-cols-2 sm:grid-cols-3 gap-4 items-center justify-center overflow-y-auto custom-scrollbar p-2">
              {participants.map((p) => {
                const isMe = p.uid === currentUser.uid;
                return (
                  <div
                    key={p.uid}
                    className="relative bg-[#1a1d24] border border-white/10 rounded-3xl p-6 flex flex-col items-center justify-center gap-4 aspect-square shadow-xl group"
                  >
                    <div className="relative">
                      {/* Active speaker animation ring */}
                      <div className="absolute -inset-2 rounded-full bg-emerald-500/30 animate-ping" />
                      <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 p-1 flex items-center justify-center shadow-lg relative z-10">
                        {p.photoURL ? (
                          <img src={p.photoURL} alt={p.displayName} className="w-full h-full rounded-full object-cover" />
                        ) : (
                          <div className="w-full h-full rounded-full bg-[#272b35] flex items-center justify-center text-2xl font-black text-white uppercase">
                            {(p.displayName || "U")[0]}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="text-center z-10">
                      <span className="font-bold text-sm sm:text-base text-white block truncate max-w-[140px]">
                        {isMe ? "Você" : p.displayName || "Participante"}
                      </span>
                      <span className="text-[11px] text-emerald-400 font-medium">
                        {isMe && isMuted ? "Microfone desligado" : "Conectado"}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Controls Bar */}
            <div className="w-full max-w-md mx-auto bg-[#181b22] border border-white/10 rounded-full p-3 shadow-2xl flex items-center justify-around z-50">
              <button
                onClick={toggleMute}
                className={`p-4 rounded-full transition-all ${
                  isMuted ? "bg-red-500/20 text-red-500" : "bg-white/10 text-white hover:bg-white/20"
                }`}
                title={isMuted ? "Ativar Microfone" : "Desativar Microfone"}
              >
                {isMuted ? <MicOff size={22} /> : <Mic size={22} />}
              </button>

              <button
                onClick={toggleDeaf}
                className={`p-4 rounded-full transition-all ${
                  isDeaf ? "bg-red-500/20 text-red-500" : "bg-white/10 text-white hover:bg-white/20"
                }`}
                title={isDeaf ? "Ativar Som" : "Desativar Som"}
              >
                {isDeaf ? <VolumeX size={22} /> : <Volume2 size={22} />}
              </button>

              <button
                onClick={leaveCall}
                className="p-4 bg-red-600 hover:bg-red-700 text-white rounded-full transition-all shadow-lg shadow-red-600/40 hover:scale-105 active:scale-95"
                title="Desconectar Chamada"
              >
                <PhoneOff size={22} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isInCall && !isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            onClick={() => setIsExpanded(true)}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[1000] bg-[#181b22] border border-emerald-500/40 p-3 rounded-full shadow-2xl flex items-center gap-4 cursor-pointer hover:border-emerald-500 transition-all"
          >
            <div className="flex items-center gap-2 px-3">
              <div className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </div>
              <span className="text-sm font-bold text-emerald-400">Chamada ({formatDuration(callDuration)})</span>
              <span className="text-xs text-text-muted ml-1 bg-white/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                <Users size={12} /> {participants.length}
              </span>
            </div>

            <div className="w-px h-6 bg-white/10 mx-1" />

            <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
              <button 
                onClick={toggleMute}
                className={`p-2.5 rounded-full transition-colors ${isMuted ? 'bg-red-500/20 text-red-500' : 'bg-white/10 text-white hover:bg-white/20'}`}
                title={isMuted ? "Ativar Microfone" : "Silenciar Microfone"}
              >
                {isMuted ? <MicOff size={18} /> : <Mic size={18} />}
              </button>

              <button 
                onClick={leaveCall}
                className="p-2.5 bg-red-600 hover:bg-red-700 text-white rounded-full transition-colors shadow-lg shadow-red-600/30"
                title="Sair da Chamada"
              >
                <PhoneOff size={18} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
