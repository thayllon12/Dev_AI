import React, { useState, useRef, useEffect, lazy, Suspense, memo, useMemo } from "react";
import {
  Copy,
  CheckCheck,
  ChevronUp,
  ChevronDown,
  Play,
  Maximize2,
  Download,
  File,
  ExternalLink,
  ShieldAlert,
  ArrowDown,
  Server,
  Code2,
  RotateCcw,
  Github
} from "lucide-react";
import { copyToClipboard } from "../lib/utils";
import { toast } from "sonner";
import { HtmlPreviewModal } from "./HtmlPreviewModal";
import { auth } from "../firebase";
import { getDeviconUrl } from "../utils/devicons";

const highlightCache = new Map<string, string>();

const highlightLine = (line: string) => {
  if (!line) return "";
  const keywords = new Set(["const", "let", "var", "function", "return", "if", "else", "for", "while", "class", "import", "export", "from", "default", "interface", "type", "public", "private", "protected", "async", "await", "new", "this", "super", "extends", "implements", "true", "false", "null", "undefined", "switch", "case", "break", "continue", "DOCTYPE", "html", "head", "body", "meta", "title", "style", "script", "link", "div", "span", "p", "a"]);
  
  let result = "";
  let i = 0;
  
  const escapeHtml = (str: string) => str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  while (i < line.length) {
    if (line.startsWith('//', i) || line.startsWith('/*', i)) {
      result += `<span style="color: #a8ff60; font-style: italic">${escapeHtml(line.substring(i))}</span>`;
      break;
    }

    if (line[i] === '"' || line[i] === "'" || line[i] === "`") {
      const quote = line[i];
      let end = i + 1;
      while (end < line.length && line[end] !== quote) {
        if (line[end] === '\\') end++;
        end++;
      }
      if (end < line.length) end++;
      result += `<span style="color: #f1fa8c">${escapeHtml(line.substring(i, end))}</span>`;
      i = end;
      continue;
    }

    if (/[a-zA-Z_$]/.test(line[i])) {
      let end = i + 1;
      while (end < line.length && /[a-zA-Z0-9_$-]/.test(line[end])) {
        end++;
      }
      const word = line.substring(i, end);
      
      let j = end;
      while(j < line.length && /\s/.test(line[j])) j++;
      if (j < line.length && line[j] === '(') {
         result += `<span style="color: #50fa7b; font-weight: bold">${escapeHtml(word)}</span>`;
      } else if (keywords.has(word) || keywords.has(word.toLowerCase())) {
         result += `<span style="color: #ff79c6; font-weight: bold">${escapeHtml(word)}</span>`;
      } else {
         result += escapeHtml(word);
      }
      
      i = end;
      continue;
    }

    if (/[0-9]/.test(line[i])) {
      let end = i + 1;
      while (end < line.length && /[0-9.]/.test(line[end])) end++;
      result += `<span style="color: #bd93f9">${escapeHtml(line.substring(i, end))}</span>`;
      i = end;
      continue;
    }

    if (line[i] === '<' || line[i] === '>') {
      result += `<span style="color: #ff79c6">${escapeHtml(line[i])}</span>`;
      i++;
      continue;
    }

    result += escapeHtml(line[i]);
    i++;
  }

  return result;
};

const highlightLineCached = (line: string) => {
  if (!line) return "";
  if (line.length > 2000) return line.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const cached = highlightCache.get(line);
  if (cached !== undefined) return cached;
  const result = highlightLine(line);
  if (highlightCache.size > 8000) highlightCache.clear();
  highlightCache.set(line, result);
  return result;
};

const NativeHighlighter = memo(({ code, chatId, codeWrap, isGenerating }: { code: string, chatId?: string | null, codeWrap?: boolean, isGenerating?: boolean }) => {
  const lines = useMemo(() => {
    if (!code) return [""];
    const rawLines = code.split("\n");
    if (isGenerating || code.length > 200000) {
      return rawLines.map(l => l.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    return rawLines.map(highlightLineCached);
  }, [code, isGenerating]);

  return (
    <div className="w-full overflow-x-auto custom-scrollbar bg-transparent">
      <table className="w-full border-collapse font-mono text-[13px] leading-[1.5]">
        <tbody>
          {lines.map((lineHtml, i) => {
            const isLastLine = i === lines.length - 1;
            const content = isGenerating && isLastLine 
              ? (lineHtml || '&nbsp;') + '<span class="inline-block w-[6px] h-[1em] ml-0.5 bg-white align-middle animate-pulse shadow-[0_0_8px_rgba(255,255,255,0.8)] shrink-0 pointer-events-none"></span>'
              : (lineHtml || '&nbsp;');

            return (
              <tr key={i} className="hover:bg-white/[0.04] transition-colors group">
                <td 
                  className="select-none text-right pr-2 pl-0.5 text-white/30 group-hover:text-white/70 align-top shrink-0 font-mono text-[11px] py-0.5 bg-transparent whitespace-nowrap"
                  style={{ width: "1%" }}
                >
                  {i + 1}
                </td>
                <td 
                  className={`pl-1 pr-2 align-top font-mono py-0.5 text-[#d4d4d4] ${
                    codeWrap ? 'whitespace-pre-wrap break-words' : 'whitespace-pre'
                  }`}
                  dangerouslySetInnerHTML={{ __html: content }}
                />
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
});

const lazyWithRetry = (componentImport: () => Promise<any>) => 
  lazy(async () => {
    const pageHasAlreadyBeenForceRefreshed = JSON.parse(
      window.sessionStorage.getItem('page-has-been-force-refreshed') || 'false'
    );
    try {
      const component = await componentImport();
      window.sessionStorage.setItem('page-has-been-force-refreshed', 'false');
      return component;
    } catch (error) {
      if (!pageHasAlreadyBeenForceRefreshed) {
        window.sessionStorage.setItem('page-has-been-force-refreshed', 'true');
        window.location.reload();
      }
      throw error;
    }
  });




export const CodeBlock = memo(function CodeBlock({
  language,
  code,
  userSettings,
  fullMessageContent,
  onAnalyzeSecurity,
  onAskAI,
  isGenerating,
  hideHeader,
  chatId,
}: {
  language: string;
  code: string;
  userSettings: any;
  fullMessageContent?: string;
  onAnalyzeSecurity?: (code: string) => void;
  onAskAI?: (code: string) => void;
  isGenerating?: boolean;
  hideHeader?: boolean;
  chatId?: string | null;
}) {
  const [copied, setCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(!!isGenerating);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isConstrained, setIsConstrained] = useState(true);
  const [downloadState, setDownloadState] = useState<"idle" | "downloading" | "success">("idle");
  const [showHtmlPreview, setShowHtmlPreview] = useState(false);
  const [iconError, setIconError] = useState(false);
  const [iframeRefreshCount, setIframeRefreshCount] = useState(0);

  const deviconUrl = useMemo(() => getDeviconUrl(language), [language]);

  const codeContainerRef = useRef<HTMLDivElement>(null);
  const scrollPositionRef = useRef<number>(0);

  const lineCount = useMemo(() => (code ? code.split("\n").length : 0), [code]);
  const isLongCode = lineCount > 15;

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    scrollPositionRef.current = e.currentTarget.scrollTop;
  };

  const scrollToBottom = () => {
    if (codeContainerRef.current) {
      codeContainerRef.current.scrollTo({
        top: codeContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
      scrollPositionRef.current = codeContainerRef.current.scrollHeight;
    }
  };

  const isSelectingTextRef = useRef(false);
  useEffect(() => {
    const handleSelectionChange = () => {
      const selection = window.getSelection();
      isSelectingTextRef.current = selection && selection.toString().length > 0;
    };
    document.addEventListener("selectionchange", handleSelectionChange);
    return () => document.removeEventListener("selectionchange", handleSelectionChange);
  }, []);

  useEffect(() => {
    if (isGenerating && codeContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = codeContainerRef.current;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 100; // 100px tolerance
      
      if (isNearBottom && !isSelectingTextRef.current) {
        // Use animation frame to ensure DOM has painted the new text
        requestAnimationFrame(() => {
          if (codeContainerRef.current) {
             codeContainerRef.current.scrollTo({
               top: codeContainerRef.current.scrollHeight,
               behavior: "auto" // smooth can lag behind fast generation
             });
          }
        });
      }
    }
  }, [code, isGenerating]);

  const handleCopy = async () => {
    await copyToClipboard(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setDownloadState("downloading");
    try {
      let useFallback = false;
      const suggestedName = `code_${Date.now()}.${language || "txt"}`;
      
      if ('showSaveFilePicker' in window) {
        try {
          const handle = await (window as any).showSaveFilePicker({
            suggestedName,
            types: [
              {
                description: 'Code file',
                accept: { 'text/plain': [`.${language || "txt"}`] },
              },
            ],
          });
          const writable = await handle.createWritable();
          await writable.write(code);
          await writable.close();
        } catch (err: any) {
          if (err.name === 'AbortError') {
            setDownloadState("idle");
            return; // User cancelled
          }
          console.warn("showSaveFilePicker failed, using fallback:", err);
          useFallback = true;
        }
      } else {
        useFallback = true;
      }

      if (useFallback) {
        const blob = new Blob([code], { type: "text/plain" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = suggestedName;
        // Important: Needs to be in DOM for some iframe config downloads to work
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
      
      setDownloadState("success");
      setTimeout(() => setDownloadState("idle"), 1500);

    } catch (err) {
      console.error("Failed to save file", err);
      setDownloadState("idle");
    }
  };

  const handlePreviewHtml = () => {
    setShowHtmlPreview(true);
  };

  return (
    <>
      {isFullScreen && (
        <div className="extended-editor-modal fixed inset-0 z-[200] bg-black/95 backdrop-blur-xl flex flex-col p-0 animate-in fade-in zoom-in duration-300">
          <div className="flex items-center justify-between p-3 sm:p-4 border-b border-white/10 bg-bg-surface text-white">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-white/90 font-mono text-xs font-bold uppercase tracking-wider shrink-0">
                {deviconUrl && !iconError ? (
                  <img 
                    src={deviconUrl} 
                    alt={language} 
                    className="w-4 h-4 object-contain" 
                    onError={() => setIconError(true)} 
                  />
                ) : (
                  <Code2 size={14} className="stroke-[2.5]" />
                )}
                <span className="truncate max-w-[100px] sm:max-w-none">{language || "text"}</span>
              </div>
              <span className="text-xs font-mono text-white/40 shrink-0">
                {lineCount} {lineCount === 1 ? "linha" : "linhas"}
              </span>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* 1. Play / Jogar (se HTML/SVG) */}
              {(language?.toLowerCase() === "html" || language?.toLowerCase() === "svg") && (
                <button
                  onClick={handlePreviewHtml}
                  className="h-8 px-3 rounded-lg bg-white/5 hover:bg-white/10 text-white/80 hover:text-white border border-white/10 transition-all active:scale-95 flex items-center justify-center gap-1.5 text-xs font-medium"
                  title="Testar / Visualizar HTML"
                >
                  <Play size={14} strokeWidth={2.2} />
                  <span>Testar</span>
                </button>
              )}

              {/* 2. Download */}
              <button
                onClick={handleDownload}
                className={`h-8 px-3 rounded-lg transition-all border active:scale-95 flex items-center gap-1.5 text-xs text-white/80 ${
                  downloadState === 'success' 
                    ? 'bg-green-500/20 text-green-400 border-green-500/30' : 
                  downloadState === 'downloading' 
                    ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30 animate-pulse' : 
                    'bg-white/5 hover:bg-white/10 hover:text-white border-white/10'
                }`}
                title={downloadState === 'success' ? 'Download concluído' : 'Baixar arquivo'}
              >
                {downloadState === 'success' ? <CheckCheck size={14} /> : <Download size={14} />}
                <span className="hidden sm:inline">Download</span>
              </button>

              {/* Exportar GitHub */}
              <button
                onClick={() => {
                  const event = new CustomEvent('open-github-export', { detail: { code, language } });
                  window.dispatchEvent(event);
                }}
                className="h-8 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-xs text-white/80 hover:text-white flex items-center gap-1.5"
                title="Exportar para GitHub"
              >
                <Github size={14} />
                <span className="hidden sm:inline">GitHub</span>
              </button>

              {/* 3. Copiar */}
              <button
                onClick={handleCopy}
                className="h-8 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-xs text-white/80 hover:text-white flex items-center gap-1.5"
                title="Copiar código"
              >
                {copied ? <CheckCheck size={14} className="text-emerald-400" /> : <Copy size={14} />}
                <span>{copied ? "Copiado!" : "Copiar"}</span>
              </button>

              {/* 4. Sair da tela cheia (Desexpandir) */}
              <button
                onClick={() => setIsFullScreen(false)}
                className="h-8 p-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 hover:text-white rounded-lg transition-colors flex items-center gap-1"
                title="Sair da tela cheia"
              >
                <Maximize2 size={16} className="rotate-180" />
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-auto bg-bg-code">
             <div className="p-3 sm:p-6 font-mono text-sm">
                <NativeHighlighter code={code} chatId={chatId} codeWrap={userSettings?.codeWrap} isGenerating={isGenerating} />
             </div>
          </div>
        </div>
      )}

      <div className={`overflow-hidden bg-bg-code w-full max-w-full min-w-0 [content-visibility:auto] [contain-intrinsic-size:100px] ${hideHeader ? "my-0 rounded-none border-none h-full flex flex-col" : "my-4 rounded-xl border border-border-strong"}`}>
        {!hideHeader && (<div className="flex items-center justify-between px-2 sm:px-3 py-1.5 bg-bg-code-header text-text-muted text-xs font-sans w-full custom-scrollbar gap-2 border-b border-border-subtle/40">
          <div className="flex items-center gap-2 shrink-0 min-w-0">
            <div className="flex items-center gap-1.5 px-2 py-0.5 h-7 rounded-md bg-white/5 border border-white/10 text-white/90 font-mono text-[11px] font-bold uppercase tracking-wider shrink-0">
              {deviconUrl && !iconError ? (
                <img 
                  src={deviconUrl} 
                  alt={language} 
                  className="w-3.5 h-3.5 object-contain" 
                  onError={() => setIconError(true)} 
                />
              ) : (
                <Code2 size={13} className="stroke-[2.5]" />
              )}
              <span className="truncate max-w-[80px] sm:max-w-none">{language || "text"}</span>
            </div>
            <span className="text-[11px] font-mono text-text-muted/70 shrink-0">
              {lineCount} {lineCount === 1 ? "linha" : "linhas"}
            </span>
          </div>

          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            {/* 1. Testar HTML (se for HTML ou SVG) */}
            {(language?.toLowerCase() === "html" || language?.toLowerCase() === "svg") && (
              <button
                onClick={handlePreviewHtml}
                className="h-7 w-7 rounded-md bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all border border-white/5 active:scale-95 flex items-center justify-center shrink-0"
                title="Testar / Visualizar HTML"
              >
                <Play size={14} strokeWidth={2.2} />
              </button>
            )}

            {/* 2. Minimizar / Recolher */}
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="h-7 w-7 rounded-md bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all border border-white/5 active:scale-95 flex items-center justify-center shrink-0"
              title={isExpanded ? "Recolher código" : "Expandir código"}
            >
              {isExpanded ? <ChevronUp size={14} strokeWidth={2.2} /> : <ChevronDown size={14} strokeWidth={2.2} />}
            </button>

            {/* 3. Expandir / Tela Cheia */}
            <button
              onClick={() => setIsFullScreen(true)}
              className="h-7 w-7 rounded-md bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all border border-white/5 active:scale-95 flex items-center justify-center shrink-0"
              title="Expandir em tela cheia"
            >
              <Maximize2 size={14} strokeWidth={2.2} />
            </button>

            {/* 4. Download */}
            <button
              onClick={handleDownload}
              className={`h-7 w-7 rounded-md transition-all border active:scale-95 flex items-center justify-center shrink-0 ${
                downloadState === 'success' 
                  ? 'bg-green-500/20 text-green-400 border-green-500/30' : 
                downloadState === 'downloading' 
                  ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30 animate-pulse' : 
                  'bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border-white/5'
              }`}
              title={downloadState === 'success' ? 'Download concluído' : 'Baixar arquivo'}
            >
              {downloadState === 'success' ? <CheckCheck size={14} strokeWidth={2.3} /> : <Download size={14} strokeWidth={2.2} />}
            </button>

            {/* Exportar GitHub */}
            <button
              onClick={() => {
                const event = new CustomEvent('open-github-export', { detail: { code, language } });
                window.dispatchEvent(event);
              }}
              className="h-7 w-7 rounded-md bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all border border-white/5 active:scale-95 flex items-center justify-center shrink-0"
              title="Exportar para GitHub"
            >
              <Github size={14} strokeWidth={2.2} />
            </button>

            {/* 5. Copiar */}
            <button
              onClick={handleCopy}
              className="h-7 w-7 rounded-md bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all border border-white/5 active:scale-95 flex items-center justify-center shrink-0"
              title={copied ? "Copiado!" : "Copiar código"}
            >
              {copied ? (
                <CheckCheck size={14} strokeWidth={2.3} className="text-emerald-400" />
              ) : (
                <Copy size={14} strokeWidth={2.2} />
              )}
            </button>
          </div>
        </div>)}
        {(isExpanded || hideHeader) && (
          <div className="relative group">
            <div 
              ref={codeContainerRef}
              onScroll={handleScroll}
              className={`p-4 overflow-x-auto overscroll-contain text-[13px] font-mono custom-scrollbar ${isConstrained && isLongCode && !hideHeader && !isFullScreen ? 'max-h-[50vh] overflow-y-auto' : ''} ${hideHeader || isFullScreen ? 'flex-1 overflow-y-auto' : ''}`}
            >
              <NativeHighlighter code={code} chatId={chatId} codeWrap={userSettings?.codeWrap} isGenerating={isGenerating} />
            </div>
            
            {isConstrained && isLongCode && (
              <button
                onClick={scrollToBottom}
                className="absolute bottom-4 right-4 bg-bg-surface border border-border-strong text-text-muted hover:text-primary p-2.5 rounded-xl shadow-xl opacity-20 hover:opacity-100 transition-opacity z-10"
                title="Rolar para o final do bloco"
              >
                <ArrowDown size={18} />
              </button>
            )}
          </div>
        )}
      </div>

      <HtmlPreviewModal 
         isOpen={showHtmlPreview} 
         onClose={() => setShowHtmlPreview(false)} 
         code={code} 
         chatId={chatId}
         isGenerating={isGenerating}
      />
    </>
  );
});
