import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Folder, 
  FolderOpen, 
  FileCode, 
  Eye, 
  Code2, 
  Download, 
  Copy, 
  Check, 
  MoreVertical, 
  X, 
  ChevronRight, 
  ChevronDown,
  Layers,
  FileText,
  FileSpreadsheet,
  Presentation,
  Archive,
  ExternalLink,
  RotateCcw
} from 'lucide-react';
import { toast } from 'sonner';
import { copyToClipboard } from '../lib/utils';
import { getDeviconUrl } from '../utils/devicons';
import { HtmlPreviewModal } from './HtmlPreviewModal';
import { generateAndDownloadFile } from '../lib/artifactGenerator';
import JSZip from 'jszip';

export interface ArtifactFile {
  name: string;
  path: string;
  language: string;
  content: string;
}

export interface MultiFileArtifactProps {
  title?: string;
  language?: string;
  code?: string;
  files?: ArtifactFile[];
  chatId?: string | null;
  isGenerating?: boolean;
}

// Parses multiline file blocks formatted as:
// === FILE: path/to/file.ext === or // FILE: path/to/file.ext
export function parseMultiFileProject(rawContent: string, defaultLanguage: string): { title: string; files: ArtifactFile[] } {
  const lines = rawContent.split('\n');
  const files: ArtifactFile[] = [];
  let currentFile: ArtifactFile | null = null;
  let currentLines: string[] = [];

  const fileMarkerRegex = /^(?:={3,}\s*(?:FILE|ARQUIVO):\s*(.+?)\s*={3,}|\/\/\s*(?:FILE|ARQUIVO):\s*(.+?)$|#\s*(?:FILE|ARQUIVO):\s*(.+?)$)/i;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const match = line.match(fileMarkerRegex);

    if (match) {
      const filePath = (match[1] || match[2] || match[3]).trim();
      if (currentFile) {
        currentFile.content = currentLines.join('\n').trim();
        files.push(currentFile);
      }
      const parts = filePath.split('/');
      const fileName = parts[parts.length - 1];
      const ext = fileName.includes('.') ? fileName.split('.').pop() || defaultLanguage : defaultLanguage;

      currentFile = {
        name: fileName,
        path: filePath,
        language: ext.toLowerCase(),
        content: ''
      };
      currentLines = [];
    } else {
      if (currentFile) {
        currentLines.push(line);
      } else {
        currentLines.push(line);
      }
    }
  }

  if (currentFile) {
    currentFile.content = currentLines.join('\n').trim();
    files.push(currentFile);
  }

  // If no multiple file markers found, create a single file artifact
  if (files.length === 0) {
    const ext = defaultLanguage.toLowerCase();
    const defaultName = ext === 'html' ? 'index.html' : ext === 'css' ? 'styles.css' : ext === 'js' ? 'index.js' : ext === 'ts' ? 'index.ts' : `artifact.${ext}`;
    files.push({
      name: defaultName,
      path: defaultName,
      language: ext,
      content: rawContent
    });
  }

  return {
    title: files.length > 1 ? `Projeto (${files.length} arquivos)` : files[0].name,
    files
  };
}

export const MultiFileArtifactCard: React.FC<MultiFileArtifactProps> = ({
  title,
  language = 'html',
  code = '',
  files: initialFiles,
  chatId,
  isGenerating
}) => {
  const [isOpenMenu, setIsOpenMenu] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isProjectExpanded, setIsProjectExpanded] = useState(false);
  const [selectedFilePath, setSelectedFilePath] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const parsed = React.useMemo(() => {
    if (initialFiles && initialFiles.length > 0) {
      return { title: title || `Projeto (${initialFiles.length} arquivos)`, files: initialFiles };
    }
    return parseMultiFileProject(code, language);
  }, [code, language, initialFiles, title]);

  const files = parsed.files;
  const activeFile = files.find(f => f.path === selectedFilePath) || files[0] || { name: 'file', path: 'file', language: 'text', content: code };

  useEffect(() => {
    if (!selectedFilePath && files.length > 0) {
      setSelectedFilePath(files[0].path);
    }
  }, [files, selectedFilePath]);

  // Click outside menu handler
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpenMenu(false);
      }
    };
    if (isOpenMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpenMenu]);

  // Can HTML preview be executed?
  const hasHtml = files.some(f => f.name.endsWith('.html') || f.language === 'html');
  const mainHtmlContent = React.useMemo(() => {
    const htmlFile = files.find(f => f.name.endsWith('.html') || f.language === 'html');
    if (!htmlFile) return activeFile.content;
    
    // Inject JS and CSS files into HTML preview if present
    let combined = htmlFile.content;
    const cssFiles = files.filter(f => f.name.endsWith('.css'));
    const jsFiles = files.filter(f => f.name.endsWith('.js') || f.name.endsWith('.ts'));

    if (cssFiles.length > 0) {
      const styleTags = cssFiles.map(c => `<style>\n/* ${c.path} */\n${c.content}\n</style>`).join('\n');
      if (combined.includes('</head>')) {
        combined = combined.replace('</head>', `${styleTags}\n</head>`);
      } else {
        combined = `${styleTags}\n${combined}`;
      }
    }

    if (jsFiles.length > 0) {
      const scriptTags = jsFiles.map(j => `<script>\n// ${j.path}\n${j.content}\n</script>`).join('\n');
      if (combined.includes('</body>')) {
        combined = combined.replace('</body>', `${scriptTags}\n</body>`);
      } else {
        combined = `${combined}\n${scriptTags}`;
      }
    }

    return combined;
  }, [files, activeFile]);

  const handleCopy = () => {
    copyToClipboard(activeFile.content);
    setCopied(true);
    toast.success("Conteúdo copiado!");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    try {
      const zip = new JSZip();
      files.forEach(f => {
        zip.file(f.path, f.content);
      });
      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(title || 'projeto').toLowerCase().replace(/\s+/g, '_')}.zip`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Projeto baixado em .ZIP!");
    } catch (e: any) {
      toast.error("Erro ao gerar ZIP.");
    }
  };

  const deviconUrl = getDeviconUrl(activeFile.language || language);

  return (
    <>
      <div className="relative my-3 w-full max-w-2xl select-none">
        {/* Main Card Container */}
        <div className="group relative rounded-2xl bg-[#1C1C1E] border border-white/10 hover:border-white/20 transition-all duration-200 shadow-xl overflow-hidden backdrop-blur-xl">
          
          {/* Header Bar */}
          <div 
            onClick={() => {
              if (hasHtml) setIsPreviewOpen(true);
              else setIsProjectExpanded(!isProjectExpanded);
            }}
            className="flex items-center justify-between p-3.5 sm:p-4 cursor-pointer hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3 min-w-0">
              {/* Language Icon */}
              <div className="w-11 h-12 rounded-xl bg-[#28282B] border border-white/10 flex items-center justify-center shrink-0 shadow-inner group-hover:scale-105 transition-transform overflow-hidden p-2">
                {deviconUrl ? (
                  <img src={deviconUrl} alt={activeFile.language} className="w-6 h-6 object-contain" />
                ) : (
                  <FileCode size={22} className="text-primary" />
                )}
              </div>

              {/* Title and details */}
              <div className="flex flex-col min-w-0 pr-2">
                <span className="text-base font-semibold text-white tracking-wide truncate group-hover:text-primary transition-colors">
                  {title || parsed.title}
                </span>
                <span className="text-xs text-white/50 truncate flex items-center gap-1.5 mt-0.5 font-mono">
                  <span>{activeFile.name}</span>
                  {files.length > 1 && (
                    <span className="px-1.5 py-0.2 rounded-md bg-white/10 text-white/70 text-[10px]">
                      +{files.length - 1} arquivos
                    </span>
                  )}
                </span>
              </div>
            </div>

            {/* Three Dots Menu Button (INSIDE THE TOP RIGHT OF THE CARD) */}
            <div className="flex items-center gap-1 shrink-0 relative">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsOpenMenu(prev => !prev);
                }}
                className="p-2 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                title="Opções do Artefato"
              >
                <MoreVertical size={18} />
              </button>
            </div>
          </div>

          {/* Three Dots Action Dropdown */}
          <AnimatePresence>
            {isOpenMenu && (
              <motion.div
                ref={menuRef}
                initial={{ opacity: 0, scale: 0.95, y: -5 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -5 }}
                transition={{ duration: 0.15 }}
                className="absolute right-3 top-14 w-56 rounded-2xl bg-[#18181c] border border-white/15 shadow-2xl p-1.5 z-50 overflow-hidden backdrop-blur-2xl"
              >
                {hasHtml && (
                  <button
                    onClick={() => {
                      setIsPreviewOpen(true);
                      setIsOpenMenu(false);
                    }}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium text-white hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Eye size={15} className="text-emerald-400" />
                      <span>Ver Prévia</span>
                    </div>
                  </button>
                )}

                <button
                  onClick={() => {
                    setIsProjectExpanded(!isProjectExpanded);
                    setIsOpenMenu(false);
                  }}
                  className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium text-white hover:bg-white/10 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <Code2 size={15} className="text-blue-400" />
                    <span>{isProjectExpanded ? "Recolher Código" : "Ver Código do Projeto"}</span>
                  </div>
                </button>

                <button
                  onClick={() => {
                    handleCopy();
                    setIsOpenMenu(false);
                  }}
                  className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium text-white hover:bg-white/10 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <Copy size={15} className="text-amber-400" />
                    <span>Copiar Arquivo Atual</span>
                  </div>
                </button>

                {files.length > 1 ? (
                  <button
                    onClick={() => {
                      handleDownloadZip();
                      setIsOpenMenu(false);
                    }}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium text-white hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Archive size={15} className="text-purple-400" />
                      <span>Baixar Projeto (.ZIP)</span>
                    </div>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      generateAndDownloadFile({
                        filename: activeFile.name,
                        language: activeFile.language,
                        content: activeFile.content
                      });
                      setIsOpenMenu(false);
                    }}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium text-white hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Download size={15} className="text-cyan-400" />
                      <span>Baixar Arquivo</span>
                    </div>
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Project File Tree & Code Viewer (Expandable) */}
          {isProjectExpanded && (
            <div className="border-t border-white/10 bg-[#141417] p-3">
              {/* File Tabs for multi-file projects */}
              {files.length > 1 && (
                <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 border-b border-white/10 custom-scrollbar">
                  {files.map((file) => {
                    const isSelected = file.path === activeFile.path;
                    const fileDevicon = getDeviconUrl(file.language);
                    return (
                      <button
                        key={file.path}
                        onClick={() => setSelectedFilePath(file.path)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono transition-colors shrink-0 ${
                          isSelected 
                            ? 'bg-primary/20 text-primary border border-primary/30 font-bold' 
                            : 'bg-white/5 hover:bg-white/10 text-white/70'
                        }`}
                      >
                        {fileDevicon ? (
                          <img src={fileDevicon} alt="" className="w-3.5 h-3.5 object-contain" />
                        ) : (
                          <FileCode size={13} />
                        )}
                        <span>{file.name}</span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Code Snippet Box */}
              <div className="relative rounded-xl bg-[#09090b] border border-white/10 p-3 overflow-x-auto max-h-80 font-mono text-xs text-white/90">
                <pre className="whitespace-pre">{activeFile.content}</pre>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* HTML Preview Modal */}
      {isPreviewOpen && (
        <HtmlPreviewModal
          isOpen={isPreviewOpen}
          code={mainHtmlContent}
          chatId={chatId}
          onClose={() => setIsPreviewOpen(false)}
        />
      )}
    </>
  );
};
