import React from "react";
import { Brain, Sparkles, Network, Cpu, Zap } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ReasoningWebProps {
  content: string;
  isGenerating?: boolean;
}

export const ReasoningWeb: React.FC<ReasoningWebProps> = ({ content, isGenerating }) => {
  // Split reasoning into readable lines/paragraphs
  const lines = (content || "").split('\n').filter(line => line.trim().length > 0);
  const steps = lines.length > 0 ? lines : [content || "Processando raciocínio..."];

  return (
    <div className="relative pl-6 py-2 my-2 font-mono text-xs text-text-muted select-text">
      {/* Animated glowing neural energy beam along the left axis */}
      <div className="absolute left-2.5 top-0 bottom-0 w-0.5 bg-gradient-to-b from-emerald-500/80 via-teal-500/50 to-emerald-500/10 rounded-full overflow-hidden">
        {isGenerating && (
          <motion.div
            animate={{ y: ["0%", "100%", "0%"] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
            className="w-full h-12 bg-gradient-to-b from-transparent via-emerald-300 to-transparent shadow-[0_0_12px_rgba(52,211,153,1)]"
          />
        )}
      </div>
      
      <div className="flex items-center justify-between gap-2 text-emerald-400 mb-3 font-bold uppercase tracking-wider text-[10px]">
        <div className="flex items-center gap-2">
          <Network size={14} className={isGenerating ? "animate-pulse text-emerald-300" : "text-emerald-400"} />
          <span>Teia de Raciocínio Profundo</span>
        </div>
        {isGenerating && (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-[9px] text-emerald-300 animate-pulse">
            <Zap size={10} className="animate-bounce" />
            <span>Processando em tempo real</span>
          </div>
        )}
      </div>

      <div className="space-y-3">
        {steps.map((step, idx) => {
          const isLast = idx === steps.length - 1;
          return (
            <motion.div 
              key={`${idx}-${step.substring(0, 15)}`}
              initial={{ opacity: 0, x: -8, scale: 0.98 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              transition={{ duration: 0.25, delay: Math.min(idx * 0.03, 0.2) }}
              className="relative group"
            >
              {/* Glowing Node Dot */}
              <div className={`absolute -left-[1.4rem] top-2.5 w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                isLast && isGenerating 
                  ? "bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,1)] scale-125 animate-ping" 
                  : "bg-emerald-500/80 shadow-[0_0_6px_rgba(16,185,129,0.6)]"
              }`} />
              <div className={`absolute -left-[1.4rem] top-2.5 w-2.5 h-2.5 rounded-full ${
                isLast && isGenerating ? "bg-emerald-300" : "bg-emerald-500"
              }`} />

              <div className={`p-3 rounded-xl border transition-all duration-300 shadow-sm ${
                isLast && isGenerating
                  ? "bg-emerald-950/20 dark:bg-emerald-950/30 border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.15)] text-emerald-100"
                  : "bg-bg-surface/80 border-border-subtle hover:border-emerald-500/30 text-text-secondary"
              }`}>
                <p className="leading-relaxed whitespace-pre-wrap break-words">
                  {step}
                  {isLast && isGenerating && (
                    <motion.span
                      animate={{ opacity: [1, 0, 1] }}
                      transition={{ duration: 0.6, repeat: Infinity }}
                      className="inline-block w-2 h-4 ml-1 bg-emerald-400 rounded-xs align-middle shadow-[0_0_8px_rgba(52,211,153,0.9)]"
                    />
                  )}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {isGenerating && (
          <motion.div 
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            className="flex items-center gap-2 mt-3.5 text-emerald-400/80 font-mono text-[11px]"
          >
            <Sparkles size={13} className="animate-spin text-emerald-400" />
            <span className="animate-pulse font-medium">Sintetizando modelo neural e expandindo resposta...</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
