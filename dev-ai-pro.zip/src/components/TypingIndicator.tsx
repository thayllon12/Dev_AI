import React, { useEffect, useState } from 'react';
import { getSocket } from '../lib/socket';
import { motion, AnimatePresence } from 'motion/react';

export function TypingIndicator({ currentChatId, currentUserUid }: { currentChatId: string | null; currentUserUid: string }) {
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!currentChatId) return;

    const socket = getSocket();

    const handleTyping = (data: { uid: string; isTyping: boolean; name?: string }) => {
      if (data.uid === currentUserUid) return;

      setTypingUsers(prev => {
        const next = new Set(prev);
        if (data.isTyping) {
          next.add(data.uid);
        } else {
          next.delete(data.uid);
        }
        return next;
      });
    };

    socket.on('typing', handleTyping);

    return () => {
      socket.off('typing', handleTyping);
    };
  }, [currentChatId, currentUserUid]);

  if (typingUsers.size === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 10 }}
        className="absolute -top-8 left-4 bg-bg-surface border border-border-subtle rounded-full px-4 py-1.5 flex items-center gap-2 shadow-sm z-10"
      >
        <div className="flex gap-1">
          <span className="w-1.5 h-1.5 bg-primary/70 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <span className="w-1.5 h-1.5 bg-primary/70 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <span className="w-1.5 h-1.5 bg-primary/70 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
        <span className="text-xs text-text-muted">
          {typingUsers.size === 1 ? 'Alguém está digitando...' : 'Várias pessoas digitando...'}
        </span>
      </motion.div>
    </AnimatePresence>
  );
}
