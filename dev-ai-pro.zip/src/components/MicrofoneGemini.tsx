import React, { useState, useRef, useImperativeHandle, forwardRef } from 'react';
import { Mic, MicOff, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { getAI } from '../App';

export interface MicrofoneGeminiRef {
  stopAndTranscribeAndSend: () => void;
  stopAndSendAudioMessage: () => void;
  cancelRecording: () => void;
  startRecording: () => void;
  isRecording: boolean;
  isProcessing: boolean;
}

interface MicrofoneGeminiProps {
  onTranscricaoConcluida: (texto: string, autoSend?: boolean) => void;
  onAudioMessageCreated?: (audioUrl: string, duration: number, waveform: number[]) => void;
  onStateChange?: (state: { isRecording: boolean; duration: number; volume: number[]; isProcessing: boolean }) => void;
}

export const MicrofoneGemini = forwardRef<MicrofoneGeminiRef, MicrofoneGeminiProps>(
  function MicrofoneGemini({ onTranscricaoConcluida, onAudioMessageCreated, onStateChange }, ref) {
    const [isRecording, setIsRecording] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [duration, setDuration] = useState(0);

    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<BlobPart[]>([]);
    const animFrameRef = useRef<number | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const timerIntervalRef = useRef<any>(null);
    const volumeRef = useRef<number[]>([]);
    const autoSendRef = useRef(false);
    const sendAsPureAudioRef = useRef(false);
    const isCancelledRef = useRef(false);
    const streamRef = useRef<MediaStream | null>(null);

    useImperativeHandle(ref, () => ({
      stopAndTranscribeAndSend: () => {
        if (isRecording) {
          autoSendRef.current = true;
          sendAsPureAudioRef.current = false;
          stopRecording();
        }
      },
      stopAndSendAudioMessage: () => {
        if (isRecording) {
          sendAsPureAudioRef.current = true;
          autoSendRef.current = false;
          stopRecording();
        }
      },
      cancelRecording: () => {
        cancelRecording();
      },
      startRecording: () => {
        startRecording();
      },
      isRecording,
      isProcessing
    }));

    const cancelRecording = () => {
      isCancelledRef.current = true;
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (audioContextRef.current) audioContextRef.current.close().catch(() => {});
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        try { mediaRecorderRef.current.stop(); } catch (e) {}
      }
      setIsRecording(false);
      setIsProcessing(false);
      setDuration(0);
      if (onStateChange) {
        onStateChange({ isRecording: false, duration: 0, volume: [], isProcessing: false });
      }
      toast.info("Gravação cancelada");
    };

    // Iniciar Gravação e Analisador de Áudio (Barrinhas)
    const startRecording = async () => {
      audioChunksRef.current = [];
      volumeRef.current = [];
      autoSendRef.current = false;
      sendAsPureAudioRef.current = false;
      isCancelledRef.current = false;
      setDuration(0);

      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
          }
        }).catch(() => navigator.mediaDevices.getUserMedia({ audio: true }));

        streamRef.current = stream;

        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        if (audioCtx.state === 'suspended') {
          await audioCtx.resume();
        }
        const analyser = audioCtx.createAnalyser();
        audioCtx.createMediaStreamSource(stream).connect(analyser);
        analyser.fftSize = 128;
        analyser.smoothingTimeConstant = 0.5;

        audioContextRef.current = audioCtx;
        const dataArray = new Uint8Array(analyser.frequencyBinCount);

        let currentSecs = 0;
        const updateVolume = () => {
          analyser.getByteFrequencyData(dataArray);
          const bands: number[] = [];
          const totalBands = 16;
          for (let i = 0; i < totalBands; i++) {
            const binIndex = Math.floor(1 + (i * 1.5));
            const raw = dataArray[binIndex] || 0;
            const norm = raw / 255;
            const boosted = Math.min(255, Math.pow(norm, 0.5) * 300);
            bands.push(boosted);
          }
          volumeRef.current = bands;
          if (onStateChange) {
            onStateChange({ isRecording: true, duration: currentSecs, volume: bands, isProcessing: false });
          }
          animFrameRef.current = requestAnimationFrame(updateVolume);
        };
        updateVolume();

        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;
        mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) audioChunksRef.current.push(e.data);
        };
        mediaRecorder.onstop = async () => {
          if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
          stream.getTracks().forEach(t => t.stop());
          if (isCancelledRef.current) return;

          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          if (sendAsPureAudioRef.current && onAudioMessageCreated) {
            const audioUrl = URL.createObjectURL(audioBlob);
            const capturedWaveform = volumeRef.current.length > 0 ? volumeRef.current.slice(0, 25) : [40, 60, 80, 50, 70, 90, 65, 40, 55, 75];
            onAudioMessageCreated(audioUrl, currentSecs || 1, capturedWaveform);
            setIsRecording(false);
            if (onStateChange) onStateChange({ isRecording: false, duration: 0, volume: [], isProcessing: false });
          } else {
            await processarAudio(audioBlob);
          }
        };

        mediaRecorder.start(200);
        setIsRecording(true);

        const startTime = Date.now();
        timerIntervalRef.current = setInterval(() => {
          currentSecs = Math.floor((Date.now() - startTime) / 1000);
          setDuration(currentSecs);
        }, 1000);

        if (onStateChange) onStateChange({ isRecording: true, duration: 0, volume: [], isProcessing: false });
      } catch (err: any) {
        console.error("Erro ao acessar microfone:", err);
        toast.error("Erro ao acessar o microfone. Verifique as permissões do navegador.");
        if (onStateChange) onStateChange({ isRecording: false, duration: 0, volume: [], isProcessing: false });
      }
    };

    const stopRecording = () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (audioContextRef.current) audioContextRef.current.close().catch(() => {});
      if (mediaRecorderRef.current && isRecording) {
        try { mediaRecorderRef.current.stop(); } catch (e) {}
      }
      setIsRecording(false);
      if (onStateChange) onStateChange({ isRecording: false, duration: duration, volume: [], isProcessing: true });
    };

    // Enviar para o servidor transcrever e corrigir
    const processarAudio = async (blob: Blob) => {
      setIsProcessing(true);
      if (onStateChange) onStateChange({ isRecording: false, duration: 0, volume: [], isProcessing: true });
      const shouldAutoSend = autoSendRef.current;
      autoSendRef.current = false;

      try {
        const reader = new FileReader();
        const base64Promise = new Promise<string>((resolve) => {
          reader.onloadend = () => {
            const base64String = (reader.result as string).split(',')[1];
            resolve(base64String);
          };
        });
        reader.readAsDataURL(blob);
        const base64 = await base64Promise;

        let text = "";

        try {
          const res = await fetch('/api/transcribe-audio', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioData: base64,
              mimeType: blob.type || 'audio/webm'
            })
          });

          if (res.ok) {
            const data = await res.json();
            if (data.text) {
              text = data.text;
            }
          }
        } catch (serverErr) {
          console.warn("Rota do servidor de transcrição indisponível, usando fallback no cliente:", serverErr);
        }

        if (!text) {
          try {
            const ai = getAI();
            const response = await ai.models.generateContent({
              model: "gemini-2.5-flash",
              contents: [
                {
                  inlineData: {
                    mimeType: blob.type || "audio/webm",
                    data: base64,
                  },
                },
                { text: "Transcreva este áudio de forma literal e completa." },
              ],
            });
            text = response.text?.trim() || "";
          } catch (clientErr) {
            console.warn("Transcrição no cliente falhou:", clientErr);
          }
        }

        text = cleanTranscriptionText(text);

        if (text && onTranscricaoConcluida) {
          onTranscricaoConcluida(text, shouldAutoSend);
        }
      } catch (err: any) {
        console.error("Erro na transcrição:", err);
        toast.error("Falha na transcrição: " + (err?.message || "Não foi possível processar o áudio."));
      } finally {
        setIsProcessing(false);
        if (onStateChange) onStateChange({ isRecording: false, duration: 0, volume: [], isProcessing: false });
      }
    };

    return (
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={isRecording ? stopRecording : startRecording}
          disabled={isProcessing}
          className={cn(
            "w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer",
            isRecording 
              ? "bg-red-500/15 text-red-500 border border-red-500/30 shadow-md animate-pulse" 
              : "text-text-muted hover:text-text-primary hover:bg-bg-surface-hover"
          )}
          title={isRecording ? "Parar gravação" : "Gravar áudio com microfone"}
        >
          {isProcessing ? (
            <Loader2 className="w-5 h-5 animate-spin text-primary" />
          ) : isRecording ? (
            <MicOff className="w-5 h-5" />
          ) : (
            <Mic className="w-5 h-5" />
          )}
        </button>
      </div>
    );
  }
);

// Helper to clean audio transcription
function cleanTranscriptionText(str: string): string {
  if (!str) return "";
  let text = str.trim();
  text = text.replace(/^["'“«»`]+|["'”«»`]+$/g, '').trim();
  
  const prefixes = [
    /^(com certeza,?\s*)?(aqui está|esta é|segue|transcrição( do áudio)?)\s*[:\-\n]\s*/i,
    /^(transcrição|transcricao)\s*[:\-\n]\s*/i,
    /^(texto transcrito|resultado|audio transcrito)\s*[:\-\n]\s*/i,
    /^(aqui está a transcrição de forma literal e completa\s*[:\-\n]?\s*)/i,
    /^(com certeza!|com certeza,)\s*/i
  ];
  for (const p of prefixes) {
    text = text.replace(p, '').trim();
  }
  return text.replace(/^["'“«»`]+|["'”«»`]+$/g, '').trim();
}

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
