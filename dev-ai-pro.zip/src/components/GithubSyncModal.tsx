import React, { useState, useEffect } from 'react';
import { X, Github, Download, Upload, CheckCircle2, Loader2, GitBranch, Key, FileCode, MessageSquare, CheckSquare, Square, Search, FolderGit2, User, Plus, ExternalLink, Check, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { auth } from '../firebase';
import { GithubAuthProvider, signInWithPopup, getAdditionalUserInfo } from 'firebase/auth';

interface CodeBlockItem {
  id: number;
  lang: string;
  code: string;
  selected: boolean;
  filename?: string;
}

interface GithubRepo {
  id: number;
  full_name: string;
  name: string;
  description: string | null;
  private: boolean;
  html_url: string;
  default_branch?: string;
}

interface GithubSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'import' | 'export';
  exportMessage?: { id: string; content: string } | null;
  onSelectInChat?: () => void;
  onImportToChat?: (content: string, repoName: string) => void;
}

export function GithubSyncModal({ 
  isOpen, 
  onClose, 
  mode, 
  exportMessage, 
  onSelectInChat,
  onImportToChat 
}: GithubSyncModalProps) {
  const [repo, setRepo] = useState('');
  const [token, setToken] = useState(() => localStorage.getItem('github_token') || '');
  const [username, setUsername] = useState(() => localStorage.getItem('github_username') || '');

  const handleGitHubLogin = async () => {
    const provider = new GithubAuthProvider();
    provider.addScope('repo'); // Request repo scope for read/write access to repos
    try {
      const result = await signInWithPopup(auth, provider);
      const credential = GithubAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setToken(credential.accessToken);
        localStorage.setItem('github_token', credential.accessToken);
        const userInfo = getAdditionalUserInfo(result);
        const username = userInfo?.username || (result.user as any).reloadUserInfo?.screenName || '';
        if (username) {
          setUsername(username);
          localStorage.setItem('github_username', username);
        }
        toast.success("Login com GitHub realizado com sucesso!");
        // We will call fetchUserRepos here via useEffect or directly.
      }
    } catch (error: any) {
      console.error("GitHub Login Error:", error);
      toast.error("Erro ao fazer login com GitHub", { description: error.message });
    }
  };
  const [filePath, setFilePath] = useState('src/App.tsx');
  const [commitMessage, setCommitMessage] = useState('Exportado via Dev AI');
  const [status, setStatus] = useState<'idle' | 'syncing' | 'success' | 'error'>('idle');
  const [exportType, setExportType] = useState<'all' | 'code_only'>('code_only');
  const [codeBlocks, setCodeBlocks] = useState<CodeBlockItem[]>([]);
  
  // New Repo Creation State
  const [showCreateRepo, setShowCreateRepo] = useState(false);
  const [newRepoName, setNewRepoName] = useState('');
  const [newRepoDesc, setNewRepoDesc] = useState('');
  const [newRepoIsPrivate, setNewRepoIsPrivate] = useState(false);
  const [isCreatingRepo, setIsCreatingRepo] = useState(false);

  // Interactive Repo Search State
  const [userRepos, setUserRepos] = useState<GithubRepo[]>([]);
  const [isLoadingRepos, setIsLoadingRepos] = useState(false);
  const [repoSearchQuery, setRepoSearchQuery] = useState('');
  const [lastExportedUrl, setLastExportedUrl] = useState<string | null>(null);

  // Auto-save username and token to localStorage
  useEffect(() => {
    if (token) localStorage.setItem('github_token', token);
    if (username) localStorage.setItem('github_username', username);
  }, [token, username]);

  useEffect(() => {
    if (mode === 'export' && exportMessage?.content) {
      const regex = /```(\w*)\n([\s\S]*?)```/g;
      const blocks: CodeBlockItem[] = [];
      let match;
      let count = 0;
      while ((match = regex.exec(exportMessage.content)) !== null) {
        count++;
        const lang = match[1] || 'text';
        let ext = 'txt';
        if (lang === 'tsx' || lang === 'ts') ext = 'tsx';
        else if (lang === 'jsx' || lang === 'js') ext = 'jsx';
        else if (lang === 'html') ext = 'html';
        else if (lang === 'css') ext = 'css';
        else if (lang === 'json') ext = 'json';

        blocks.push({
          id: count,
          lang,
          code: match[2].trim(),
          selected: true,
          filename: count === 1 ? `src/App.${ext}` : `src/components/Block_${count}.${ext}`
        });
      }
      setCodeBlocks(blocks);
      if (blocks.length > 0 && blocks[0].filename) {
        setFilePath(blocks[0].filename);
      }
    }
  }, [mode, exportMessage]);

  const toggleBlock = (id: number) => {
    setCodeBlocks(prev => prev.map(b => b.id === id ? { ...b, selected: !b.selected } : b));
  };

  useEffect(() => {
    if (isOpen && token && userRepos.length === 0) {
      fetchUserRepos();
    }
  }, [isOpen, token]);

  const fetchUserRepos = async () => {
    if (!username && !token) {
      toast.error("Digite o seu nome de usuário do GitHub ou Token para buscar seus repositórios.");
      return;
    }

    setIsLoadingRepos(true);
    try {
      const url = token 
        ? 'https://api.github.com/user/repos?sort=updated&per_page=50' 
        : `https://api.github.com/users/${encodeURIComponent(username)}/repos?sort=updated&per_page=50`;
      
      const headers: Record<string, string> = {
        'Accept': 'application/vnd.github.v3+json'
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token.trim()}`;
      }

      const res = await fetch(url, { headers });
      if (!res.ok) {
        throw new Error(`Erro ao buscar repositórios (${res.status})`);
      }
      const data = await res.json();
      if (Array.isArray(data)) {
        setUserRepos(data.map((r: any) => ({
          id: r.id,
          full_name: r.full_name,
          name: r.name,
          description: r.description,
          private: r.private,
          html_url: r.html_url,
          default_branch: r.default_branch || 'main'
        })));
        toast.success(`${data.length} repositórios carregados!`);
      } else {
        toast.error("Nenhum repositório encontrado.");
      }
    } catch (err: any) {
      console.error("Error fetching github repos:", err);
      toast.error(err.message || "Falha ao conectar com o GitHub.");
    } finally {
      setIsLoadingRepos(false);
    }
  };

  const handleCreateRepo = async () => {
    if (!token) {
      toast.error("É necessário um Token Pessoal para criar novos repositórios.");
      return;
    }
    if (!newRepoName.trim()) {
      toast.error("Digite o nome para o novo repositório.");
      return;
    }

    setIsCreatingRepo(true);
    try {
      const res = await fetch('https://api.github.com/user/repos', {
        method: 'POST',
        headers: {
          'Accept': 'application/vnd.github.v3+json',
          'Authorization': `Bearer ${token.trim()}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: newRepoName.trim(),
          description: newRepoDesc.trim() || 'Criado via Dev AI',
          private: newRepoIsPrivate,
          auto_init: true
        })
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.message || `Erro ${res.status} ao criar repositório`);
      }

      const created = await res.json();
      const fullName = created.full_name;
      setRepo(fullName);
      setShowCreateRepo(false);
      setNewRepoName('');
      setNewRepoDesc('');
      toast.success(`Repositório ${fullName} criado com sucesso no GitHub!`);

      // Refresh list
      fetchUserRepos();
    } catch (err: any) {
      toast.error(err.message || "Erro ao criar repositório.");
    } finally {
      setIsCreatingRepo(false);
    }
  };

  const filteredRepos = userRepos.filter(r => 
    r.full_name.toLowerCase().includes(repoSearchQuery.toLowerCase()) ||
    (r.description && r.description.toLowerCase().includes(repoSearchQuery.toLowerCase()))
  );

  const handleSync = async () => {
    if (!repo) {
      toast.error("Selecione ou digite o repositório no formato usuario/repositorio");
      return;
    }

    if (mode === 'export') {
      if (!token) {
        toast.error("Token Pessoal do GitHub é necessário para exportar.");
        return;
      }

      setStatus('syncing');
      try {
        let contentToCommit = "";
        if (exportType === 'all') {
          contentToCommit = exportMessage?.content || "";
        } else {
          const selectedBlocks = codeBlocks.filter(b => b.selected);
          if (selectedBlocks.length === 0) {
            toast.error("Selecione ao menos um bloco de código para exportar.");
            setStatus('idle');
            return;
          }
          contentToCommit = selectedBlocks.map(b => b.code).join("\n\n// --- Split ---\n\n");
        }

        const cleanRepo = repo.trim();
        const cleanPath = filePath.trim() || 'export.txt';
        const apiUrl = `https://api.github.com/repos/${cleanRepo}/contents/${cleanPath}`;

        // Check if file already exists to obtain SHA
        let existingSha: string | undefined = undefined;
        try {
          const checkRes = await fetch(apiUrl, {
            headers: {
              'Accept': 'application/vnd.github.v3+json',
              'Authorization': `Bearer ${token.trim()}`
            }
          });
          if (checkRes.ok) {
            const fileInfo = await checkRes.json();
            existingSha = fileInfo.sha;
          }
        } catch (e) {
          // File does not exist yet
        }

        // UTF-8 Base64 encoding
        const base64Content = btoa(unescape(encodeURIComponent(contentToCommit)));

        const putRes = await fetch(apiUrl, {
          method: 'PUT',
          headers: {
            'Accept': 'application/vnd.github.v3+json',
            'Authorization': `Bearer ${token.trim()}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            message: commitMessage || 'Commit via Dev AI',
            content: base64Content,
            ...(existingSha ? { sha: existingSha } : {})
          })
        });

        if (!putRes.ok) {
          const errorJson = await putRes.json().catch(() => ({}));
          throw new Error(errorJson.message || `Erro HTTP ${putRes.status} ao enviar ao GitHub`);
        }

        const resData = await putRes.json();
        const htmlUrl = resData.content?.html_url || `https://github.com/${cleanRepo}`;
        setLastExportedUrl(htmlUrl);

        setStatus('success');
        toast.success("Código enviado com sucesso para o GitHub!");
      } catch (err: any) {
        console.error("Export error:", err);
        setStatus('error');
        toast.error(err.message || "Falha ao exportar para o GitHub.");
      }
    } else {
      // Import mode
      setStatus('syncing');
      try {
        const cleanRepo = repo.trim();
        const cleanPath = filePath.trim();
        const apiUrl = `https://api.github.com/repos/${cleanRepo}/contents/${cleanPath}`;

        const headers: Record<string, string> = {
          'Accept': 'application/vnd.github.v3+json'
        };
        if (token) headers['Authorization'] = `Bearer ${token.trim()}`;

        const res = await fetch(apiUrl, { headers });
        if (!res.ok) {
          throw new Error(`Não foi possível ler o arquivo/diretório (${res.status})`);
        }

        const data = await res.json();
        let importedText = "";

        if (Array.isArray(data)) {
          importedText = `📁 **Repositório ${cleanRepo} (${cleanPath || 'raiz'}):**\n` +
            data.map((f: any) => `- [${f.type === 'dir' ? '📁' : '📄'} ${f.name}](${f.html_url})`).join("\n");
        } else if (data.content) {
          const decoded = decodeURIComponent(escape(atob(data.content.replace(/\n/g, ''))));
          importedText = `📄 **Arquivo do GitHub (${cleanRepo}/${cleanPath}):**\n\`\`\`${cleanPath.split('.').pop() || 'text'}\n${decoded}\n\`\`\``;
        }

        if (onImportToChat && importedText) {
          onImportToChat(importedText, cleanRepo);
        }

        setStatus('success');
        toast.success("Conteúdo do GitHub importado no chat!");
        setTimeout(() => {
          setStatus('idle');
          onClose();
        }, 1200);
      } catch (err: any) {
        setStatus('error');
        toast.error(err.message || "Falha ao importar do GitHub.");
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1000000] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-bg-modal text-text-primary border border-border-strong w-full max-w-xl rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto custom-scrollbar flex flex-col gap-4"
      >
        <button 
          onClick={onClose} 
          className="absolute top-5 right-5 text-text-muted hover:text-text-primary p-1.5 hover:bg-bg-surface-hover rounded-xl transition-colors"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-primary/10 rounded-2xl border border-primary/20 text-primary shrink-0">
            <Github size={26} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-text-primary">
              {mode === 'import' ? 'Importar do GitHub' : 'Exportar para o GitHub'}
            </h2>
            <p className="text-xs text-text-muted">
              {mode === 'import' 
                ? 'Conecte sua conta e escolha um repositório para importar no chat.' 
                : 'Envie seus códigos diretamente para repositórios do seu GitHub.'}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Connection Section */}
          <div className="bg-bg-surface p-4 rounded-2xl border border-border-subtle space-y-3">
            <span className="text-xs font-bold text-text-primary flex items-center gap-1.5">
              <FolderGit2 size={16} className="text-primary" /> Conta do GitHub
            </span>
            
            {!token ? (
               <div className="flex justify-center p-2">
                 <button 
                   onClick={handleGitHubLogin}
                   className="flex items-center gap-2 py-2 px-4 bg-primary text-white rounded-xl hover:bg-primary-hover transition-colors font-medium text-sm shadow-md"
                 >
                   <Github size={18} />
                   Conectar com GitHub
                 </button>
               </div>
            ) : (
              <div className="flex items-center justify-between bg-bg-main p-3 rounded-xl border border-border-strong">
                 <div className="flex items-center gap-2 text-sm text-text-primary">
                    <User size={16} className="text-primary" />
                    <span className="font-medium">{username || "Conectado"}</span>
                 </div>
                 <button
                    onClick={() => {
                       setToken("");
                       setUsername("");
                       localStorage.removeItem("github_token");
                       localStorage.removeItem("github_username");
                       setUserRepos([]);
                    }}
                    className="text-xs text-red-400 hover:text-red-300 transition-colors"
                 >
                    Desconectar
                 </button>
              </div>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={fetchUserRepos}
                disabled={isLoadingRepos || !token}
                className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-bg-main hover:bg-bg-surface-hover text-text-primary text-xs font-bold rounded-xl border border-border-strong transition-all shadow-sm disabled:opacity-50"
              >
                {isLoadingRepos ? <Loader2 size={14} className="animate-spin text-primary" /> : <Search size={14} className="text-primary" />}
                <span>{isLoadingRepos ? 'Carregando...' : 'Buscar Meus Repositórios'}</span>
              </button>

              <button
                type="button"
                onClick={() => setShowCreateRepo(!showCreateRepo)}
                disabled={!token}
                className="flex items-center gap-1.5 py-2 px-3 bg-primary/10 hover:bg-primary/20 text-primary text-xs font-bold rounded-xl border border-primary/30 transition-all shrink-0 disabled:opacity-50"
              >
                <Plus size={14} />
                <span>Novo Repo</span>
              </button>
            </div>
          </div>

          {/* New Repo Creation Box */}
          <AnimatePresence>
            {showCreateRepo && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-4 bg-primary/5 border border-primary/20 rounded-2xl space-y-3 overflow-hidden"
              >
                <span className="text-xs font-bold text-primary flex items-center gap-1.5">
                  <GitBranch size={15} /> Criar Novo Repositório no GitHub
                </span>
                
                <input 
                  type="text" 
                  value={newRepoName}
                  onChange={(e) => setNewRepoName(e.target.value)}
                  placeholder="Nome do repositório (ex: meu-projeto-ia)"
                  className="w-full bg-bg-main border border-border-strong rounded-xl px-3 py-1.5 text-xs text-text-primary focus:border-primary outline-none"
                />

                <input 
                  type="text" 
                  value={newRepoDesc}
                  onChange={(e) => setNewRepoDesc(e.target.value)}
                  placeholder="Descrição opcional..."
                  className="w-full bg-bg-main border border-border-strong rounded-xl px-3 py-1.5 text-xs text-text-primary focus:border-primary outline-none"
                />

                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-xs font-medium text-text-muted cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={newRepoIsPrivate}
                      onChange={(e) => setNewRepoIsPrivate(e.target.checked)}
                      className="rounded accent-primary"
                    />
                    <span>Repositório Privado</span>
                  </label>

                  <button
                    type="button"
                    onClick={handleCreateRepo}
                    disabled={isCreatingRepo}
                    className="px-4 py-1.5 bg-primary hover:bg-primary-hover text-white text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-1.5"
                  >
                    {isCreatingRepo ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
                    <span>Criar no GitHub</span>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Repository List Dropdown */}
          {userRepos.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-text-primary">
                  Seus Repositórios ({userRepos.length}):
                </span>
                <input 
                  type="text" 
                  value={repoSearchQuery}
                  onChange={(e) => setRepoSearchQuery(e.target.value)}
                  placeholder="Filtrar..."
                  className="bg-bg-main border border-border-subtle rounded-lg px-2 py-1 text-[11px] text-text-primary outline-none focus:border-primary w-36"
                />
              </div>

              <div className="max-h-36 overflow-y-auto custom-scrollbar space-y-1.5 pr-1">
                {filteredRepos.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      setRepo(r.full_name);
                      toast.info(`Selecionado: ${r.full_name}`);
                    }}
                    className={`w-full flex items-center justify-between p-2 rounded-xl border text-xs text-left transition-all ${
                      repo === r.full_name 
                        ? 'bg-primary/15 border-primary text-primary font-bold shadow-sm'
                        : 'bg-bg-surface hover:bg-bg-surface-hover border-border-subtle text-text-primary'
                    }`}
                  >
                    <div className="min-w-0 flex-1 pr-2">
                      <div className="flex items-center gap-1.5">
                        <FolderGit2 size={14} className={repo === r.full_name ? "text-primary" : "text-text-muted"} />
                        <span className="truncate">{r.full_name}</span>
                        {r.private && (
                          <span className="px-1.5 py-0.5 text-[9px] bg-amber-500/10 text-amber-500 rounded font-semibold shrink-0">Privado</span>
                        )}
                      </div>
                    </div>
                    {repo === r.full_name && <CheckCircle2 size={16} className="text-primary shrink-0" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Selected Repo & File Path */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-semibold text-text-secondary block mb-1">
                Repositório Alvo
              </label>
              <input 
                type="text" 
                value={repo}
                onChange={(e) => setRepo(e.target.value)}
                placeholder="usuario/repositorio"
                className="w-full bg-bg-surface border border-border-strong rounded-xl px-3 py-2 text-text-primary focus:border-primary outline-none transition-all text-xs font-mono"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-text-secondary block mb-1">
                Caminho do Arquivo
              </label>
              <input 
                type="text" 
                value={filePath}
                onChange={(e) => setFilePath(e.target.value)}
                placeholder="ex: src/App.tsx"
                className="w-full bg-bg-surface border border-border-strong rounded-xl px-3 py-2 text-text-primary focus:border-primary outline-none transition-all text-xs font-mono"
              />
            </div>
          </div>

          {mode === 'export' && (
            <div className="pt-2 border-t border-border-subtle space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-text-primary">
                  Conteúdo a Exportar
                </label>
                {onSelectInChat && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onSelectInChat();
                    }}
                    className="text-[11px] font-semibold text-primary hover:underline flex items-center gap-1"
                  >
                    <CheckSquare size={13} /> Selecionar mensagens no chat
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setExportType('code_only')}
                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold text-left transition-all ${
                    exportType === 'code_only'
                      ? 'bg-primary/10 border-primary text-primary'
                      : 'bg-bg-surface border-border-strong text-text-muted hover:text-text-primary'
                  }`}
                >
                  <FileCode size={15} />
                  <span>Apenas Códigos</span>
                </button>

                <button
                  type="button"
                  onClick={() => setExportType('all')}
                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold text-left transition-all ${
                    exportType === 'all'
                      ? 'bg-primary/10 border-primary text-primary'
                      : 'bg-bg-surface border-border-strong text-text-muted hover:text-text-primary'
                  }`}
                >
                  <MessageSquare size={15} />
                  <span>Tudo (Texto + Código)</span>
                </button>
              </div>

              {exportType === 'code_only' && codeBlocks.length > 0 && (
                <div className="space-y-2 mt-2">
                  <span className="text-[11px] font-semibold text-text-muted block">
                    Blocos de código detectados nesta resposta:
                  </span>
                  <div className="space-y-2 max-h-32 overflow-y-auto custom-scrollbar p-1">
                    {codeBlocks.map((block) => (
                      <div
                        key={block.id}
                        onClick={() => toggleBlock(block.id)}
                        className={`flex items-start gap-2.5 p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                          block.selected
                            ? 'bg-bg-surface-hover border-primary/50 text-text-primary'
                            : 'bg-bg-surface border-border-subtle text-text-muted opacity-60'
                        }`}
                      >
                        {block.selected ? (
                          <CheckSquare size={15} className="text-primary shrink-0 mt-0.5" />
                        ) : (
                          <Square size={15} className="text-text-muted shrink-0 mt-0.5" />
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between font-mono text-[10px] mb-0.5">
                            <span className="font-bold text-primary uppercase">{block.lang}</span>
                            <span className="text-[9px] text-text-muted">Bloco #{block.id}</span>
                          </div>
                          <p className="font-mono text-[10px] truncate text-text-muted">
                            {block.code.slice(0, 50)}...
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {lastExportedUrl && status === 'success' && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-between text-xs text-emerald-400">
              <span className="font-semibold flex items-center gap-1.5">
                <CheckCircle2 size={16} /> Arquivo salvo no GitHub!
              </span>
              <a 
                href={lastExportedUrl} 
                target="_blank" 
                rel="noreferrer" 
                className="inline-flex items-center gap-1 underline font-bold hover:text-white"
              >
                Ver no GitHub <ExternalLink size={12} />
              </a>
            </div>
          )}

          <button
            onClick={handleSync}
            disabled={!repo || status === 'syncing'}
            className="w-full mt-2 flex items-center justify-center gap-2 bg-primary hover:bg-primary-hover disabled:bg-primary/50 text-white font-bold py-3.5 rounded-2xl transition-all shadow-lg active:scale-95 cursor-pointer"
          >
            {status === 'idle' && (mode === 'import' ? <><Download size={18} /> Iniciar Importação</> : <><Upload size={18} /> Exportar para GitHub</>)}
            {status === 'syncing' && <><Loader2 size={18} className="animate-spin" /> {mode === 'import' ? 'Importando...' : 'Enviando ao GitHub...'}</>}
            {status === 'success' && <><CheckCircle2 size={18} /> {mode === 'import' ? 'Importado com sucesso!' : 'Exportado com sucesso!'}</>}
            {status === 'error' && <><X size={18} /> Tentar Novamente</>}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
