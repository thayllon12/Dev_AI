import React, { useState, useMemo } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "motion/react";
import { X, Download, Copy, Pencil, MessageSquarePlus, Crop, Trash2, MoreVertical, FileArchive, FileText, File, Code2, ListOrdered, Play } from "lucide-react";
import { CodeBlock } from "./CodeBlock";
import { HtmlPreviewModal } from "./HtmlPreviewModal";
import { copyToClipboard } from "../lib/utils";
import { getDeviconUrl } from "../utils/devicons";
import { toast } from "sonner";

interface FilePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  dataUrl: string;
  mimeType: string;
  fileName?: string;
  onEdit?: () => void;
  onRemover?: () => void;
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({
  isOpen,
  onClose,
  dataUrl,
  mimeType,
  fileName = "arquivo.txt",
  onEdit,
  onRemover,
}) => {
  const [showHtmlPreview, setShowHtmlPreview] = useState(false);

  const isImage = mimeType.startsWith("image/");
  const isAudio = mimeType.startsWith("audio/");
  const isVideo = mimeType.startsWith("video/");
  const isPdf = mimeType === "application/pdf";
  
  const isZip = mimeType.includes("zip") || mimeType.includes("archive") || fileName.endsWith(".zip") || fileName.endsWith(".rar") || fileName.endsWith(".tar") || fileName.endsWith(".gz");
  const isBinary = isZip || mimeType.includes("octet-stream") || mimeType.includes("word") || mimeType.includes("excel") || mimeType.includes("powerpoint") || (!mimeType.startsWith("text/") && !mimeType.startsWith("image/") && !mimeType.startsWith("audio/") && !mimeType.startsWith("video/") && !mimeType.includes("javascript") && !mimeType.includes("json") && !mimeType.includes("html") && !mimeType.includes("css") && !mimeType.includes("typescript"));

  // Extract text from base64 dataUrl if it's a text file
  const getTextContent = () => {
    if (isImage || isAudio || isVideo || isPdf || isBinary) return "";
    try {
      const base64 = dataUrl.split(",")[1];
      return decodeURIComponent(escape(atob(base64)));
    } catch (e) {
      console.error("Error decoding text attachment:", e);
      return "Erro ao decodificar o arquivo.";
    }
  };

  const textContent = useMemo(() => getTextContent(), [dataUrl, isImage, isAudio, isVideo, isPdf, isBinary]);
  const isTextFile = !isImage && !isAudio && !isVideo && !isPdf && !isBinary;
  const lineCount = useMemo(() => isTextFile && textContent ? textContent.split("\n").length : 0, [isTextFile, textContent]);

  const detectedLang = useMemo(() => {
    const ext = fileName ? (fileName.split('.').pop()?.toLowerCase() || "") : "";
    if (ext === "html" || ext === "htm") return { id: "html", name: "HTML" };
    if (ext === "js" || ext === "jsx") return { id: "javascript", name: "JavaScript" };
    if (ext === "ts" || ext === "tsx") return { id: "typescript", name: "TypeScript" };
    if (ext === "css" || ext === "scss") return { id: "css", name: "CSS" };
    if (ext === "json") return { id: "json", name: "JSON" };
    if (ext === "py") return { id: "python", name: "Python" };
    if (ext === "md") return { id: "markdown", name: "Markdown" };
    if (ext === "svg") return { id: "svg", name: "SVG" };

    const trimmed = textContent.trim();
    if (trimmed.startsWith("<!DOCTYPE html>") || trimmed.startsWith("<html") || /<head>|<body|<script|<style/i.test(trimmed)) {
      return { id: "html", name: "HTML" };
    }
    if (trimmed.startsWith("<?xml") || trimmed.startsWith("<svg")) {
      return { id: "svg", name: "SVG" };
    }
    if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
      try {
        JSON.parse(trimmed);
        return { id: "json", name: "JSON" };
      } catch {}
    }
    if (/^(import|export|const|let|var|function|class)\s/.test(trimmed)) {
      return { id: "javascript", name: "JavaScript" };
    }

    return { id: ext || "text", name: (ext || "TEXT").toUpperCase() };
  }, [fileName, textContent]);

  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = dataUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("Download iniciado!");
  };

  const handleCopy = async () => {
    if (isImage) {
      try {
        const response = await fetch(dataUrl);
        const blob = await response.blob();
        await navigator.clipboard.write([
          new ClipboardItem({
            [blob.type]: blob
          })
        ]);
        toast.success("Imagem copiada!");
      } catch (err) {
        console.error("Failed to copy image: ", err);
        toast.error("Erro ao copiar imagem. Tente fazer o download.");
      }
      return;
    }
    await copyToClipboard(textContent);
    toast.success("Conteúdo copiado!");
  };

  // Render a specialized premium binary/zip file download interface
  const renderBinaryDownloadView = () => {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center text-text-primary bg-bg-main">
        <div className="p-8 rounded-full bg-bg-surface border border-border-subtle mb-6 animate-pulse">
          {isZip ? (
            <FileArchive size={64} className="text-primary" />
          ) : fileName.endsWith(".pdf") ? (
            <FileText size={64} className="text-red-400" />
          ) : (
            <File size={64} className="text-blue-400" />
          )}
        </div>
        <h3 className="text-xl font-bold mb-2 break-all max-w-md">{fileName}</h3>
        <p className="text-sm text-text-muted mb-6">{mimeType}</p>
        <button
          onClick={handleDownload}
          className="px-8 py-3 bg-primary hover:bg-primary-hover text-white font-bold rounded-xl shadow-lg hover:shadow-primary/25 transition-all flex items-center gap-2"
        >
          <Download size={18} />
          <span>Baixar Arquivo</span>
        </button>
      </div>
    );
  };

  if (!isOpen) return null;

  return createPortal(
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[999999] flex flex-col items-center justify-center bg-black/85 backdrop-blur-md p-2 sm:p-6 overflow-y-auto w-screen h-screen"
          >
            {isImage ? (
              /* Premium High-Fidelity Custom Image Viewer Layout */
              <div className="w-full max-w-5xl h-full max-h-[90vh] flex flex-col justify-between bg-bg-modal backdrop-blur-2xl text-text-primary rounded-3xl border border-border-strong relative shadow-2xl overflow-hidden">
                
                {/* Top Action Bar */}
                <div className="p-4 flex items-center justify-between border-b border-border-subtle bg-bg-surface-hover/50 z-50">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={onClose}
                      className="w-10 h-10 bg-bg-surface hover:bg-bg-surface-hover text-text-primary rounded-xl flex items-center justify-center transition-all active:scale-95 border border-border-subtle shadow-md"
                      title="Fechar"
                    >
                      <X size={20} />
                    </button>

                    <button
                      onClick={handleDownload}
                      className="w-10 h-10 bg-bg-surface hover:bg-bg-surface-hover text-text-primary rounded-xl flex items-center justify-center transition-all active:scale-95 border border-border-subtle shadow-md"
                      title="Download"
                    >
                      <Download size={20} />
                    </button>
                  </div>

                  <span className="text-xs font-bold text-text-muted truncate max-w-[200px]">{fileName}</span>
                </div>

                {/* Viewport Center */}
                <div className="flex-1 w-full flex items-center justify-center p-4 overflow-y-auto custom-scrollbar">
                  <img
                    src={dataUrl}
                    alt={fileName}
                    className="max-w-full max-h-[65vh] object-contain rounded-2xl shadow-2xl border border-border-subtle"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Bottom Action Bar */}
                <div className="w-full bg-bg-surface-hover/80 border-t border-border-subtle py-4 px-6 flex justify-around items-center shrink-0 z-10">
                  <button
                    onClick={() => {
                      if (onEdit) onEdit();
                    }}
                    className="flex flex-col items-center gap-1 group cursor-pointer"
                  >
                    <div className="w-10 h-10 rounded-xl bg-bg-surface group-hover:bg-primary/10 text-text-primary group-hover:text-primary flex items-center justify-center transition-all active:scale-95 border border-border-subtle shadow-sm">
                      <Pencil size={18} />
                    </div>
                    <span className="text-[11px] font-medium text-text-muted group-hover:text-text-primary tracking-wide">
                      Editar
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      if (onEdit) onEdit();
                    }}
                    className="flex flex-col items-center gap-1 group cursor-pointer"
                  >
                    <div className="w-10 h-10 rounded-xl bg-bg-surface group-hover:bg-primary/10 text-text-primary group-hover:text-primary flex items-center justify-center transition-all active:scale-95 border border-border-subtle shadow-sm">
                      <MessageSquarePlus size={18} />
                    </div>
                    <span className="text-[11px] font-medium text-text-muted group-hover:text-text-primary tracking-wide">
                      Comentar
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      if (onEdit) onEdit();
                    }}
                    className="flex flex-col items-center gap-1 group cursor-pointer"
                  >
                    <div className="w-10 h-10 rounded-xl bg-bg-surface group-hover:bg-primary/10 text-text-primary group-hover:text-primary flex items-center justify-center transition-all active:scale-95 border border-border-subtle shadow-sm">
                      <Crop size={18} />
                    </div>
                    <span className="text-[11px] font-medium text-text-muted group-hover:text-text-primary tracking-wide">
                      Redimensionar
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      if (onRemover) {
                        onRemover();
                      } else {
                        toast.info("Esta imagem faz parte do histórico do chat e não pode ser alterada.");
                      }
                    }}
                    className="flex flex-col items-center gap-1 group cursor-pointer"
                  >
                    <div className="w-10 h-10 rounded-xl bg-red-500/10 group-hover:bg-red-500/20 text-red-500 flex items-center justify-center transition-all active:scale-95 border border-red-500/20 shadow-sm">
                      <Trash2 size={18} />
                    </div>
                    <span className="text-[11px] font-medium text-red-500/80 tracking-wide">
                      Remover
                    </span>
                  </button>
                </div>

              </div>
            ) : (
              /* General File Previewer layout (for PDFs, Audio, Video, Text/Code files) */
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                className="bg-bg-modal text-text-primary border border-border-strong rounded-3xl w-full max-w-5xl h-full max-h-[90vh] shadow-2xl overflow-hidden flex flex-col"
              >
                <div className="flex items-center justify-between px-2.5 sm:px-4 py-2.5 sm:py-3.5 border-b border-border-subtle bg-bg-surface text-text-primary gap-2 shrink-0">
                  <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0 flex-1">
                    <h2 className="text-xs sm:text-base font-bold text-text-primary max-w-[120px] sm:max-w-md truncate">{fileName}</h2>
                    
                    {isTextFile ? (
                      <>
                        <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-white/5 border border-white/10 text-text-primary font-mono text-[11px] font-bold uppercase tracking-wide shrink-0">
                          {getDeviconUrl(detectedLang.id) ? (
                            <img 
                              src={getDeviconUrl(detectedLang.id)!} 
                              alt={detectedLang.name} 
                              className="w-3.5 h-3.5 object-contain"
                              onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} 
                            />
                          ) : (
                            <Code2 size={12} strokeWidth={2.5} />
                          )}
                          {detectedLang.name}
                        </span>
                        <span className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-white/5 border border-white/10 text-text-muted font-mono text-[11px] shrink-0">
                          <ListOrdered size={12} />
                          {lineCount} {lineCount === 1 ? "linha" : "linhas"}
                        </span>
                      </>
                    ) : (
                      <span className="text-[10px] sm:text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-lg truncate max-w-[100px] sm:max-w-[140px] font-mono shrink-0">
                        {mimeType}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
                    {isTextFile && (detectedLang.id === "html" || detectedLang.id === "svg") && (
                      <button
                        onClick={() => setShowHtmlPreview(true)}
                        className="px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 font-bold text-xs transition-all border border-emerald-500/30 active:scale-95 flex items-center gap-1 shrink-0"
                        title="Testar Renderização HTML"
                      >
                        <Play size={12} className="fill-emerald-400" />
                        <span className="text-xs font-bold">Play</span>
                      </button>
                    )}
                    <button
                      onClick={handleCopy}
                      className="p-1.5 sm:p-2 text-text-muted hover:text-text-primary hover:bg-bg-surface-hover rounded-lg transition-colors flex items-center gap-1"
                      title="Copiar"
                    >
                      <Copy size={16} />
                      <span className="text-xs hidden md:inline font-medium">Copiar</span>
                    </button>
                    <button
                      onClick={handleDownload}
                      className="p-1.5 sm:p-2 text-text-muted hover:text-text-primary hover:bg-bg-surface-hover rounded-lg transition-colors flex items-center gap-1"
                      title="Baixar Arquivo"
                    >
                      <Download size={16} />
                      <span className="text-xs hidden md:inline font-medium">Download</span>
                    </button>
                    <div className="w-px h-4 bg-border-subtle mx-0.5" />
                    <button
                      onClick={onClose}
                      className="p-1.5 sm:p-2 text-text-muted hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                      title="Fechar"
                    >
                      <X size={18} />
                    </button>
                  </div>
                </div>

                <div className="flex-1 min-h-0 w-full overflow-hidden p-2 sm:p-4 bg-bg-main flex flex-col">
                  {isBinary ? (
                    renderBinaryDownloadView()
                  ) : isAudio ? (
                    <div className="w-full h-full flex items-center justify-center bg-bg-surface rounded-lg border border-border-subtle">
                      <audio controls src={dataUrl} className="w-full max-w-md" />
                    </div>
                  ) : isVideo ? (
                    <div className="w-full h-full flex items-center justify-center bg-black/5 rounded-lg overflow-hidden border border-border-subtle">
                      <video controls src={dataUrl} className="max-w-full max-h-full" />
                    </div>
                  ) : isPdf ? (
                    <div className="w-full h-full flex items-center justify-center bg-white rounded-lg overflow-hidden shadow-inner">
                      <iframe src={dataUrl} className="w-full h-full border-0" title={fileName} />
                    </div>
                  ) : (
                    <div className="flex-1 min-h-0 w-full rounded-xl overflow-hidden border border-border-subtle shadow-sm bg-bg-code flex flex-col">
                      <CodeBlock
                        language={detectedLang.id}
                        code={textContent}
                        userSettings={{ codeWrap: true }} 
                        hideHeader={true}
                      />
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* HTML Preview Modal for HTML/SVG files */}
      {showHtmlPreview && (
        <HtmlPreviewModal
          isOpen={showHtmlPreview}
          onClose={() => setShowHtmlPreview(false)}
          code={textContent}
        />
      )}
    </>,
    document.body
  );
};
