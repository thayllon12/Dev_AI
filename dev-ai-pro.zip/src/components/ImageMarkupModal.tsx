import React, { useRef, useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Undo2, Redo2, Type, Paintbrush, Trash2, Pencil, Move } from "lucide-react";
import { toast } from "sonner";

interface ImageMarkupModalProps {
  isOpen: boolean;
  onClose: () => void;
  dataUrl: string;
  onSave: (newDataUrl: string) => void;
}

interface TextAnnotation {
  id: string;
  text: string;
  x: number; // percentage (0-100)
  y: number; // percentage (0-100)
  color: string;
  fontSize: number;
}

interface DrawingStroke {
  points: { x: number; y: number }[];
  color: string;
  width: number;
}

const MARKUP_COLORS = [
  { value: "#000000", label: "Preto", ringColor: "border-white" },
  { value: "#ff4a4a", label: "Vermelho", ringColor: "border-red-500" },
  { value: "#fbbf24", label: "Amarelo", ringColor: "border-yellow-500" },
  { value: "#22c55e", label: "Verde", ringColor: "border-green-500" },
  { value: "#3b82f6", label: "Azul", ringColor: "border-blue-500" },
  { value: "#a855f7", label: "Roxo", ringColor: "border-purple-500" },
  { value: "#ffffff", label: "Branco", ringColor: "border-gray-300" },
];

export const ImageMarkupModal: React.FC<ImageMarkupModalProps> = ({
  isOpen,
  onClose,
  dataUrl,
  onSave,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Tools state
  const [activeTool, setActiveTool] = useState<"sketch" | "annotation">("sketch");
  const [selectedColor, setSelectedColor] = useState<string>("#ff4a4a"); // default Red/Salmon like screenshot

  // Interactive Markup States
  const [strokes, setStrokes] = useState<DrawingStroke[]>([]);
  const [redoStrokes, setRedoStrokes] = useState<DrawingStroke[]>([]);
  const [texts, setTexts] = useState<TextAnnotation[]>([]);
  const [redoTexts, setRedoTexts] = useState<TextAnnotation[]>([]);

  // Local drawing states
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState<{ x: number; y: number }[]>([]);

  // Text addition popup helper
  const [editingTextId, setEditingTextId] = useState<string | null>(null);
  const [inputText, setInputText] = useState("");
  const [clickPos, setClickPos] = useState<{ x: number; y: number } | null>(null);

  // Drag & drop and selection states for text annotations
  const [selectedTextId, setSelectedTextId] = useState<string | null>(null);
  const [draggingTextId, setDraggingTextId] = useState<string | null>(null);
  const [dragStart, setDragStart] = useState<{ clientX: number; clientY: number; textX: number; textY: number } | null>(null);

  // Resize canvas according to loaded image dimensions
  const [imageSize, setImageSize] = useState({ width: 0, height: 0, displayWidth: 0, displayHeight: 0 });

  useEffect(() => {
    if (isOpen) {
      // Reset state for new image
      setStrokes([]);
      setRedoStrokes([]);
      setTexts([]);
      setRedoTexts([]);
      setIsDrawing(false);
      setCurrentStroke([]);
      setEditingTextId(null);
      setClickPos(null);
      setSelectedTextId(null);
      setDraggingTextId(null);
      setDragStart(null);
      setActiveTool("sketch");
    }
  }, [isOpen, dataUrl]);

  const handleImageLoad = () => {
    const img = imageRef.current;
    if (!img) return;

    setImageSize({
      width: img.naturalWidth,
      height: img.naturalHeight,
      displayWidth: img.clientWidth,
      displayHeight: img.clientHeight,
    });
  };

  // Redraw the canvas on image state/resize change
  useEffect(() => {
    const canvas = canvasRef.current;
    const img = imageRef.current;
    if (!canvas || !img || !imageSize.width) return;

    // We set the internal coordinate system of canvas to match the original image size for crisp rendering!
    canvas.width = imageSize.width;
    canvas.height = imageSize.height;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw all strokes
    strokes.forEach((stroke) => {
      if (stroke.points.length < 1) return;
      ctx.beginPath();
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      // Scale coordinates from displaying size to real resolution
      const firstPoint = stroke.points[0];
      ctx.moveTo(
        (firstPoint.x / 100) * canvas.width,
        (firstPoint.y / 100) * canvas.height
      );

      for (let i = 1; i < stroke.points.length; i++) {
        const p = stroke.points[i];
        ctx.lineTo((p.x / 100) * canvas.width, (p.y / 100) * canvas.height);
      }
      ctx.stroke();
    });

    // Draw active current stroke if any
    if (currentStroke.length > 0) {
      ctx.beginPath();
      ctx.strokeStyle = selectedColor;
      ctx.lineWidth = 10; // crisp brush width on full-res
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      const firstPoint = currentStroke[0];
      ctx.moveTo(
        (firstPoint.x / 100) * canvas.width,
        (firstPoint.y / 100) * canvas.height
      );

      for (let i = 1; i < currentStroke.length; i++) {
        const p = currentStroke[i];
        ctx.lineTo((p.x / 100) * canvas.width, (p.y / 100) * canvas.height);
      }
      ctx.stroke();
    }

    // Drawing of texts has been moved to HTML overlay for premium interactive editing (drag, edit, delete).
    // They will be burnt/flattened onto the image upon 'Concluir'.
  }, [strokes, currentStroke, imageSize, selectedColor]);

  // Handle canvas resize automatically
  useEffect(() => {
    const handleResize = () => {
      const img = imageRef.current;
      if (img && img.clientWidth) {
        setImageSize((prev) => ({
          ...prev,
          displayWidth: img.clientWidth,
          displayHeight: img.clientHeight,
        }));
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Helper: Get relative percentages (0-100) for coordinates
  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();
    let clientX = 0;
    let clientY = 0;

    if ("touches" in e) {
      if (e.touches.length === 0) return null;
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = ((clientX - rect.left) / rect.width) * 100;
    const y = ((clientY - rect.top) / rect.height) * 100;

    return { x, y };
  };

  // Sketch mode logic
  const handleStartDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (activeTool !== "sketch") return;
    const coords = getCoordinates(e);
    if (!coords) return;

    setIsDrawing(true);
    setCurrentStroke([coords]);
  };

  const handleDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing || activeTool !== "sketch") return;
    const coords = getCoordinates(e);
    if (!coords) return;

    setCurrentStroke((prev) => [...prev, coords]);
  };

  const handleEndDraw = () => {
    if (!isDrawing) return;
    setIsDrawing(false);

    if (currentStroke.length > 1) {
      const newStroke: DrawingStroke = {
        points: currentStroke,
        color: selectedColor,
        width: Math.max(5, Math.round(imageSize.width * 0.008)), // Dynamic stroke weight based on image dimension
      };
      setStrokes((prev) => [...prev, newStroke]);
      setRedoStrokes([]); // Clear redo stack on new action
    }
    setCurrentStroke([]);
  };

  // Annotation mode logic
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (activeTool !== "annotation") return;
    const coords = getCoordinates(e);
    if (!coords) return;

    setClickPos(coords);
    setInputText("");
    setEditingTextId(null);
  };

  const handleAddText = () => {
    if (!inputText.trim() || !clickPos) return;

    if (editingTextId) {
      // Editing existing annotation
      setTexts((prev) =>
        prev.map((t) =>
          t.id === editingTextId ? { ...t, text: inputText.trim() } : t
        )
      );
      setEditingTextId(null);
    } else {
      // Creating new annotation
      const newText: TextAnnotation = {
        id: Math.random().toString(36).substring(2, 9),
        text: inputText.trim(),
        x: clickPos.x,
        y: clickPos.y,
        color: selectedColor,
        fontSize: 16,
      };
      setTexts((prev) => [...prev, newText]);
      setRedoTexts([]);
    }
    setInputText("");
    setClickPos(null);
  };

  const handleTextMouseDown = (e: React.MouseEvent, t: TextAnnotation) => {
    e.stopPropagation();
    setSelectedTextId(t.id);
    setDraggingTextId(t.id);
    setDragStart({
      clientX: e.clientX,
      clientY: e.clientY,
      textX: t.x,
      textY: t.y
    });
  };

  const handleTextTouchStart = (e: React.TouchEvent, t: TextAnnotation) => {
    e.stopPropagation();
    setSelectedTextId(t.id);
    setDraggingTextId(t.id);
    const touch = e.touches[0];
    setDragStart({
      clientX: touch.clientX,
      clientY: touch.clientY,
      textX: t.x,
      textY: t.y
    });
  };

  const handleGlobalMove = (clientX: number, clientY: number) => {
    if (!draggingTextId || !dragStart || !imageRef.current) return;

    const img = imageRef.current;
    const width = img.clientWidth;
    const height = img.clientHeight;

    const deltaX = clientX - dragStart.clientX;
    const deltaY = clientY - dragStart.clientY;

    const deltaPercentX = (deltaX / width) * 100;
    const deltaPercentY = (deltaY / height) * 100;

    setTexts((prev) =>
      prev.map((t) =>
        t.id === draggingTextId
          ? {
              ...t,
              x: Math.max(2, Math.min(98, dragStart.textX + deltaPercentX)),
              y: Math.max(2, Math.min(98, dragStart.textY + deltaPercentY)),
            }
          : t
      )
    );
  };

  const handleGlobalEnd = () => {
    setDraggingTextId(null);
    setDragStart(null);
  };

  const handleDeleteText = (id: string) => {
    setTexts((prev) => prev.filter((t) => t.id !== id));
    if (selectedTextId === id) {
      setSelectedTextId(null);
    }
    toast.error("Anotação removida!");
  };

  // Undo and Redo controls
  const handleUndo = () => {
    if (activeTool === "sketch") {
      if (strokes.length === 0) return;
      const last = strokes[strokes.length - 1];
      setStrokes((prev) => prev.slice(0, -1));
      setRedoStrokes((prev) => [...prev, last]);
    } else {
      if (texts.length === 0) return;
      const last = texts[texts.length - 1];
      setTexts((prev) => prev.slice(0, -1));
      setRedoTexts((prev) => [...prev, last]);
    }
    toast.info("Desfeito!");
  };

  const handleRedo = () => {
    if (activeTool === "sketch") {
      if (redoStrokes.length === 0) return;
      const last = redoStrokes[redoStrokes.length - 1];
      setRedoStrokes((prev) => prev.slice(0, -1));
      setStrokes((prev) => [...prev, last]);
    } else {
      if (redoTexts.length === 0) return;
      const last = redoTexts[redoTexts.length - 1];
      setRedoTexts((prev) => prev.slice(0, -1));
      setTexts((prev) => [...prev, last]);
    }
    toast.info("Refito!");
  };

  // Flatten the image + markup canvas to generate final data URL
  const handleSaveAndConcluir = () => {
    const canvas = canvasRef.current;
    const img = imageRef.current;
    if (!canvas || !img) {
      onClose();
      return;
    }

    // Create a final master canvas to flatten image + our markup canvas
    const exportCanvas = document.createElement("canvas");
    exportCanvas.width = imageSize.width || img.naturalWidth;
    exportCanvas.height = imageSize.height || img.naturalHeight;

    const ctx = exportCanvas.getContext("2d");
    if (!ctx) {
      onClose();
      return;
    }

    // 1. Draw base image
    ctx.drawImage(img, 0, 0, exportCanvas.width, exportCanvas.height);

    // 2. Overlay drawing markup (strokes)
    ctx.drawImage(canvas, 0, 0, exportCanvas.width, exportCanvas.height);

    // 3. Flatten and draw all text annotations on top of the image
    texts.forEach((txt) => {
      // Calculate responsive text size based on final canvas resolution
      ctx.font = `bold ${Math.round(exportCanvas.width * 0.045)}px sans-serif`;
      ctx.fillStyle = txt.color;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      // Shadow to make text pop
      ctx.shadowColor = "rgba(0, 0, 0, 0.6)";
      ctx.shadowBlur = 12;
      ctx.shadowOffsetX = 2;
      ctx.shadowOffsetY = 2;

      ctx.fillText(
        txt.text,
        (txt.x / 100) * exportCanvas.width,
        (txt.y / 100) * exportCanvas.height
      );

      // Reset shadow
      ctx.shadowColor = "transparent";
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
    });

    // 4. Export to PNG or JPEG data URL
    try {
      const finalDataUrl = exportCanvas.toDataURL("image/png");
      onSave(finalDataUrl);
      toast.success("Imagem editada com sucesso!");
      onClose();
    } catch (e) {
      console.error("Failed to generate marked image:", e);
      toast.error("Erro ao salvar marcações.");
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[120] flex flex-col justify-between bg-[#121214] select-none text-white overflow-hidden p-safe"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-[#121214] shrink-0 z-10">
            <button
              onClick={onClose}
              className="p-2 -ml-2 text-white/80 hover:text-white transition-colors rounded-full hover:bg-white/5"
              aria-label="Voltar / Fechar"
            >
              <X size={24} />
            </button>

            <span className="text-lg font-medium text-white/90 tracking-wide">
              Marcação
            </span>

            <div className="flex items-center gap-3">
              <button
                onClick={handleUndo}
                disabled={(activeTool === "sketch" ? strokes : texts).length === 0}
                className="p-2 text-white/80 hover:text-white hover:bg-white/5 rounded-full transition-colors disabled:opacity-30 disabled:pointer-events-none"
                title="Desfazer"
              >
                <Undo2 size={20} />
              </button>
              <button
                onClick={handleRedo}
                disabled={(activeTool === "sketch" ? redoStrokes : redoTexts).length === 0}
                className="p-2 text-white/80 hover:text-white hover:bg-white/5 rounded-full transition-colors disabled:opacity-30 disabled:pointer-events-none"
                title="Refazer"
              >
                <Redo2 size={20} />
              </button>
            </div>
          </div>

          {/* Canvas & Image Area */}
          <div
            ref={containerRef}
            onClick={() => setSelectedTextId(null)}
            onMouseMove={(e) => {
              if (draggingTextId) {
                handleGlobalMove(e.clientX, e.clientY);
              }
            }}
            onMouseUp={handleGlobalEnd}
            onMouseLeave={handleGlobalEnd}
            onTouchMove={(e) => {
              if (draggingTextId && e.touches.length > 0) {
                handleGlobalMove(e.touches[0].clientX, e.touches[0].clientY);
              }
            }}
            onTouchEnd={handleGlobalEnd}
            className="flex-1 w-full flex items-center justify-center p-6 relative bg-black/40 overflow-hidden"
          >
            <div className="relative max-w-full max-h-[60vh] inline-block shadow-2xl rounded-2xl overflow-hidden border border-white/10">
              <img
                ref={imageRef}
                src={dataUrl}
                alt="Original"
                onLoad={handleImageLoad}
                className="max-w-full max-h-[60vh] object-contain rounded-2xl select-none pointer-events-none"
                referrerPolicy="no-referrer"
              />

              {/* Interaction Canvas Layer */}
              {imageSize.width > 0 && (
                <canvas
                  ref={canvasRef}
                  onMouseDown={handleStartDraw}
                  onMouseMove={handleDrawing}
                  onMouseUp={handleEndDraw}
                  onMouseLeave={handleEndDraw}
                  onTouchStart={handleStartDraw}
                  onTouchMove={handleDrawing}
                  onTouchEnd={handleEndDraw}
                  onClick={handleCanvasClick}
                  className={`absolute inset-0 w-full h-full cursor-crosshair z-20 touch-none`}
                />
              )}

              {/* Dynamic Overlay labels for placed texts */}
              {texts.map((t) => {
                const isSelected = selectedTextId === t.id;
                return (
                  <div
                    key={t.id}
                    style={{
                      position: "absolute",
                      left: `${t.x}%`,
                      top: `${t.y}%`,
                      transform: "translate(-50%, -50%)",
                      color: t.color,
                    }}
                    className={`z-30 font-bold select-none text-base drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] text-center whitespace-nowrap bg-black/50 px-3 py-1 rounded-xl border transition-all cursor-pointer flex items-center gap-2 ${
                      isSelected ? "border-primary scale-105 shadow-2xl ring-2 ring-primary/30" : "border-white/5 hover:border-white/20"
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedTextId(t.id);
                    }}
                    onMouseDown={(e) => handleTextMouseDown(e, t)}
                    onTouchStart={(e) => handleTextTouchStart(e, t)}
                  >
                    <span>{t.text}</span>

                    {/* Controls popup overlay when clicked - designed elegantly for mobile/desktop */}
                    {isSelected && (
                      <div
                        className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-[#18181b] border border-white/15 p-1 rounded-full shadow-2xl z-40"
                        onClick={(e) => e.stopPropagation()}
                        onMouseDown={(e) => e.stopPropagation()}
                        onTouchStart={(e) => e.stopPropagation()}
                      >
                        {/* Drag Handle */}
                        <div
                          className="p-1.5 text-white/50 hover:text-white cursor-move"
                          title="Mover"
                        >
                          <Move size={14} />
                        </div>
                        {/* Pencil/Edit */}
                        <button
                          onClick={() => {
                            setEditingTextId(t.id);
                            setInputText(t.text);
                            setClickPos({ x: t.x, y: t.y });
                          }}
                          className="p-1.5 hover:bg-white/10 text-white/80 hover:text-white rounded-full transition-colors"
                          title="Editar texto"
                        >
                          <Pencil size={14} />
                        </button>
                        {/* Trash */}
                        <button
                          onClick={() => handleDeleteText(t.id)}
                          className="p-1.5 hover:bg-red-500/20 text-red-400 hover:text-red-500 rounded-full transition-colors"
                          title="Excluir"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Floating Quick text editor overlay */}
            <AnimatePresence>
              {clickPos && activeTool === "annotation" && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="absolute z-50 bg-[#1e1e24] border border-white/10 p-4 rounded-2xl shadow-2xl flex flex-col gap-3 w-64"
                  style={{
                    left: `calc(50% - 128px)`,
                    top: "40%",
                  }}
                >
                  <span className="text-xs font-bold text-white/50 uppercase tracking-wider">
                    Nova Anotação de Texto
                  </span>
                  <input
                    type="text"
                    autoFocus
                    placeholder="Escreva algo..."
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleAddText();
                      if (e.key === "Escape") setClickPos(null);
                    }}
                    className="bg-[#121216] border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary w-full"
                  />
                  <div className="flex gap-2 justify-end">
                    <button
                      onClick={() => setClickPos(null)}
                      className="px-3 py-1.5 text-xs font-bold text-white/60 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={handleAddText}
                      className="px-4 py-1.5 text-xs font-bold bg-primary text-white rounded-lg hover:bg-primary-hover transition-colors"
                    >
                      Adicionar
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Footer Controls */}
          <div className="flex flex-col gap-6 px-6 pb-12 pt-6 bg-[#121214] border-t border-white/5 shrink-0 select-none">
            {/* Color selector palette matches screenshot */}
            <div className="flex items-center justify-center gap-4 py-2">
              {MARKUP_COLORS.map((color) => {
                const isSelected = selectedColor === color.value;
                return (
                  <button
                    key={color.value}
                    onClick={() => setSelectedColor(color.value)}
                    className="relative w-8 h-8 rounded-full flex items-center justify-center transition-transform hover:scale-115 active:scale-95"
                    style={{ backgroundColor: color.value }}
                    title={color.label}
                  >
                    {/* Ring highlight like in screenshot */}
                    {isSelected && (
                      <span className={`absolute -inset-1 rounded-full border-2 ${color.ringColor} opacity-90 animate-ping`} />
                    )}
                    {isSelected && (
                      <span className={`absolute -inset-1 rounded-full border-2 ${color.ringColor} opacity-100 shadow-[0_0_8px_rgba(255,255,255,0.4)]`} />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Tool Mode selector and Finish Button */}
            <div className="grid grid-cols-12 gap-4 items-center">
              {/* Empty offset spacer */}
              <div className="col-span-1 hidden md:block" />

              {/* Mode Buttons */}
              <div className="col-span-8 flex items-center justify-center gap-12">
                {/* Esboço Tool */}
                <button
                  onClick={() => {
                    setActiveTool("sketch");
                    setClickPos(null);
                  }}
                  className="flex flex-col items-center gap-2 group"
                >
                  <div
                    className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                      activeTool === "sketch"
                        ? "bg-white text-black shadow-lg"
                        : "bg-white/5 border border-white/10 text-white/80 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    <Paintbrush size={24} />
                  </div>
                  <span
                    className={`text-xs tracking-wide transition-colors ${
                      activeTool === "sketch" ? "font-bold text-white" : "text-white/60 group-hover:text-white/80"
                    }`}
                  >
                    Esboço
                  </span>
                </button>

                {/* Anotação Tool */}
                <button
                  onClick={() => setActiveTool("annotation")}
                  className="flex flex-col items-center gap-2 group"
                >
                  <div
                    className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                      activeTool === "annotation"
                        ? "bg-white text-black shadow-lg"
                        : "bg-white/5 border border-white/10 text-white/80 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    <Type size={24} />
                  </div>
                  <span
                    className={`text-xs tracking-wide transition-colors ${
                      activeTool === "annotation" ? "font-bold text-white" : "text-white/60 group-hover:text-white/80"
                    }`}
                  >
                    Anotação
                  </span>
                </button>
              </div>

              {/* Done / Concluir button */}
              <div className="col-span-4 flex justify-end">
                <button
                  onClick={handleSaveAndConcluir}
                  className="px-8 py-4 bg-white hover:bg-white/90 text-black font-extrabold rounded-full shadow-xl transition-all duration-300 hover:scale-[1.04] active:scale-[0.98] text-sm select-none"
                >
                  Concluir
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
