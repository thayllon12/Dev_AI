import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

interface AudioMessagePlayerProps {
  audioUrl: string;
  duration?: number;
  waveform?: number[];
  authorName?: string;
}

export const AudioMessagePlayer: React.FC<AudioMessagePlayerProps> = ({
  audioUrl,
  duration = 0,
  waveform = [],
  authorName = "Usuário"
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(duration);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Generate synthetic smooth waveform bars if not provided
  const bars = waveform && waveform.length >= 10 ? waveform : [
    30, 45, 60, 80, 50, 70, 90, 65, 40, 55, 75, 85, 60, 45, 70, 95, 80, 60, 40, 30, 50, 70, 85, 65, 45
  ];

  useEffect(() => {
    const audio = new Audio(audioUrl);
    audioRef.current = audio;

    const onLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setTotalDuration(Math.round(audio.duration));
      }
    };

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const onEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.pause();
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('ended', onEnded);
    };
  }, [audioUrl]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(err => {
        console.error("Audio playback error:", err);
      });
    }
  };

  const handleSeek = (index: number) => {
    if (!audioRef.current || totalDuration === 0) return;
    const progress = index / bars.length;
    const seekTime = progress * totalDuration;
    audioRef.current.currentTime = seekTime;
    setCurrentTime(seekTime);
    if (!isPlaying) {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const currentProgress = totalDuration > 0 ? currentTime / totalDuration : 0;

  return (
    <div className="flex items-center gap-3 p-3 bg-[#1e1e24]/90 border border-white/10 rounded-2xl w-full max-w-sm shadow-md backdrop-blur-md">
      {/* Play/Pause Button */}
      <button
        onClick={togglePlay}
        className="w-10 h-10 rounded-full bg-primary hover:bg-primary/80 text-white flex items-center justify-center shrink-0 shadow-lg active:scale-95 transition-transform cursor-pointer"
        title={isPlaying ? "Pausar" : "Reproduzir"}
      >
        {isPlaying ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
      </button>

      {/* Waveform and Progress Bar */}
      <div className="flex-1 flex flex-col gap-1 min-w-0">
        <div className="flex items-center gap-0.5 h-7 cursor-pointer" title="Clique para avançar/retroceder">
          {bars.map((height, idx) => {
            const barProgress = idx / bars.length;
            const isPlayed = barProgress <= currentProgress;
            return (
              <div
                key={idx}
                onClick={() => handleSeek(idx)}
                style={{ height: `${Math.max(15, height)}%` }}
                className={`flex-1 min-w-[2px] max-w-[4px] rounded-full transition-all duration-100 ${
                  isPlayed ? 'bg-primary' : 'bg-white/20 hover:bg-white/40'
                }`}
              />
            );
          })}
        </div>

        {/* Time Stamp and Info */}
        <div className="flex items-center justify-between text-[11px] font-mono text-white/50 px-0.5">
          <span>{formatTime(currentTime > 0 ? currentTime : totalDuration)}</span>
          <span className="text-[10px] text-white/30 truncate">{authorName}</span>
        </div>
      </div>
    </div>
  );
};
