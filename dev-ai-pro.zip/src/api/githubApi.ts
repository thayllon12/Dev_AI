export async function fetchGithub(endpoint: string, options: RequestInit = {}) {
  const url = `/api/github?endpoint=${encodeURIComponent(endpoint)}`;
  
  // Clone options and ensure headers object exists
  const headers = new Headers(options.headers || {});
  
  // If sending a JSON body, ensure Content-Type is set
  if (options.body && typeof options.body === 'string' && !headers.has('Content-Type')) {
    try {
      JSON.parse(options.body);
      headers.set('Content-Type', 'application/json');
    } catch (e) {
      // not json, leave as is
    }
  }

  const response = await fetch(url, {
    ...options,
    headers,
    credentials: 'include', // Important to send the httpOnly cookie
  });

  if (response.status === 401) {
    throw new Error('UNAUTHORIZED');
  }

  if (response.status === 204) {
    return null;
  }

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const errorMsg = data?.message || `GitHub API error: ${response.status} ${response.statusText}`;
    throw new Error(errorMsg);
  }

  return data;
}

export async function checkAuthStatus(): Promise<boolean> {
  try {
    const res = await fetch('/api/auth/status', { credentials: 'include' });
    if (!res.ok) return false;
    const data = await res.json();
    return !!data.authenticated;
  } catch (error) {
    console.error('Error checking auth status:', error);
    return false;
  }
}

export async function logout(): Promise<void> {
  await fetch('/api/auth/logout', {
    method: 'POST',
    credentials: 'include',
  });
}
