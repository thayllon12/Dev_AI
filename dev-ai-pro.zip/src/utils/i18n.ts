export type SupportedLanguage = 'pt' | 'en' | 'es' | 'fr' | 'de' | 'it';

export interface LanguageOption {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'pt', name: 'Português (Brasil)', nativeName: 'Português', flag: '🇧🇷' },
  { code: 'en', name: 'English (US)', nativeName: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'Deutsch', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'it', name: 'Italiano', nativeName: 'Italiano', flag: '🇮🇹' }
];

export const translations: Record<SupportedLanguage, Record<string, string>> = {
  pt: {
    // Header & Navigation
    'app.name': 'Dev AI',
    'app.tagline': 'Assistente Inteligente & Workspace',
    'nav.history': 'Histórico',
    'nav.select': 'Selecionar',
    'nav.cancel': 'Cancelar',
    'nav.delete_selected': 'Excluir selecionados',
    'nav.no_chats': 'Nenhum chat encontrado.',
    'nav.load_more': 'Carregar mais antigos',
    'nav.new_chat': 'Nova conversa',
    'nav.online_users': 'usuários online',
    'nav.online_user': 'usuário online',
    'nav.settings': 'Configurações',
    'nav.call': 'Chamada',
    'nav.share': 'Compartilhar',
    'nav.export': 'Exportar',
    'nav.derive_chat': 'Derivar chat',
    'nav.derived_from': 'Chat derivado de:',
    'nav.rename': 'Renomear',
    'nav.pin': 'Fixar',
    'nav.unpin': 'Desfixar',
    'nav.delete': 'Excluir',

    // Chat Empty State & Inputs
    'chat.empty_title': 'Como posso ajudar hoje?',
    'chat.empty_subtitle': 'Eu sou seu assistente de elite. Posso gerar código, criar projetos, mensagens de áudio, pesquisar e muito mais.',
    'chat.input_placeholder': 'Escreva uma mensagem...',
    'chat.input_listening': 'Falando...',
    'chat.input_processing': 'Processando fala...',
    'chat.replying_to': 'Respondendo a',
    'chat.audio_message': 'Mensagem de áudio',
    'chat.send': 'Enviar',
    'chat.cancel': 'Cancelar',
    'chat.stop': 'Parar',

    // Commands
    'cmd.slash_title': 'Comandos Rápidos (/ )',
    'cmd.call_title': '/ligar',
    'cmd.call_desc': 'Inicia uma chamada de voz ao vivo.',
    'cmd.chat_title': '/chat',
    'cmd.chat_desc': 'Mensagem entre pessoas. A IA não responderá.',
    'cmd.audio_title': '/audio',
    'cmd.audio_desc': 'Grava e envia áudio entre usuários. A IA não interpretará este áudio.',

    // Settings
    'settings.title': 'Configurações do Dev AI',
    'settings.language': 'Idioma',
    'settings.language_desc': 'Escolha o idioma preferencial da interface e da IA',
    'settings.theme': 'Tema',
    'settings.mode': 'Modo de Resposta',
    'settings.save': 'Salvar Alterações',

    // Artifacts & Code
    'artifact.preview': 'Ver prévia',
    'artifact.code': 'Código',
    'artifact.copy': 'Copiar',
    'artifact.download': 'Baixar',
    'artifact.publish': 'Publicar no GitHub',
    'artifact.close_preview': 'Fechar prévia',
    'artifact.project': 'Projeto',
    'artifact.files': 'arquivos',

    // Call
    'call.connecting': 'Conectando...',
    'call.listening': 'Ouvindo...',
    'call.processing': 'Processando...',
    'call.responding': 'Respondendo...',
    'call.paused': 'Pausado',
    'call.end_call': 'Encerrar chamada',
    'call.minimize': 'Minimizar',
    'call.maximize': 'Maximizar',
    'call.active_call': 'Chamada Ativa'
  },
  en: {
    'app.name': 'Dev AI',
    'app.tagline': 'Intelligent Assistant & Workspace',
    'nav.history': 'History',
    'nav.select': 'Select',
    'nav.cancel': 'Cancel',
    'nav.delete_selected': 'Delete selected',
    'nav.no_chats': 'No chats found.',
    'nav.load_more': 'Load older',
    'nav.new_chat': 'New chat',
    'nav.online_users': 'online users',
    'nav.online_user': 'online user',
    'nav.settings': 'Settings',
    'nav.call': 'Call',
    'nav.share': 'Share',
    'nav.export': 'Export',
    'nav.derive_chat': 'Branch chat',
    'nav.derived_from': 'Chat branched from:',
    'nav.rename': 'Rename',
    'nav.pin': 'Pin',
    'nav.unpin': 'Unpin',
    'nav.delete': 'Delete',

    'chat.empty_title': 'How can I help you today?',
    'chat.empty_subtitle': 'I am your elite assistant. I can generate code, build projects, send audio messages, search the web, and more.',
    'chat.input_placeholder': 'Type a message...',
    'chat.input_listening': 'Listening...',
    'chat.input_processing': 'Processing speech...',
    'chat.replying_to': 'Replying to',
    'chat.audio_message': 'Voice message',
    'chat.send': 'Send',
    'chat.cancel': 'Cancel',
    'chat.stop': 'Stop',

    'cmd.slash_title': 'Quick Commands (/ )',
    'cmd.call_title': '/call',
    'cmd.call_desc': 'Start a live voice call.',
    'cmd.chat_title': '/chat',
    'cmd.chat_desc': 'Human-to-human chat. AI will not respond.',
    'cmd.audio_title': '/audio',
    'cmd.audio_desc': 'Record and send voice note to users. AI will not process this audio.',

    'settings.title': 'Dev AI Settings',
    'settings.language': 'Language',
    'settings.language_desc': 'Choose your preferred language for the UI and AI',
    'settings.theme': 'Theme',
    'settings.mode': 'Response Mode',
    'settings.save': 'Save Changes',

    'artifact.preview': 'Preview',
    'artifact.code': 'Code',
    'artifact.copy': 'Copy',
    'artifact.download': 'Download',
    'artifact.publish': 'Publish to GitHub',
    'artifact.close_preview': 'Close preview',
    'artifact.project': 'Project',
    'artifact.files': 'files',

    'call.connecting': 'Connecting...',
    'call.listening': 'Listening...',
    'call.processing': 'Processing...',
    'call.responding': 'Responding...',
    'call.paused': 'Paused',
    'call.end_call': 'End Call',
    'call.minimize': 'Minimize',
    'call.maximize': 'Maximize',
    'call.active_call': 'Active Call'
  },
  es: {
    'app.name': 'Dev AI',
    'app.tagline': 'Asistente Inteligente y Espacio de Trabajo',
    'nav.history': 'Historial',
    'nav.select': 'Seleccionar',
    'nav.cancel': 'Cancelar',
    'nav.delete_selected': 'Eliminar seleccionados',
    'nav.no_chats': 'No se encontraron conversaciones.',
    'nav.load_more': 'Cargar más antiguos',
    'nav.new_chat': 'Nueva conversación',
    'nav.online_users': 'usuarios en línea',
    'nav.online_user': 'usuario en línea',
    'nav.settings': 'Configuración',
    'nav.call': 'Llamada',
    'nav.share': 'Compartir',
    'nav.export': 'Exportar',
    'nav.derive_chat': 'Derivar chat',
    'nav.derived_from': 'Chat derivado de:',
    'nav.rename': 'Renombrar',
    'nav.pin': 'Fijar',
    'nav.unpin': 'Desfijar',
    'nav.delete': 'Eliminar',

    'chat.empty_title': '¿Cómo puedo ayudarte hoy?',
    'chat.empty_subtitle': 'Soy tu asistente de élite. Puedo generar código, crear proyectos, mensajes de voz y mucho más.',
    'chat.input_placeholder': 'Escribe un mensaje...',
    'chat.input_listening': 'Escuchando...',
    'chat.input_processing': 'Procesando voz...',
    'chat.replying_to': 'Respondiendo a',
    'chat.audio_message': 'Mensaje de voz',
    'chat.send': 'Enviar',
    'chat.cancel': 'Cancelar',
    'chat.stop': 'Detener',

    'cmd.slash_title': 'Comandos Rápidos (/ )',
    'cmd.call_title': '/ligar',
    'cmd.call_desc': 'Inicia una llamada de voz en vivo.',
    'cmd.chat_title': '/chat',
    'cmd.chat_desc': 'Mensaje entre usuarios. La IA no responderá.',
    'cmd.audio_title': '/audio',
    'cmd.audio_desc': 'Grabar y enviar nota de voz entre usuarios.',

    'settings.title': 'Configuración de Dev AI',
    'settings.language': 'Idioma',
    'settings.language_desc': 'Elige tu idioma preferido para la interfaz y la IA',
    'settings.theme': 'Tema',
    'settings.mode': 'Modo de respuesta',
    'settings.save': 'Guardar Cambios',

    'artifact.preview': 'Ver vista previa',
    'artifact.code': 'Código',
    'artifact.copy': 'Copiar',
    'artifact.download': 'Descargar',
    'artifact.publish': 'Publicar en GitHub',
    'artifact.close_preview': 'Cerrar vista previa',
    'artifact.project': 'Proyecto',
    'artifact.files': 'archivos',

    'call.connecting': 'Conectando...',
    'call.listening': 'Escuchando...',
    'call.processing': 'Procesando...',
    'call.responding': 'Respondiendo...',
    'call.paused': 'Pausado',
    'call.end_call': 'Finalizar llamada',
    'call.minimize': 'Minimizar',
    'call.maximize': 'Maximizar',
    'call.active_call': 'Llamada Activa'
  },
  fr: {
    'app.name': 'Dev AI',
    'app.tagline': 'Assistant Intelligent et Espace de Travail',
    'nav.history': 'Historique',
    'nav.select': 'Sélectionner',
    'nav.cancel': 'Annuler',
    'nav.delete_selected': 'Supprimer sélectionnés',
    'nav.no_chats': 'Aucune conversation trouvée.',
    'nav.load_more': 'Charger plus anciens',
    'nav.new_chat': 'Nouvelle conversation',
    'nav.online_users': 'utilisateurs en ligne',
    'nav.online_user': 'utilisateur en ligne',
    'nav.settings': 'Paramètres',
    'nav.call': 'Appel',
    'nav.share': 'Partager',
    'nav.export': 'Exporter',
    'nav.derive_chat': 'Dériver le chat',
    'nav.derived_from': 'Chat dérivé de :',
    'nav.rename': 'Renommer',
    'nav.pin': 'Épingler',
    'nav.unpin': 'Détacher',
    'nav.delete': 'Supprimer',

    'chat.empty_title': 'Comment puis-je vous aider ?',
    'chat.empty_subtitle': 'Je suis votre assistant d\'élite. Je peux générer du code, créer des projets et plus encore.',
    'chat.input_placeholder': 'Écrivez un message...',
    'chat.input_listening': 'Écoute en cours...',
    'chat.input_processing': 'Traitement vocal...',
    'chat.replying_to': 'En réponse à',
    'chat.audio_message': 'Message vocal',
    'chat.send': 'Envoyer',
    'chat.cancel': 'Annuler',
    'chat.stop': 'Arrêter',

    'cmd.slash_title': 'Commandes rapides (/ )',
    'cmd.call_title': '/appel',
    'cmd.call_desc': 'Démarrer un appel vocal en direct.',
    'cmd.chat_title': '/chat',
    'cmd.chat_desc': 'Chat entre humains. L\'IA ne répondra pas.',
    'cmd.audio_title': '/audio',
    'cmd.audio_desc': 'Enregistrer et envoyer un message vocal entre utilisateurs.',

    'settings.title': 'Paramètres Dev AI',
    'settings.language': 'Langue',
    'settings.language_desc': 'Choisissez votre langue préférée pour l\'interface et l\'IA',
    'settings.theme': 'Thème',
    'settings.mode': 'Mode de réponse',
    'settings.save': 'Enregistrer les modifications',

    'artifact.preview': 'Aperçu',
    'artifact.code': 'Code',
    'artifact.copy': 'Copier',
    'artifact.download': 'Télécharger',
    'artifact.publish': 'Publier sur GitHub',
    'artifact.close_preview': 'Fermer l\'aperçu',
    'artifact.project': 'Projet',
    'artifact.files': 'fichiers',

    'call.connecting': 'Connexion...',
    'call.listening': 'Écoute...',
    'call.processing': 'Traitement...',
    'call.responding': 'Réponse en cours...',
    'call.paused': 'En pause',
    'call.end_call': 'Mettre fin à l\'appel',
    'call.minimize': 'Réduire',
    'call.maximize': 'Agrandir',
    'call.active_call': 'Appel en cours'
  },
  de: {
    'app.name': 'Dev AI',
    'app.tagline': 'Intelligenter Assistent & Workspace',
    'nav.history': 'Verlauf',
    'nav.select': 'Auswählen',
    'nav.cancel': 'Abbrechen',
    'nav.delete_selected': 'Ausgewählte löschen',
    'nav.no_chats': 'Keine Chats gefunden.',
    'nav.load_more': 'Ältere laden',
    'nav.new_chat': 'Neuer Chat',
    'nav.online_users': 'Benutzer online',
    'nav.online_user': 'Benutzer online',
    'nav.settings': 'Einstellungen',
    'nav.call': 'Anruf',
    'nav.share': 'Teilen',
    'nav.export': 'Exportieren',
    'nav.derive_chat': 'Chat ableiten',
    'nav.derived_from': 'Abgeleitet von:',
    'nav.rename': 'Umbenennen',
    'nav.pin': 'Anheften',
    'nav.unpin': 'Lösen',
    'nav.delete': 'Löschen',

    'chat.empty_title': 'Wie kann ich heute helfen?',
    'chat.empty_subtitle': 'Ich bin dein Elite-Assistent. Ich kann Code generieren, Projekte erstellen und vieles mehr.',
    'chat.input_placeholder': 'Nachricht schreiben...',
    'chat.input_listening': 'Zuhören...',
    'chat.input_processing': 'Sprache wird verarbeitet...',
    'chat.replying_to': 'Antwort an',
    'chat.audio_message': 'Sprachnachricht',
    'chat.send': 'Senden',
    'chat.cancel': 'Abbrechen',
    'chat.stop': 'Stoppen',

    'cmd.slash_title': 'Schnellbefehle (/ )',
    'cmd.call_title': '/anruf',
    'cmd.call_desc': 'Live-Sprachanruf starten.',
    'cmd.chat_title': '/chat',
    'cmd.chat_desc': 'Chat zwischen Menschen. KI antwortet nicht.',
    'cmd.audio_title': '/audio',
    'cmd.audio_desc': 'Sprachnachricht aufnehmen und an Benutzer senden.',

    'settings.title': 'Dev AI Einstellungen',
    'settings.language': 'Sprache',
    'settings.language_desc': 'Wähle deine bevorzugte Sprache für Oberfläche und KI',
    'settings.theme': 'Design',
    'settings.mode': 'Antwortmodus',
    'settings.save': 'Änderungen speichern',

    'artifact.preview': 'Vorschau',
    'artifact.code': 'Code',
    'artifact.copy': 'Kopieren',
    'artifact.download': 'Herunterladen',
    'artifact.publish': 'Auf GitHub veröffentlichen',
    'artifact.close_preview': 'Vorschau schließen',
    'artifact.project': 'Projekt',
    'artifact.files': 'Dateien',

    'call.connecting': 'Verbinden...',
    'call.listening': 'Hört zu...',
    'call.processing': 'Verarbeitung...',
    'call.responding': 'Antwortet...',
    'call.paused': 'Pausiert',
    'call.end_call': 'Anruf beenden',
    'call.minimize': 'Minimieren',
    'call.maximize': 'Maximieren',
    'call.active_call': 'Aktiver Anruf'
  },
  it: {
    'app.name': 'Dev AI',
    'app.tagline': 'Assistente Intelligente & Workspace',
    'nav.history': 'Cronologia',
    'nav.select': 'Seleziona',
    'nav.cancel': 'Annulla',
    'nav.delete_selected': 'Elimina selezionati',
    'nav.no_chats': 'Nessuna chat trovata.',
    'nav.load_more': 'Carica precedenti',
    'nav.new_chat': 'Nuova chat',
    'nav.online_users': 'utenti online',
    'nav.online_user': 'utente online',
    'nav.settings': 'Impostazioni',
    'nav.call': 'Chiamata',
    'nav.share': 'Condividi',
    'nav.export': 'Esporta',
    'nav.derive_chat': 'Deriva chat',
    'nav.derived_from': 'Chat derivata da:',
    'nav.rename': 'Rinomina',
    'nav.pin': 'Fissa',
    'nav.unpin': 'Sblocca',
    'nav.delete': 'Elimina',

    'chat.empty_title': 'Come posso aiutarti oggi?',
    'chat.empty_subtitle': 'Sono il tuo assistente d\'élite. Posso generare codice, creare progetti, note vocali e molto altro.',
    'chat.input_placeholder': 'Scrivi un messaggio...',
    'chat.input_listening': 'In ascolto...',
    'chat.input_processing': 'Elaborazione vocale...',
    'chat.replying_to': 'In risposta a',
    'chat.audio_message': 'Messaggio vocale',
    'chat.send': 'Invia',
    'chat.cancel': 'Annulla',
    'chat.stop': 'Interrompi',

    'cmd.slash_title': 'Comandi rapidi (/ )',
    'cmd.call_title': '/chiama',
    'cmd.call_desc': 'Avvia una chiamata vocale in tempo reale.',
    'cmd.chat_title': '/chat',
    'cmd.chat_desc': 'Chat tra persone. L\'IA non risponderà.',
    'cmd.audio_title': '/audio',
    'cmd.audio_desc': 'Registra e invia nota vocale tra utenti.',

    'settings.title': 'Impostazioni Dev AI',
    'settings.language': 'Lingua',
    'settings.language_desc': 'Scegli la lingua preferita per l\'interfaccia e l\'IA',
    'settings.theme': 'Tema',
    'settings.mode': 'Modalità di risposta',
    'settings.save': 'Salva modifiche',

    'artifact.preview': 'Anteprima',
    'artifact.code': 'Codice',
    'artifact.copy': 'Copia',
    'artifact.download': 'Scarica',
    'artifact.publish': 'Pubblica su GitHub',
    'artifact.close_preview': 'Chiudi anteprima',
    'artifact.project': 'Progetto',
    'artifact.files': 'file',

    'call.connecting': 'Connessione...',
    'call.listening': 'In ascolto...',
    'call.processing': 'Elaborazione...',
    'call.responding': 'Risposta in corso...',
    'call.paused': 'In pausa',
    'call.end_call': 'Termina chiamata',
    'call.minimize': 'Riduci a icona',
    'call.maximize': 'Ingrandisci',
    'call.active_call': 'Chiamata attiva'
  }
};

/**
 * Detects default system/browser language
 */
export function detectDefaultLanguage(): SupportedLanguage {
  try {
    const saved = localStorage.getItem('devai_language') as SupportedLanguage;
    if (saved && translations[saved]) {
      return saved;
    }

    const browserLang = (
      (navigator.languages && navigator.languages[0]) ||
      navigator.language ||
      ''
    ).toLowerCase();

    if (browserLang.startsWith('pt')) return 'pt';
    if (browserLang.startsWith('es')) return 'es';
    if (browserLang.startsWith('fr')) return 'fr';
    if (browserLang.startsWith('de')) return 'de';
    if (browserLang.startsWith('it')) return 'it';
    return 'en';
  } catch {
    return 'pt';
  }
}

let currentLanguage: SupportedLanguage = detectDefaultLanguage();
const listeners: Array<(lang: SupportedLanguage) => void> = [];

export function getLanguage(): SupportedLanguage {
  return currentLanguage;
}

export function setLanguage(lang: SupportedLanguage) {
  if (translations[lang]) {
    currentLanguage = lang;
    try {
      localStorage.setItem('devai_language', lang);
    } catch {}
    listeners.forEach((cb) => cb(lang));
  }
}

export function subscribeLanguage(callback: (lang: SupportedLanguage) => void) {
  listeners.push(callback);
  return () => {
    const index = listeners.indexOf(callback);
    if (index !== -1) listeners.splice(index, 1);
  };
}

export function t(key: string, defaultText?: string): string {
  const currentDict = translations[currentLanguage];
  if (currentDict && currentDict[key]) {
    return currentDict[key];
  }
  const fallbackDict = translations['en'];
  if (fallbackDict && fallbackDict[key]) {
    return fallbackDict[key];
  }
  return defaultText || key;
}

export function getSystemLanguagePromptInstruction(lang: SupportedLanguage = currentLanguage): string {
  const map: Record<SupportedLanguage, string> = {
    pt: "Responda em Português do Brasil de forma natural, direta e precisa. Se o usuário pedir para falar em outro idioma, atenda ao pedido.",
    en: "Respond in clear, natural, and concise English. If the user explicitly asks to speak in another language, follow their request.",
    es: "Responde en español de forma natural, clara y concisa. Si el usuario pide hablar en otro idioma, cumple con su solicitud.",
    fr: "Répondez en français de manière claire, naturelle et concise. Si l'utilisateur demande une autre langue, adaptez-vous.",
    de: "Antworte auf Deutsch klar, präzise und natürlich. Wenn der Benutzer eine andere Sprache wünscht, passe dich an.",
    it: "Rispondi in italiano in modo chiaro, naturale e conciso. Se l'utente richiede un'altra lingua, adattati alla richiesta."
  };
  return map[lang] || map['pt'];
}
