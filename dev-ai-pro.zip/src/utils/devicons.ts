const DEVICON_SLUGS = new Set([
  "html5", "css3", "javascript", "typescript", "python", "java", "c", "cplusplus", "csharp", "lua", "php", "ruby", "go", "rust", "swift", "kotlin", "dart", "r", "scala", "perl", "haskell", "elixir", "clojure", "objectivec", "matlab", "fortran", "julia", "zig", "bash", "powershell", "aarch64", "adonisjs", "aftereffects", "akka", "algolia", "alpinejs", "amazonwebservices", "anaconda", "android", "androidstudio", "angular", "angularmaterial", "ansible", "antdesign", "apache", "apachekafka", "apex", "apppwrite", "apple", "appstore", "archlinux", "arduino", "argocd", "astro", "atom", "azure", "babel", "backbonejs", "ballerina", "bamboo", "baremetal", "beats", "behance", "bitbucket", "blender", "bootstrap", "bower", "bulma", "bun", "cairo", "cakephp", "canva", "capistran", "capacitor", "cassandra", "centos", "ceylon", "chrome", "circleci", "clion", "clojurescript", "cloudflare", "cmake", "codeac", "codecov", "codeigniter", "codepen", "coffeescript", "composer", "confluence", "consul", "cordova", "corejs", "couchbase", "couchdb", "crystal", "cypress", "d3js", "dbeaver", "debian", "deno", "devicon", "digitalocean", "discourse", "django", "djangorest", "docker", "doctrine", "dot-net", "dotnetcore", "dreamweaver", "dropwizard", "drupal", "dynamodb", "eclipse", "ectron", "elasticsearch", "elm", "emacs", "embeddedc", "ember", "envoy", "erlang", "eslint", "fsharp", "fastapi", "fastify", "feathersjs", "fedora", "figma", "filezilla", "firebase", "firefox", "flask", "flutter", "foundation", "framer", "gatsby", "gatling", "geeqie", "gentoo", "gimp", "git", "gitbook", "github", "gitlab", "gitpod", "gleam", "gnome", "godot", "google", "googlecloud", "gradle", "grafana", "grails", "graphql", "groovy", "grunt", "gulp", "hadoop", "haxe", "helm", "heroku", "hibernate", "homebrew", "html5-3d", "hugo", "ian", "ie10", "ifttt", "illustrator", "inkscape", "insomnia", "intellij", "ionic", "jaegertracing", "jamstack", "jasmine", "jeecg", "jenkins", "jest", "jetbrains", "jetpackcompose", "jira", "jquery", "json", "julia-plain", "juniper", "jupyter", "k3s", "k6", "kaggle", "karate", "karma", "kde", "keras", "kibana", "knexjs", "knockout", "krakenjs", "kubernetes", "labview", "laravel", "latex", "less", "linkedin", "linux", "lit", "livewire", "llvm", "lodash", "logstash", "lua-plain", "lumens", "magento", "mariadb", "markdown", "materialui", "matlab-plain", "mattermost", "maven", "maya", "meilisearch", "mempool", "meteor", "microfocus", "microsoft", "minitab", "mint", "mira", "mithril", "mobx", "mocha", "modx", "moleculer", "mongodb", "mongoose", "monkeytie", "mono", "mootools", "mysql", "nano", "neo4j", "neovim", "nestjs", "netians", "netlify", "networkx", "nextjs", "nginx", "nixos", "nodewebkit", "nodejs", "nodemon", "npm", "nuget", "numpy", "nuxt", "nwjs", "oauth", "ocaml", "octave", "okta", "openal", "openapi", "cl", "opencv", "opengl", "openstack", "opensuse", "opentelemetry", "opera", "oracle", "p5js", "packer", "pandas", "pdm", "phoenix", "photoshop", "phpstorm", "playwright", "plotly", "pm2", "pnpm", "podman", "poetry", "polygon", "portainer", "postcss", "postgresql", "postman", "premierepro", "prisma", "processing", "prolog", "prometheus", "protractor", "pulsar", "puppeteer", "pwa", "pycharm", "pypi", "pyspark", "pytest", "qt", "rstudio", "rabbitmq", "rails", "railway", "rancher", "raspberrypi", "react", "reactbootstrap", "reactrouter", "redhat", "redis", "redux", "renpy", "replit", "rider", "rocksdb", "rollup", "ros", "rspec", "rubymine", "rxjs", "s3", "safari", "salesforce", "sanity", "sass", "sauron", "scikitlearn", "sdl", "selenium", "semver", "sentry", "sequelize", "shotcut", "sketch", "slack", "socketio", "solidity", "solidjs", "sonarqube", "sourcetree", "spack", "splunk", "spring", "sqldelight", "sqlite", "sqlsrv", "ssh", "stackoverflow", "storybook", "strapi", "streamlit", "stylus", "sublime", "supabase", "swagger", "swig", "symfony", "tailwindcss", "tauri", "tensorflow", "terraform", "tex", "threejs", "thymeleaf", "tmux", "trello", "trpc", "twitter", "ubuntu", "unity", "unix", "unrealengine", "v3", "vagrant", "vala", "vault", "vercel", "vertx", "vim", "visualstudio", "vite", "vitest", "vlang", "vscode", "vuejs", "vuestorefront", "vuetify", "vyper", "webassembly", "webflow", "webrtc", "webpack", "webstorm", "wechat", "windi", "windows8", "woocommerce", "wordpress", "xamarin", "xcode", "xd", "xml", "yaml", "yarn", "yew", "yunohost", "zbrush"
]);

const ALIAS_MAP: Record<string, string> = {
  html: "html5",
  htm: "html5",
  xhtml: "html5",
  css: "css3",
  scss: "sass",
  sass: "sass",
  less: "less",
  js: "javascript",
  jsx: "react",
  ts: "typescript",
  tsx: "react",
  py: "python",
  python: "python",
  java: "java",
  c: "c",
  "c++": "cplusplus",
  cpp: "cplusplus",
  cplusplus: "cplusplus",
  "c#": "csharp",
  cs: "csharp",
  csharp: "csharp",
  php: "php",
  rb: "ruby",
  ruby: "ruby",
  go: "go",
  golang: "go",
  rs: "rust",
  rust: "rust",
  swift: "swift",
  kt: "kotlin",
  kotlin: "kotlin",
  dart: "dart",
  lua: "lua",
  sh: "bash",
  bash: "bash",
  zsh: "bash",
  shell: "bash",
  ps1: "powershell",
  powershell: "powershell",
  json: "json",
  md: "markdown",
  markdown: "markdown",
  docker: "docker",
  dockerfile: "docker",
  sql: "postgresql",
  mysql: "mysql",
  postgres: "postgresql",
  postgresql: "postgresql",
  sqlite: "sqlite",
  yml: "yaml",
  yaml: "yaml",
  xml: "xml",
  vue: "vuejs",
  react: "react",
  angular: "angular",
  svelte: "svelte",
  flutter: "flutter",
  tailwind: "tailwindcss",
  tailwindcss: "tailwindcss",
  bootstrap: "bootstrap",
  graphql: "graphql"
};

export function getDeviconUrl(lang?: string): string | null {
  if (!lang) return null;
  const clean = lang.trim().toLowerCase();
  
  const slug = ALIAS_MAP[clean] || (DEVICON_SLUGS.has(clean) ? clean : null);
  
  if (slug) {
    return `https://cdn.jsdelivr.net/gh/devicons/devicon/icons/${slug}/${slug}-original.svg`;
  }
  return null;
}
