with open("recovered_73_0x7fb0d0000000.tsx", "rb") as f:
    data = f.read()

# let's look for "export const getAI" anywhere in the chunk
target = b"export const getAI"
idx = data.find(target)
if idx != -1:
    print("Found getAI at", idx)
    print(data[idx:idx+500].decode("utf-8", "ignore"))
else:
    print("getAI not found in 0x7fb0...")
    
with open("recovered_90_0xc000000000.tsx", "rb") as f:
    data = f.read()
idx = data.find(target)
if idx != -1:
    print("Found getAI at", idx)
    print(data[idx:idx+500].decode("utf-8", "ignore"))
else:
    print("getAI not found in 0xc000...")
