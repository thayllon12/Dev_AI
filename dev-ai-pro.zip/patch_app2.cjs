const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const target1 = "const [micState, setMicState] = useState<{ isRecording: boolean; volume: number[] }>({ isRecording: false, volume: [] });";
if (content.includes(target1)) {
    content = content.replace(target1, target1 + '\n  const [githubModal, setGithubModal] = useState<{ isOpen: boolean; mode: "import" | "export" }>({ isOpen: false, mode: "import" });');
}

const lines = content.split('\n');
let newLines = [];
let skip = false;
for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes('<MicrofoneGemini') && !line.includes('import')) {
        skip = true;
        newLines.push(`                    <button
                      type="button"
                      onClick={() => setGithubModal({ isOpen: true, mode: 'export' })}
                      className="p-2 sm:p-2.5 text-text-muted hover:text-text-primary rounded-xl hover:bg-bg-surface-hover transition-colors shrink-0"
                      title="Exportar para GitHub"
                    >
                      <Github size={20} strokeWidth={2.5} />
                    </button>`);
        continue;
    }
    if (skip && line.includes('onStateChange={setMicState}')) {
        skip = false;
        // Skip the closing tag line as well
        if (lines[i].includes('/>')) {
             // already closed on this line
        } else if (lines[i+1] && lines[i+1].includes('/>')) {
             i++; // skip next line
        }
        continue;
    }
    if (!skip) {
        newLines.push(line);
    }
}
content = newLines.join('\n');

const toasterTag = '<Toaster position="top-center" richColors />';
if (content.includes(toasterTag)) {
    content = content.replace(toasterTag, `<GithubSyncModal 
        isOpen={githubModal.isOpen} 
        mode={githubModal.mode} 
        onClose={() => setGithubModal({ ...githubModal, isOpen: false })} 
      />\n      ` + toasterTag);
}

fs.writeFileSync('src/App.tsx', content);
