import sys

def extract():
    with open("recovered_90_0xc000000000.tsx", "rb") as f:
        data = f.read()
    
    # In Go, strings don't have null terminators but the surrounding memory will have them or other garbage.
    # We can try to decode as utf-8 and ignore errors, then look for the end of the file.
    # The file should end with ");\n}" or similar.
    
    text = data.decode("utf-8", errors="ignore")
    # find the end of the App component. The last thing was `Toaster position="top-center" richColors />\n    </div>\n  );\n}`
    
    idx = text.find("<Toaster position=\"top-center\" richColors />")
    if idx != -1:
        end_idx = text.find("}", idx)
        clean_text = text[:end_idx+1]
        with open("App_recovered_clean.tsx", "w") as out:
            out.write(clean_text)
        print("Success, length:", len(clean_text))
    else:
        print("Could not find end of App component")

if __name__ == "__main__":
    extract()
