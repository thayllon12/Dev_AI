head -n 104 src/App.tsx > new_App.tsx
cat App_recovered_clean.tsx >> new_App.tsx
mv new_App.tsx src/App.tsx
