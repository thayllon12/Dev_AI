const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const target1 = "const [micState, setMicState] = useState<{ isRecording: boolean; volume: number[] }>({ isRecording: false, volume: [] });";
if (content.includes(target1)) {
    content = content.replace(target1, target1 + '\n  const [githubModal, setGithubModal] = useState<{ isOpen: boolean; mode: "import" | "export" }>({ isOpen: false, mode: "import" });');
}

const target2 = `                    <MicrofoneGemini 
                      ref={micRef}
                      onTranscricaoConcluida={(texto, autoSend) => {
                        if (!texto) return;
                        let fullText = texto;
                        setInput((prev) => {
                          fullText = prev && prev.trim() ? prev.trim() + " " + texto : texto;
                          return fullText;
                        });
                        if (autoSend) {
                          setTimeout(() => {
                            handleSend(fullText);
                          }, 50);
                        }
                      }} 
                      onStateChange={setMicState}
                    />`;

const replacement2 = `                    <button
                      type="button"
                      onClick={() => setGithubModal({ isOpen: true, mode: 'export' })}
                      className="p-2 sm:p-2.5 text-text-muted hover:text-text-primary rounded-xl hover:bg-bg-surface-hover transition-colors shrink-0"
                      title="Sincronizar com GitHub"
                    >
                      <Github size={20} strokeWidth={2.5} />
                    </button>`;

if (content.includes(target2)) {
    content = content.replace(target2, replacement2);
} else {
    console.log("target2 not found");
}

const toasterTag = '<Toaster position="top-center" richColors />';
if (content.includes(toasterTag)) {
    content = content.replace(toasterTag, `<GithubSyncModal 
        isOpen={githubModal.isOpen} 
        mode={githubModal.mode} 
        onClose={() => setGithubModal({ ...githubModal, isOpen: false })} 
      />\n      ` + toasterTag);
}

fs.writeFileSync('src/App.tsx', content);
