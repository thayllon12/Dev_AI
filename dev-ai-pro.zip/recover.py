import sys

def recover(filename):
    with open(filename, 'rb') as f:
        data = f.read()
    
    target = b"export default function App() {"
    idx = 0
    while True:
        idx = data.find(target, idx)
        if idx == -1:
            break
        print(f"Found at {idx}")
        # Extract a large chunk to see if it's the right one
        chunk = data[idx:idx+250000]
        # Find the end of the file or function
        # We can just write it to a file
        with open(f"recovered_{idx}.tsx", "wb") as out:
            out.write(chunk)
        idx += 1

if __name__ == "__main__":
    recover(sys.argv[1])
