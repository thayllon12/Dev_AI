import sys
with open('src/App.tsx', 'r') as f:
    text = f.read()
text = text.replace("window.aistudio", "(window as any).aistudio")
with open('src/App.tsx', 'w') as f:
    f.write(text)
