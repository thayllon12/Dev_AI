import sys

def extract():
    with open("recovered_90_0xc000000000.tsx", "rb") as f:
        data = f.read()
    
    text = data.decode("utf-8", "ignore")
    idx = text.find("export default function App")
    if idx != -1:
        # Search for Toaster
        toaster_idx = text.find("<Toaster position=", idx)
        if toaster_idx != -1:
            end_idx = text.find(";}", toaster_idx)
            if end_idx == -1:
                end_idx = text.find("  );\n}", toaster_idx)
            if end_idx != -1:
                clean_text = text[idx:end_idx+6]
                with open("App_recovered_clean.tsx", "w") as out:
                    out.write(clean_text)
                print(f"Success! Length: {len(clean_text)}")
                return
        print("Toaster not found, writing 150000 chars")
        with open("App_recovered_clean.tsx", "w") as out:
            out.write(text[idx:idx+150000])

if __name__ == "__main__":
    extract()
