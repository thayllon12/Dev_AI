import re
import sys

def dump_memory(pid):
    maps_file = f"/proc/{pid}/maps"
    mem_file = f"/proc/{pid}/mem"
    
    with open(maps_file, 'r') as map_f, open(mem_file, 'rb', 0) as mem_f:
        for line in map_f:
            parts = line.split()
            if len(parts) >= 2:
                perms = parts[1]
                if 'r' in perms:  # Readable
                    addr_range = parts[0]
                    start, end = [int(x, 16) for x in addr_range.split('-')]
                    
                    try:
                        mem_f.seek(start)
                        chunk = mem_f.read(end - start)
                        
                        target = b"export default function App() {"
                        idx = chunk.find(target)
                        if idx != -1:
                            print(f"Found in PID {pid} at {hex(start + idx)}")
                            # save a bit earlier
                            start_idx = max(0, idx - 4000)
                            with open(f"imports_recovered.tsx", "wb") as out:
                                out.write(chunk[start_idx:idx])
                    except Exception as e:
                        pass

if __name__ == "__main__":
    dump_memory(int(sys.argv[1]))
