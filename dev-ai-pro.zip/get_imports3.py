with open("recovered_73_0x7fb0d0000000.tsx", "rb") as f:
    data = f.read()

# I dumped 250000 bytes starting from `export default function App() {`.
# The imports must be before that in memory. Let's dump the memory again for PID 73 but starting a bit earlier!
