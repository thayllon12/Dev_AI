import sys
with open("recovered_73_0x7fb0d0000000.tsx", "rb") as f:
    data = f.read()

# Let's search for "const getAI = " or "export const" but with spaces
idx = data.find(b"export const getAI =")
if idx != -1:
    print(data[idx:idx+200].decode('utf-8', 'ignore'))
else:
    idx2 = data.find(b"export const getAI")
    if idx2 != -1:
        print(data[idx2:idx2+200].decode('utf-8', 'ignore'))
    else:
        # maybe it's just `export const `? Let's just find `getAI` that is not `getAI()`
        start = 0
        while True:
            pos = data.find(b"getAI", start)
            if pos == -1: break
            if data[pos:pos+7] != b"getAI()":
                print(data[pos-30:pos+100].decode('utf-8', 'ignore'))
            start = pos + 1
