const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Add githubModal state
content = content.replace(
  /const \[micState, setMicState\] = useState[^\n]+;\n/,
  `const [micState, setMicState] = useState<{ isRecording: boolean; volume: number[] }>({ isRecording: false, volume: [] });
  const [githubModal, setGithubModal] = useState<{ isOpen: boolean; mode: "import" | "export" }>({ isOpen: false, mode: "import" });\n`
);

// Replace MicrofoneGemini usage
// Note: We'll use a safer regex matching the exact lines of MicrofoneGemini
content = content.replace(
  /<MicrofoneGemini[\s\S]*?onStateChange=\{setMicState\}\s*\/>/,
  `<button
                      type="button"
                      onClick={() => setGithubModal({ isOpen: true, mode: 'export' })}
                      className="p-2 sm:p-2.5 text-text-muted hover:text-text-primary rounded-xl hover:bg-bg-surface-hover transition-colors shrink-0"
                      title="Exportar para GitHub"
                    >
                      <Github size={20} strokeWidth={2.5} />
                    </button>`
);

// Add GithubSyncModal at the end before Toaster
content = content.replace(
  /<Toaster position="top-center" richColors \/>/,
  `<GithubSyncModal 
        isOpen={githubModal.isOpen} 
        mode={githubModal.mode} 
        onClose={() => setGithubModal({ ...githubModal, isOpen: false })} 
      />
      <Toaster position="top-center" richColors />`
);

fs.writeFileSync('src/App.tsx', content);
