import sys

imports = """
import { AILogo } from "./components/AILogo";
import { MicrofoneGemini, MicrofoneGeminiRef } from "./components/MicrofoneGemini";
import { ImageMarkupModal } from "./components/ImageMarkupModal";
import { FilePreviewModal } from "./components/FilePreviewModal";
import { ModelSelectorModal, getModelById, getProviderByModelId } from "./components/ModelSelectorModal";
import { SettingsModal } from "./components/SettingsModal";
import { ShareModal } from "./components/ShareModal";
import { GithubSyncModal } from "./components/GithubSyncModal";
import { PasteModal } from "./components/PasteModal";
import { MiniDev } from "./components/MiniDev";
import { ContextTokenCounter } from "./components/ContextTokenCounter";
import { GenerationTimer } from "./components/GenerationTimer";
import { cn, copyToClipboard } from "./lib/utils";
import { processLargeFile, saveFileToDB, getFileFromDB, deleteFileFromDB } from "./lib/fileStorage";
import { playTypingTick, playQuotaExceededSound, playCompletionSound, playOpeningSound } from "./lib/audio";
import { resizeImageBase64 } from "./lib/image";
import { getInitialSettings } from "./lib/settings";
import { getAI } from "./lib/ai";
import { useClickOutside } from "./lib/hooks";

function useEvent<T extends (...args: any[]) => any>(handler: T) {
  const handlerRef = useRef(handler);
  useEffect(() => {
    handlerRef.current = handler;
  });
  return useCallback((...args: Parameters<T>) => {
    const fn = handlerRef.current;
    return fn(...args);
  }, []);
}

function classifyQueryComplexity(queryText: string, hasAttachments: boolean): { modelId: string; reason: string } {
  const text = queryText.toLowerCase();
  const proKeywords = [
    "exploit", "hacking", "vulnerabilidade", "reverse engineering", "compiler", "interpretador",
    "vba", "powerpoint", "apresentação", "three.js", "canvas", "sistema completo", "arquitetura",
    "grafos", "bento grid", "monumental", "completo", "jogo", "game", "foda ainda", "complexo",
    "segurança", "algoritmo", "backdoor", "payload", "assembly", "c++", "rust", "otimizar",
    "refatorar o arquivo inteiro", "escrever o código inteiro", "monolítico"
  ];
  const flashKeywords = [
    "react", "html", "css", "tailwind", "express", "node", "database", "banco de dados", "d3",
    "recharts", "gráfico", "api", "dashboard", "função", "function", "criar", "desenvolver", "refinar",
    "corrigir", "refactor", "escreva", "código", "script", "foda", "programa", "modal", "tabela",
    "filtro", "busca", "search", "botão", "button", "firebase", "firestore", "auth", "login",
    "segundos", "cron", "timer", "schedule", "notificação", "som", "áudio"
  ];
  const hasProKeyword = proKeywords.some(keyword => text.includes(keyword));
  const hasFlashKeyword = flashKeywords.some(keyword => text.includes(keyword));
  if (hasAttachments) {
    if (text.length > 800 || hasProKeyword) {
      return {
        modelId: "gemini-3.1-pro-preview",
        reason: "🤖 Auto: Detectou análise complexa de arquivos/código. Acionando Gemini 3.1 Pro!"
      };
    }
    return {
      modelId: "gemini-3.6-flash",
      reason: "🤖 Auto: Detectou arquivos anexados. Acionando Gemini 3.6 Flash!"
    };
  }
  if (text.length > 1200 || hasProKeyword) {
    return {
      modelId: "gemini-3.1-pro-preview",
      reason: "🤖 Auto: Pergunta ultra complexa ou código pesado detectado. Acionando Gemini 3.1 Pro!"
    };
  }
  if (text.length > 250 || hasFlashKeyword) {
    return {
      modelId: "gemini-3.6-flash",
      reason: "🤖 Auto: Pergunta média de programação ou desenvolvimento detectada. Acionando Gemini 3.6 Flash!"
    };
  }
  return {
    modelId: "gemini-3.6-flash",
    reason: "🤖 Auto: Pergunta simples detectada. Acionando Gemini 3.6 Flash!"
  };
}
"""

with open('src/App.tsx', 'r') as f:
    text = f.read()

idx = text.find("export default function App() {")
if idx != -1:
    top = text[:idx]
    bottom = text[idx:]
    with open('src/App.tsx', 'w') as f:
        f.write(top + imports + bottom)
    print("Fixed imports")
else:
    print("Could not find App")
